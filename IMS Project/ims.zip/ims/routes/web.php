<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\backend\CourseController;
use App\Http\Controllers\backend\InstituteController;
use App\Http\Controllers\backend\UserController;
use App\Http\Controllers\backend\CountryController;
use App\Http\Controllers\backend\StateController;
use App\Http\Controllers\backend\User_RoleController;
use App\Http\Controllers\backend\subjectController;
use App\Http\Controllers\backend\Inquiry_forsController;
use App\Http\Controllers\backend\NotificationsController;
use App\Http\Controllers\backend\CallstatusesController;
use App\Http\Controllers\backend\LeadstatusesController;
use App\Http\Controllers\backend\CourseSubjectController;
use App\Http\Controllers\backend\InstituteBranchController;
use App\Http\Controllers\backend\AcademicyearController;
use App\Http\Controllers\backend\FirmController;
use App\Http\Controllers\backend\FeeheadController;
use App\Http\Controllers\backend\FeeStructureController;
use App\Http\Controllers\backend\FeeStructureMapController;
use App\Http\Controllers\backend\StudentController;
use App\Http\Controllers\backend\StudentCourseController;
use App\Http\Controllers\backend\FinacialyearController;
use App\Http\Controllers\backend\FeereceiptController;
use App\Http\Controllers\backend\StudentFeeEmiController;
use App\Http\Controllers\backend\FacultyController;
use App\Http\Controllers\backend\BatchController;
use App\Http\Controllers\backend\StudentBatchAssignController;
use App\Http\Controllers\backend\AttendanceController;
use App\Http\Controllers\backend\BatchExtensionController;
use App\Http\Controllers\backend\BatcheCompletionController;
use App\Http\Controllers\backend\ChartController;

// For report controller
use App\Http\Controllers\reports\StudentAttandanceController;
use App\Http\Controllers\reports\FacultyReportsController;
use App\Http\Controllers\reports\RevenueReportController;
use App\Http\Controllers\reports\BatchReportController;
use App\Http\Controllers\reports\PortFolioSubmissionController;




use App\Http\Controllers\Studentc;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/


// Backend Controller

Route::get('/', [UserController::class, 'index'])->name('login');
Route::post('user/admin', [UserController::class, 'login'])->name('user.admin');


Route::middleware(['auth'])->group(function () {
    Route::get('adminlogout', [UserController::class, 'logout'])->name('adminlogout');
    // change branch
    Route::post('changebranch', [InstituteBranchController::class, 'changeBranch'])->name('changeBranch');

    //for notification
    Route::get('notifications/show/{id?}', [NotificationsController::class, 'show'])->name('notifications.show');
    Route::get('notifications/count', [NotificationsController::class, 'count'])->name('notifications.count');


    Route::middleware(['superAdminAllow'])->group(function () {
        Route::get('admindashboard', [UserController::class, 'dashboard'])->name('dashboard');

        Route::get('superadmin/changepassword', [UserController::class, 'changepassword'])->name('superadmin.changepassword');
        Route::post('superadmin/changepassword', [UserController::class, 'updatepassword'])->name('superadmin.updatepassword');

        // For Users
        Route::get('users/listing', [UserController::class, 'list'])->name('users.listing');
        Route::get('users/add', [UserController::class, 'create'])->name('users.add');
        Route::post('users/addnew', [UserController::class, 'store'])->name('users.addnew');
        Route::get('users/edit/{id}', [UserController::class, 'edit'])->name('users.edit');
        Route::post('users/editusers/{id}', [UserController::class, 'update'])->name('users.editusers');
        Route::get('users/trash/{id}', [UserController::class, 'trash'])->name('users.trash');
        Route::get('users/trashview', [UserController::class, 'trashview'])->name('users.trashview');
        Route::get('users/restore/{id}', [UserController::class, 'restore'])->name('users.restore');
        Route::get('users/delete/{id}', [UserController::class, 'destroy'])->name('users.delete');

        // For Countries
        Route::get('countries/listing', [CountryController::class, 'index'])->name('countries.listing');
        Route::get('countries/add', [CountryController::class, 'create'])->name('countries.add');
        Route::post('countries/addnew', [CountryController::class, 'store'])->name('countries.addnew');
        Route::get('countries/edit/{id}', [CountryController::class, 'edit'])->name('countries.edit');
        Route::post('countries/editcountries/{id}', [CountryController::class, 'update'])->name('countries.editcountries');
        Route::get('countries/trash/{id}', [CountryController::class, 'trash'])->name('countries.trash');
        Route::get('countries/trashview', [CountryController::class, 'trashview'])->name('countries.trashview');
        Route::get('countries/restore/{id}', [CountryController::class, 'restore'])->name('countries.restore');
        Route::get('countries/delete/{id}', [CountryController::class, 'destroy'])->name('countries.delete');

        // For State
        Route::get('states/listing', [StateController::class, 'index'])->name('states.listing');
        Route::get('states/add', [StateController::class, 'create'])->name('states.add');
        Route::post('states/addnew', [StateController::class, 'store'])->name('states.addnew');
        Route::get('states/edit/{id}', [StateController::class, 'edit'])->name('states.edit');
        Route::post('states/editstates/{id}', [StateController::class, 'update'])->name('states.editstates');
        Route::get('states/trashview', [StateController::class, 'trashview'])->name('states.trashview');
        Route::get('states/trash/{id}', [StateController::class, 'trash'])->name('states.trash');
        Route::get('states/restore/{id}', [StateController::class, 'restore'])->name('states.restore');
        Route::get('states/delete/{id}', [StateController::class, 'destroy'])->name('states.delete');

        // For Institute
        Route::get('institute/listing', [InstituteController::class, 'index'])->name('institute.listing');
        // Route::get('institute/add', [InstituteController::class, 'create'])->name('institute.add');
        // Route::post('institute/addnew', [InstituteController::class, 'store'])->name('institute.addnew');
        Route::get('institute/edit/{id}', [InstituteController::class, 'edit'])->name('institute.edit');
        Route::post('institute/editinstitute/{id}', [InstituteController::class, 'update'])->name('institute.editinstitute');
        // Route::get('institute/trashview', [InstituteController::class, 'trashview'])->name('institute.trashview');
        // Route::get('institute/trash/{id}', [InstituteController::class, 'trash'])->name('institute.trash');
        // Route::get('institute/restore/{id}', [InstituteController::class, 'restore'])->name('institute.restore');
        // Route::get('institute/delete/{id}', [InstituteController::class, 'destroy'])->name('institute.delete');
        //For Remove Image
        Route::get('institute/deleteimage/{id}', [InstituteController::class, 'deleteImage'])->name('institute.deleteimage');

        // For Subject
        Route::get('subject/listing', [subjectController::class, 'index'])->name('subject.listing');
        Route::get('subject/add', [subjectController::class, 'create'])->name('subject.add');
        Route::post('subject/addnew', [subjectController::class, 'store'])->name('subject.addnew');
        Route::get('subject/edit/{id}', [subjectController::class, 'edit'])->name('subject.edit');
        Route::post('subject/editsubject/{id}', [subjectController::class, 'update'])->name('subject.editsubject');
        Route::get('subject/trashview', [subjectController::class, 'trashview'])->name('subject.trashview');
        Route::get('subject/trash/{id}', [subjectController::class, 'trash'])->name('subject.trash');
        Route::get('subject/restore/{id}', [subjectController::class, 'restore'])->name('subject.restore');
        Route::get('subject/delete/{id}', [subjectController::class, 'destroy'])->name('subject.delete');

        // For Course
        Route::get('course/listing', [CourseController::class, 'index'])->name('course.listing');
        Route::get('course/add', [CourseController::class, 'create'])->name('course.add');
        Route::post('course/addnew', [CourseController::class, 'store'])->name('course.addnew');
        Route::get('course/edit/{id}', [CourseController::class, 'edit'])->name('course.edit');
        Route::post('course/editcourse/{id}', [CourseController::class, 'update'])->name('course.editcourse');
        Route::get('course/trashview', [CourseController::class, 'trashview'])->name('course.trashview');
        Route::get('course/trash/{id}', [CourseController::class, 'trash'])->name('course.trash');
        Route::get('course/restore/{id}', [CourseController::class, 'restore'])->name('course.restore');
        Route::get('course/delete/{id}', [CourseController::class, 'destroy'])->name('course.delete');

        // For CourseSubject 
        Route::get('coursesubject/listing', [CourseSubjectController::class, 'index'])->name('coursesubject.listing');
        Route::post('coursesubject/addnew', [CourseSubjectController::class, 'store'])->name('coursesubject.addnew');
        Route::get('coursesubject/delete/{id}', [CourseSubjectController::class, 'destroy'])->name('coursesubject.delete');

        // For InstituteBranch
        Route::get('institutebranch/listing', [InstituteBranchController::class, 'index'])->name('institutebranch.listing');
        // Route::get('institutebranch/add', [InstituteBranchController::class, 'create'])->name('institutebranch.add');
        // Route::post('institutebranch/addnew', [InstituteBranchController::class, 'store'])->name('institutebranch.addnew');
        Route::get('institutebranch/edit/{id}', [InstituteBranchController::class, 'edit'])->name('institutebranch.edit');
        Route::post('institutebranch/editinstitutebranch/{id}', [InstituteBranchController::class, 'update'])->name('institutebranch.editinstitutebranch');
        // Route::get('institutebranch/trashview', [InstituteBranchController::class, 'trashview'])->name('institutebranch.trashview');
        // Route::get('institutebranch/trash/{id}', [InstituteBranchController::class, 'trash'])->name('institutebranch.trash');
        // Route::get('institutebranch/restore/{id}', [InstituteBranchController::class, 'restore'])->name('institutebranch.restore');
        // Route::get('institutebranch/delete/{id}', [InstituteBranchController::class, 'destroy'])->name('institutebranch.delete');

        // For Academicyear
        Route::get('academicyear/listing', [AcademicyearController::class, 'index'])->name('academicyear.listing');
        Route::get('academicyear/add', [AcademicyearController::class, 'create'])->name('academicyear.add');
        Route::post('academicyear/addnew', [AcademicyearController::class, 'store'])->name('academicyear.addnew');
        Route::get('academicyear/edit/{id}', [AcademicyearController::class, 'edit'])->name('academicyear.edit');
        Route::post('academicyear/editacademicyear/{id}', [AcademicyearController::class, 'update'])->name('academicyear.editacademicyear');
        Route::get('academicyear/trashview', [AcademicyearController::class, 'trashview'])->name('academicyear.trashview');
        Route::get('academicyear/trash/{id}', [AcademicyearController::class, 'trash'])->name('academicyear.trash');
        Route::get('academicyear/restore/{id}', [AcademicyearController::class, 'restore'])->name('academicyear.restore');
        Route::get('academicyear/delete/{id}', [AcademicyearController::class, 'destroy'])->name('academicyear.delete');

        // For Finacialyear
        Route::get('finacialyear/listing', [FinacialyearController::class, 'index'])->name('finacialyear.listing');
        Route::get('finacialyear/add', [FinacialyearController::class, 'create'])->name('finacialyear.add');
        Route::post('finacialyear/addnew', [FinacialyearController::class, 'store'])->name('finacialyear.addnew');
        Route::get('finacialyear/edit/{id}', [FinacialyearController::class, 'edit'])->name('finacialyear.edit');
        Route::post('finacialyear/editfinacialyear/{id}', [FinacialyearController::class, 'update'])->name('finacialyear.editfinacialyear');
        Route::get('finacialyear/trashview', [FinacialyearController::class, 'trashview'])->name('finacialyear.trashview');
        Route::get('finacialyear/trash/{id}', [FinacialyearController::class, 'trash'])->name('finacialyear.trash');
        Route::get('finacialyear/restore/{id}', [FinacialyearController::class, 'restore'])->name('finacialyear.restore');
        Route::get('finacialyear/delete/{id}', [FinacialyearController::class, 'destroy'])->name('finacialyear.delete');

        // For Firm(Bank) 
        Route::get('firm/listing', [FirmController::class, 'index'])->name('firm.listing');
        Route::get('firm/add', [FirmController::class, 'create'])->name('firm.add');
        Route::post('firm/addnew', [FirmController::class, 'store'])->name('firm.addnew');
        Route::get('firm/edit/{id}', [FirmController::class, 'edit'])->name('firm.edit');
        Route::post('firm/editfirm/{id}', [FirmController::class, 'update'])->name('firm.editfirm');
        Route::get('firm/trashview', [FirmController::class, 'trashview'])->name('firm.trashview');
        Route::get('firm/trash/{id}', [FirmController::class, 'trash'])->name('firm.trash');
        Route::get('firm/restore/{id}', [FirmController::class, 'restore'])->name('firm.restore');
        Route::get('firm/delete/{id}', [FirmController::class, 'destroy'])->name('firm.delete');
        //For Remove Image
        Route::get('firm/deleteimage/{id}', [FirmController::class, 'deleteImage'])->name('firm.deleteimage');

        // For FeeHead 
        Route::get('feehead/listing', [FeeheadController::class, 'index'])->name('feehead.listing');
        Route::get('feehead/add', [FeeheadController::class, 'create'])->name('feehead.add');
        Route::post('feehead/addnew', [FeeheadController::class, 'store'])->name('feehead.addnew');
        Route::get('feehead/edit/{id}', [FeeheadController::class, 'edit'])->name('feehead.edit');
        Route::post('feehead/editfeehead/{id}', [FeeheadController::class, 'update'])->name('feehead.editfeehead');
        Route::get('feehead/trashview', [FeeheadController::class, 'trashview'])->name('feehead.trashview');
        Route::get('feehead/trash/{id}', [FeeheadController::class, 'trash'])->name('feehead.trash');
        Route::get('feehead/restore/{id}', [FeeheadController::class, 'restore'])->name('feehead.restore');
        Route::get('feehead/delete/{id}', [FeeheadController::class, 'destroy'])->name('feehead.delete');

        // For FeeStructure 
        Route::get('feestructure/listing', [FeeStructureController::class, 'index'])->name('feestructure.listing');
        Route::get('feestructure/add', [FeeStructureController::class, 'create'])->name('feestructure.add');
        Route::post('feestructure/addnew', [FeeStructureController::class, 'store'])->name('feestructure.addnew');
        Route::get('feestructure/edit/{id}', [FeeStructureController::class, 'edit'])->name('feestructure.edit');
        Route::post('feestructure/editfeestructure/{id}', [FeeStructureController::class, 'update'])->name('feestructure.editfeestructure');
        Route::get('feestructure/trashview', [FeeStructureController::class, 'trashview'])->name('feestructure.trashview');
        Route::get('feestructure/trash/{id}', [FeeStructureController::class, 'trash'])->name('feestructure.trash');
        Route::get('feestructure/restore/{id}', [FeeStructureController::class, 'restore'])->name('feestructure.restore');
        Route::get('feestructure/delete/{id}', [FeeStructureController::class, 'destroy'])->name('feestructure.delete');

        // For FeeStructureMap  
        Route::post('feestructuremap/addnew', [FeeStructureMapController::class, 'store'])->name('feestructuremap.addnew');
        Route::get('feestructuremap/delete/{id}', [FeeStructureMapController::class, 'destroy'])->name('feestructuremap.delete');

        // For feereceipt  
        Route::get('feereceipt/add', [FeereceiptController::class, 'create'])->name('feereceipt.add');
        Route::get('fee/add', [FeereceiptController::class, 'add'])->name('feeadd');
        Route::post('feereceipt/addnew', [FeereceiptController::class, 'store'])->name('feereceipt.addnew');
        Route::get('feereceipt/delete/{id}', [FeereceiptController::class, 'destroy'])->name('feereceipt.delete');

        // For Emi
        Route::post('student/emi', [StudentFeeEmiController::class, 'store'])->name('emi');
        Route::get('student/showemi/{studentId}', [StudentFeeEmiController::class, 'show'])->name('showemi');
        Route::get('student/destroyemi/{installmentId}/studentid/{studentId}', [StudentFeeEmiController::class, 'destroy'])->name('deleteemi');

        // For Faculty  
        Route::get('faculty/listing', [FacultyController::class, 'index'])->name('faculty.listing');
        Route::get('faculty/add', [FacultyController::class, 'create'])->name('faculty.add');
        Route::post('faculty/addnew', [FacultyController::class, 'store'])->name('faculty.addnew');
        Route::get('faculty/edit/{id}', [FacultyController::class, 'edit'])->name('faculty.edit');
        Route::post('faculty/editfaculty/{id}', [FacultyController::class, 'update'])->name('faculty.editfaculty');
        Route::get('faculty/trashview', [FacultyController::class, 'trashview'])->name('faculty.trashview');
        Route::get('faculty/trash/{id}', [FacultyController::class, 'trash'])->name('faculty.trash');
        Route::get('faculty/restore/{id}', [FacultyController::class, 'restore'])->name('faculty.restore');
        Route::get('faculty/delete/{id}', [FacultyController::class, 'destroy'])->name('faculty.delete');
        //For Remove Image
        Route::get('faculty/deleteimage/{id}', [FacultyController::class, 'deleteImage'])->name('faculty.deleteimage');

        // For Batch  
        Route::get('batch/listing', [BatchController::class, 'index'])->name('batch.listing');
        Route::get('batch/add', [BatchController::class, 'create'])->name('batch.add');
        Route::post('batch/addnew', [BatchController::class, 'store'])->name('batch.addnew');
        Route::get('batch/edit/{id}', [BatchController::class, 'edit'])->name('batch.edit');
        Route::post('batch/editbatch/{id}', [BatchController::class, 'update'])->name('batch.editbatch');
        Route::get('batch/trashview', [BatchController::class, 'trashview'])->name('batch.trashview');
        Route::get('batch/trash/{id}', [BatchController::class, 'trash'])->name('batch.trash');
        Route::get('batch/restore/{id}', [BatchController::class, 'restore'])->name('batch.restore');
        Route::get('batch/delete/{id}', [BatchController::class, 'destroy'])->name('batch.delete');
        // faculty listing
        Route::get('faculty/batch/listing', [BatchController::class, 'facultybatch'])->name('faculty.batch.listing');

        Route::post('studentbatchassign/addnew', [StudentBatchAssignController::class, 'store'])->name('studentbatchassign.addnew');
        Route::get('studentbatchassign/delete/{id}', [StudentBatchAssignController::class, 'destroy'])->name('studentbatchassign.delete');



        //  For Batch Extension Approval
        Route::get('batchextensionapproval/listing', [BatchExtensionController::class, 'batchextensionapproval'])->name('batchextensionapproval.listing');
        Route::get('batchextensionapproval/approve/{id}', [BatchExtensionController::class, 'approve'])->name('batchextensionapproval.approve');
        Route::get('batchextensionapproval/cancel/{id}', [BatchExtensionController::class, 'cancel'])->name('batchextensionapproval.cancel');


        //  For Batch Completion Approval
        Route::get('batchecompletionapproval/listing', [BatcheCompletionController::class, 'batchecompletionapproval'])->name('batchecompletionapproval.listing');
        Route::get('batchecompletionapproval/edit/{id}', [BatcheCompletionController::class, 'edit'])->name('batchecompletionapproval.edit');
        Route::post('batchecompletionapproval/editnew/{id}', [BatcheCompletionController::class, 'update'])->name('batchecompletionapproval.editnew');

        // For Chart
        Route::post('course/income/data', [ChartController::class, 'getCourseIncomeData'])->name('CourseIncomeData');
        Route::post('course/traffic/data', [ChartController::class, 'getCourseTrafficData'])->name('CourseTrafficData');

        // For Student  
        Route::get('student/listing', [StudentController::class, 'index'])->name('student.listing');
        Route::get('student/add', [StudentController::class, 'create'])->name('student.add');
        Route::post('student/addnew', [StudentController::class, 'store'])->name('student.addnew');
        Route::get('student/edit/{id}', [StudentController::class, 'edit'])->name('student.edit');
        Route::post('student/editstudent/{id}', [StudentController::class, 'update'])->name('student.editstudent');
        Route::get('student/trashview', [StudentController::class, 'trashview'])->name('student.trashview');
        Route::get('student/trash/{id}', [StudentController::class, 'trash'])->name('student.trash');
        Route::get('student/restore/{id}', [StudentController::class, 'restore'])->name('student.restore');
        Route::get('student/delete/{id}', [StudentController::class, 'destroy'])->name('student.delete');
        //For Remove Image
        Route::get('student/deleteimage/{id}', [StudentController::class, 'deleteImage'])->name('student.deleteimage');
        Route::post('updatefee/{id}', [StudentController::class, 'updateTotalFee'])->name('updateTotalFee');
        Route::get('student/scalender', [StudentController::class, 'scalender'])->name('student.scalender');

        // For Studentcourse  
        Route::get('studentcourse/add', [StudentCourseController::class, 'create'])->name('studentcourse.add');
        Route::post('studentcourse/addnew', [StudentCourseController::class, 'store'])->name('studentcourse.addnew');
        Route::get('studentcourse/delete/{id}', [StudentCourseController::class, 'destroy'])->name('studentcourse.delete');


        // For notifications
        Route::get('notifications/listing', [NotificationsController::class, 'index'])->name('notifications.listing');
        Route::get('notifications/add', [NotificationsController::class, 'create'])->name('notifications.add');
        Route::post('notifications/addnew', [NotificationsController::class, 'store'])->name('notifications.addnew');
        Route::get('notifications/edit/{id}', [NotificationsController::class, 'edit'])->name('notifications.edit');
        Route::post('notifications/editnotifications/{id}', [NotificationsController::class, 'update'])->name('notifications.editnotifications');
        Route::get('notifications/trashview', [NotificationsController::class, 'trashview'])->name('notifications.trashview');
        Route::get('notifications/trash/{id}', [NotificationsController::class, 'trash'])->name('notifications.trash');
        Route::get('notifications/restore/{id}', [NotificationsController::class, 'restore'])->name('notifications.restore');
        Route::get('notifications/delete/{id}', [NotificationsController::class, 'destroy'])->name('notifications.delete');

        // Student Attandance Report
        Route::get('student/studentattandancereport', [StudentAttandanceController::class, 'index'])->name('studentattandancereport.listing');
        Route::post('studentattandancereport', [StudentAttandanceController::class, 'store'])->name('studentattandancereport');

        // StudentWithSubjectReport
        Route::get('student/StudentWithSubjectReport', [StudentAttandanceController::class, 'studentwithsubject'])->name('StudentWithSubjectReport.listing');
        Route::post('StudentWithSubjectReport', [StudentAttandanceController::class, 'studentwithsubjectreport'])->name('StudentWithSubjectReport');
        // Student Batch Report
        Route::get('student/StudentBatchReport', [StudentAttandanceController::class, 'StudentBatch'])->name('StudentBatchReport.listing');
        Route::post('StudentBatchReport', [StudentAttandanceController::class, 'StudentBatchReport'])->name('StudentBatchReport');
        // Student Detail Report
        Route::get('student/StudentDetailReport', [StudentAttandanceController::class, 'StudentDetail'])->name('StudentDetailReport.listing');
        Route::post('StudentDetailReport', [StudentAttandanceController::class, 'StudentDetailReport'])->name('StudentDetailReport');
        // Facultys Detail Report
        Route::get('faculty/FacultyDetailReport', [FacultyReportsController::class, 'FacultyDetail'])->name('FacultyDetailReport.listing');
        Route::post('FacultyDetailReport', [FacultyReportsController::class, 'FacultyDetailReport'])->name('FacultyDetailReport');
        // faculty Batch Report
        Route::get('faculty/FacultyBatchReport', [FacultyReportsController::class, 'FacultyBatch'])->name('FacultyBatchReport.listing');
        Route::post('FacultyBatchReport', [FacultyReportsController::class, 'FacultyBatchReport'])->name('FacultyBatchReport');
        // Revenue Report
        Route::get('RevenueReport', [RevenueReportController::class, 'RevenueReport'])->name('RevenueReport.listing');
        Route::post('RevenueReportdetail', [RevenueReportController::class, 'RevenueReportdetail'])->name('RevenueReportdetail');
        // faculty Batch timing Report
        Route::get('faculty/facultyBatchTiming', [FacultyReportsController::class, 'FacultyBatchTiming'])->name('FacultyBatchTiming.listing');
        Route::post('FacultyBatchTimingReport', [FacultyReportsController::class, 'FacultyBatchTimingReport'])->name('FacultyBatchTimingReport');
        // Faculty Attandance Counter Report
        Route::get('faculty/facultyattandancecounterreport', [FacultyReportsController::class, 'FacultyAttandanceCounter'])->name('FacultyAttandanceCounter.listing');
        Route::post('FacultyAttandanceCounterReport', [FacultyReportsController::class, 'FacultyAttandanceCounterReport'])->name('FacultyAttandanceCounterReport');
        // Batch Extension Report
        Route::get('batch/batchExtensionReport', [BatchReportController::class, 'BatchExtension'])->name('BatchExtension.listing');
        Route::post('BatchExtensionReport', [BatchReportController::class, 'BatchExtensionReport'])->name('BatchExtensionReport');
        // Portfolio Submission Report
        Route::get('student/PortfolioSubmissionReport', [PortFolioSubmissionController::class, 'PortfolioSubmission'])->name('PortfolioSubmission.listing');
        Route::post('PortfolioSubmissionReport', [PortFolioSubmissionController::class, 'PortfolioSubmissionReport'])->name('PortfolioSubmissionReport');
    });


    Route::group(['middleware' => 'studentAllow'], function () {
        Route::get('student/dashboard', [UserController::class, 'studentdashboard'])->name('student.dashboard');
        Route::get('student/show', [StudentController::class, 'show'])->name('student.show');
        Route::get('studentcourse/detail', [StudentCourseController::class, 'detail'])->name('studentcourse.detail');
        Route::get('feereceipt/detail', [FeereceiptController::class, 'detail'])->name('feereceipt.detail');

        // student calender show for attandance
        Route::get('student/calender', [StudentController::class, 'calender'])->name('student.calender');

        // student PortfolioSubmission
        Route::get('student/PortfolioSubmission', [StudentController::class, 'PortfolioSubmission'])->name('student.PortfolioSubmission');
       
        // student batchcompletion
        Route::get('student/batchcompletion', [StudentController::class, 'batchcompletion'])->name('student.batchcompletion');

        //feereceipt print
        Route::get('feereceipt/print/{id}', [FeereceiptController::class, 'printReceipt'])->name('feereceipt.print');
        Route::get('generate-pdf/{id}', [FeereceiptController::class, 'generatePDF'])->name('makepdf');
        // student subjectwise chart
        Route::get('subject/batch/data', [ChartController::class, 'getSubjectWiseBatchData'])->name('getSubjectWiseBatchData');
        // change password
        Route::get('student/changepassword', [StudentController::class, 'changepassword'])->name('student.changepassword');
        Route::post('student/changepassword', [StudentController::class, 'updatepassword'])->name('student.updatepassword');
    });


    Route::group(['middleware' => 'facultyAllow'], function () {
        // Routes accessible to users with roles 1 and 3
        Route::get('faculty/dashboard', [UserController::class, 'facultydashboard'])->name('faculty.dashboard');
        Route::get('faculty/show', [FacultyController::class, 'show'])->name('faculty.show');
        Route::get('faculty/calender/add', [FacultyController::class, 'calender'])->name('faculty.calender.add');

        // Attendance
        Route::post('saveattendance', [AttendanceController::class, 'store'])->name('saveAttendance');
        // faculty subjectwise chart
        Route::get('faculty/subject/batchdata', [ChartController::class, 'getFacultySubjectWiseBatchData'])->name('getFacultySubjectWiseBatchData');

        // For Batch Extension
        Route::get('batchextension/listing', [BatchExtensionController::class, 'index'])->name('batchextension.listing');
        Route::get('batchextension/edit/{id}', [BatchExtensionController::class, 'edit'])->name('batchextension.edit');
        Route::post('batchextension/editbatchextension/{id}', [BatchExtensionController::class, 'update'])->name('batchextension.editbatchextension');

        //  For Batch Completion
        Route::get('batchecompletion/listing', [BatcheCompletionController::class, 'index'])->name('batchecompletion.listing');
        Route::get('batchecompletion/add/{id}', [BatcheCompletionController::class, 'create'])->name('batchecompletion.add');
        Route::post('batchecompletion/addnew/{id}', [BatcheCompletionController::class, 'store'])->name('batchecompletion.addnew');
        // change password
        Route::get('faculty/changepassword', [FacultyController::class, 'changepassword'])->name('faculty.changepassword');
        Route::post('faculty/changepassword', [FacultyController::class, 'updatepassword'])->name('faculty.updatepassword');

        // Portfolio Submission
        Route::get('faculty/PortfolioSubmission', [FacultyController::class, 'PortfolioSubmission'])->name('faculty.PortfolioSubmission');
        Route::post('savePortfolioSubmission', [FacultyController::class, 'SavePortfolioSubmission'])->name('SavePortfolioSubmission');
        Route::get('PortfolioSubmission/delete/{id}', [FacultyController::class, 'DeletePortfolioSubmission'])->name('PortfolioSubmission.delete');
    });


    // For Userrole
    // Route::get('role/listing', [User_RoleController::class, 'index'])->name('role.listing');
    // Route::get('role/add', [User_RoleController::class, 'create'])->name('role.add');
    // Route::post('role/addnew', [User_RoleController::class, 'store'])->name('role.addnew');
    // Route::get('role/edit/{id}', [User_RoleController::class, 'edit'])->name('role.edit');
    // Route::post('role/editrole/{id}', [User_RoleController::class, 'update'])->name('role.editrole');
    // Route::get('role/trashview', [User_RoleController::class, 'trashview'])->name('role.trashview');
    // Route::get('role/trash/{id}', [User_RoleController::class, 'trash'])->name('role.trash');
    // Route::get('role/restore/{id}', [User_RoleController::class, 'restore'])->name('role.restore');
    // Route::get('role/delete/{id}', [User_RoleController::class, 'destroy'])->name('role.delete');

    // For Inquiry_fors
    Route::get('inquiry/listing', [Inquiry_forsController::class, 'index'])->name('inquiry.listing');
    Route::get('inquiry/add', [Inquiry_forsController::class, 'create'])->name('inquiry.add');
    Route::post('inquiry/addnew', [Inquiry_forsController::class, 'store'])->name('inquiry.addnew');
    Route::get('inquiry/edit/{id}', [Inquiry_forsController::class, 'edit'])->name('inquiry.edit');
    Route::post('inquiry/editInquiry_fors/{id}', [Inquiry_forsController::class, 'update'])->name('inquiry.editinquiry');
    Route::get('inquiry/trashview', [Inquiry_forsController::class, 'trashview'])->name('inquiry.trashview');
    Route::get('inquiry/trash/{id}', [Inquiry_forsController::class, 'trash'])->name('inquiry.trash');
    Route::get('inquiry/restore/{id}', [Inquiry_forsController::class, 'restore'])->name('inquiry.restore');
    Route::get('inquiry/delete/{id}', [Inquiry_forsController::class, 'destroy'])->name('inquiry.delete');


    // For Callstatuses
    Route::get('callstatuses/listing', [CallstatusesController::class, 'index'])->name('callstatuses.listing');
    Route::get('callstatuses/add', [CallstatusesController::class, 'create'])->name('callstatuses.add');
    Route::post('callstatuses/addnew', [CallstatusesController::class, 'store'])->name('callstatuses.addnew');
    Route::get('callstatuses/edit/{id}', [CallstatusesController::class, 'edit'])->name('callstatuses.edit');
    Route::post('callstatuses/editcallstatuses_fors/{id}', [CallstatusesController::class, 'update'])->name('callstatuses.editcallstatuses');
    Route::get('callstatuses/trashview', [CallstatusesController::class, 'trashview'])->name('callstatuses.trashview');
    Route::get('callstatuses/trash/{id}', [CallstatusesController::class, 'trash'])->name('callstatuses.trash');
    Route::get('callstatuses/restore/{id}', [CallstatusesController::class, 'restore'])->name('callstatuses.restore');
    Route::get('callstatuses/delete/{id}', [CallstatusesController::class, 'destroy'])->name('callstatuses.delete');

    // For Leadstatuses
    Route::get('leadstatuses/listing', [LeadstatusesController::class, 'index'])->name('leadstatuses.listing');
    Route::get('leadstatuses/add', [LeadstatusesController::class, 'create'])->name('leadstatuses.add');
    Route::post('leadstatuses/addnew', [LeadstatusesController::class, 'store'])->name('leadstatuses.addnew');
    Route::get('leadstatuses/edit/{id}', [LeadstatusesController::class, 'edit'])->name('leadstatuses.edit');
    Route::post('leadstatuses/editleadstatuses_fors/{id}', [LeadstatusesController::class, 'update'])->name('leadstatuses.editleadstatuses');
    Route::get('leadstatuses/trashview', [LeadstatusesController::class, 'trashview'])->name('leadstatuses.trashview');
    Route::get('leadstatuses/trash/{id}', [LeadstatusesController::class, 'trash'])->name('leadstatuses.trash');
    Route::get('leadstatuses/restore/{id}', [LeadstatusesController::class, 'restore'])->name('leadstatuses.restore');
    Route::get('leadstatuses/delete/{id}', [LeadstatusesController::class, 'destroy'])->name('leadstatuses.delete');
});


// Route::get('students', [Studentc::class, 'index'])->name('student.listing.public');
// Route::get('students', [Studentc::class, 'create'])->name('student.add.public');
// Route::post('students/addnew', [Studentc::class, 'store'])->name('student.addnew.public');
// php artisan make:model Portfoliosubmission

// php artisan make:controller reports\PortFolioSubmissionController  --model=StudentAttandance
// 

// php artisan make:migration change_column_student --table=student

// php artisan make:migration create_portfoliosubmission_table 




Route::get('/cc', function () {
    Artisan::call('config:cache');

    Artisan::call('route:cache');

    Artisan::call('cache:clear');

    Artisan::call('view:clear');
    return 'done';
});

// Route::get('/rc', function () {
//     Artisan::call('route:cache');
// });

// Route::get('/configc', function () {
//     Artisan::call('config:cache');
// });

// Route::get('/vc', function () {
//     Artisan::call('view:clear');
// });
// Route::get('/db', function () {
//     // Call Artisan command to run migrations
//     Artisan::call('migrate');

//     // Optionally, call Artisan command to run seeders
//     // Artisan::call('db:seed');

//     return 'Database migration completed successfully.';
// });

 //   php artisan make:middleware facultyAllow

// session('BranchId')
