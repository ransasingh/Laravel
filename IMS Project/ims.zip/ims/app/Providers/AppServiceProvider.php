<?php

namespace App\Providers;

use App\Models\Faculty;
use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\View;
use App\Models\InstituteBranch;
use App\Models\Student;
use Illuminate\Support\Facades\Auth;


class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        // Using a view composer to share $branches with all views
        View::composer('layout.admin_header', function ($view) {
            $branches = InstituteBranch::all();
            $user = Auth::user();
            if ($user) {
                switch ($user->RoleId) {
                    case 3: // Faculty
                        $facultyProfile = Faculty::where('UserId', $user->id)->first();
                        $imagePath = $facultyProfile && $facultyProfile->ProfileImage && file_exists(public_path('uploads/faculty/profile/' . $facultyProfile->ProfileImage)) ? asset('uploads/faculty/profile/' . $facultyProfile->ProfileImage) : url('assets/images/default/user_image.png');
                        break;
                    case 4: // Student
                        $studentProfile = Student::where('UserId', $user->id)->first();
                        $imagePath = $studentProfile && $studentProfile->ProfileImage && file_exists(public_path('uploads/student/profile/' . $studentProfile->ProfileImage)) ? asset('uploads/student/profile/' . $studentProfile->ProfileImage) : url('assets/images/default/user_image.png');
                        break;
                    default:
                        $imagePath =  url('assets/images/default/user_image.png');
                }
            }

            $view->with('branches', $branches)
                ->with('userimage', $imagePath);
        });
    }
}
