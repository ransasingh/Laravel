<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Batchdetail extends Model
{
    use HasFactory;
    use SoftDeletes;

    protected $table = 'batchdetail';
    protected $fillable = [
        'SubjectId',
        'BatchDay',
        'TransferToFacultyId',
        'IsActive',
        'createdBy',
        'updatedBy',
        'BatchId',
    ];
}
