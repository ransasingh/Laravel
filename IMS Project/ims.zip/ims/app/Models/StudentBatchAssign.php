<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class StudentBatchAssign extends Model
{
    use HasFactory;
    use SoftDeletes;

    protected $table = 'studentbatchassign';

    protected $fillable = [
        'BatchDetailId',
        'StudentId',
        'IsCompleted',
        'IsActive',
        'createdBy',
        'updatedBy',
     
    ];
}
