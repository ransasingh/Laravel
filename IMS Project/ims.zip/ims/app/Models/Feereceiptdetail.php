<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Feereceiptdetail extends Model
{
    use HasFactory;
    protected $table = 'feereceiptdetail';
    protected $fillable = [
        'FeeReceiptId',
        'FeeHeadId',
        'Amount',
        'created_at',
        'updated_at',

    ];

    public function receipt()
    {
        return $this->belongsTo(FeeReceipt::class, 'FeeReceiptId', 'id');
    }
}
