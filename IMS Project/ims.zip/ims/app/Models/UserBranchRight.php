<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserBranchRight extends Model
{
    use HasFactory;
    protected $table = 'userbranchright';

    public $fillable = [
        'UserId',
        'BranchId',
        'createdBy',
        'updatedBy',
        'created_at',
        'updated_at',
    ];
}
