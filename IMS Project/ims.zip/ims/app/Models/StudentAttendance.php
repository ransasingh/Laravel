<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StudentAttendance extends Model
{
    use HasFactory;
    protected $table = 'studentattandance';

    protected $fillable = [
        'BatchDetailId',
        'ForDate',
        'StudentId',
        'IsActive',
        'createdBy',
        'updatedBy',
        'DayAttandance',
        'IsOnline',
        'StartTime',
        'EndTime',
           ];
}
