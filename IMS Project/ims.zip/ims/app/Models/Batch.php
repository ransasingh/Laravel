<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Batch extends Model
{
    use HasFactory;
    use SoftDeletes;

    protected $table = 'batch';
    protected $fillable = [
        'FacultyId',
        'StartTimeInMinutes',
        'EndTimeInMinutes',
        'FromDate',
        'ToDate',
        'StudentCapacity',
        'Name',
        'IsCompleted',
        'IsActive',
        'createdBy',
        'updatedBy',
        'IsApproved',
        'VerifyBy',
        'VerifyAt',

    ];
}
