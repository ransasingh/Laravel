<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Institute extends Model
{
    use HasFactory;
    use SoftDeletes;

    protected $table = 'institute';

    public $fillable = [
        'Name',
        'MobileNumber',
        'EmailId',
        'Website',
        'AddressLine1',
        'AddressLine2',
        'StateId',
        'CityName',
        'PostalCode',
        'InstituteLogo',
        'IsActive',
    ];

}
