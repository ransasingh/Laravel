<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Feereceipt extends Model
{
    use HasFactory;
    use SoftDeletes;

    protected $table = 'feereceipt';

    protected $fillable = [
        'StudentId',
        'FeeStructureId',
        'ReceiptSrNo',
        'ReceiptNo',
        'FinancialYearId',
        'ReceiptDate',
        'IsActive',
        'PaymentMode',
        'ChequeNoOrUtr',
        'ChequeDate',
        'BankId',
        'FilePath',
    ];


    public function details()
    {
        return $this->hasMany(FeeReceiptDetail::class, 'FeeReceiptId', 'id');
    }
}
