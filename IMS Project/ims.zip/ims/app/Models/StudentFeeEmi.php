<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StudentFeeEmi extends Model
{
    use HasFactory;

    protected $table = 'studentfeeemi';

    protected $fillable = [
        'InstallmentAmount',
        'InstallmentDueDate',
        'FeeStructureId',
        'StudentId',
        'IsActive',
        'createdBy',
        'updatedBy',
    ];
}
