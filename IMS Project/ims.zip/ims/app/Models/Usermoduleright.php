<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Usermoduleright extends Model
{
    use HasFactory;
    protected $table = 'usermoduleright';

    public $fillable = [
        'UserId',
        'ModuleId',
        'created_at',
        'updated_at',
    ];
}

