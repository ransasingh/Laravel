<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Student extends Model
{
    use HasFactory;
    use SoftDeletes;

    protected $table = 'student';

    protected $fillable = [
        'FirstName',
        'LastName',
        'MobileNumber',
        'EmailId',
        'AddressLine1',
        'StudentCode',
        'ProfileImage',
        'SignImage',
        'UserId',
        'TotalFeeAmount',
    ];


    public function studentCourses()
    {
        return $this->hasMany(StudentCourse::class, 'StudentId');
    }
    
}
