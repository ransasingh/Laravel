<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StudentBatchExtension extends Model
{
    use HasFactory;
    protected $table = 'batchextension';

    protected $fillable = [
        'BatchId',
        'NewDate',
        'Remarks',
        'IsApproved',
        'VerifyBy',
        'VerifyAt',
        'IsActive',
        'createdBy',
        'updatedBy',
    ];
}
