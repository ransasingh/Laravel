<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class InstituteBranch extends Model
{
    use HasFactory;
    use SoftDeletes;

    protected $table = 'institutebranch';

    protected $fillable = [
        'Name', 'BranchCode', 'InstituteId', 'MobileNumber', 'EmailId', 'Website', 'AddressLine1', 'StateId', 'CityName', 'PostalCode',
    ];
}
