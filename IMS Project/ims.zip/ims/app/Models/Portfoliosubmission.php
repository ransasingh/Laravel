<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Portfoliosubmission extends Model
{
    use HasFactory;
    protected $table = 'portfoliosubmission';

    protected $fillable = [
        'PortfolioFile',
        'StudentId',
        'FacultyId',
        'SubjectId',
        'createdBy',
        'updatedBy',
        'ApprovedAt',
        'ApprovedBy',
        'IsApproved',
        'SubmissionDate',
    ];
}
