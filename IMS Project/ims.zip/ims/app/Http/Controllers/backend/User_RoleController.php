<?php

namespace App\Http\Controllers\backend;

use App\Models\User_role;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Validator;

class User_RoleController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $data = User_role::all();
        return view('backend.role.list', compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('backend.role.add');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request, User_role $user_role)
    {

        $validator = Validator::make(request()->all(), [
            'RoleName' => 'required|max:50|unique:userrole,RoleName',
            'Code' => 'required|max:50|unique:userrole,Code',
            'IsActive' => 'required',
        ], [
            'Code.required' => 'The role code field is required.',
        ]);
        if ($validator->fails()) {
            return redirect()->route('role.add')
                ->withErrors($validator)
                ->withInput();
        } else {
            $user_id = Auth::id();
            $user_role->RoleName = ucwords($request->RoleName);
            $user_role->Code  = ucwords($request->Code);
            $user_role->CanCreate = $request->CanCreate;
            $user_role->CanUpdate = $request->CanUpdate;
            $user_role->CanDelete = $request->CanDelete;
            $user_role->CanView = $request->CanView;
            $user_role->IsActive = $request->IsActive;
            $user_role->createdBy = $user_id;
            $user_role->save();
            return redirect()->route('role.listing')->with('success', 'Role has been created successfully.');
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(User_role $user_role)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(User_role $user_role, $id)
    {
        $data = User_role::find($id);
        return view('backend.role.edit', compact('data'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, User_role $user_role, $id)
    {
        $data = User_role::find($id);
        $validator = Validator::make(request()->all(), [
            'RoleName' => 'required|max:50|unique:userrole,RoleName,' . $id,
            'Code' => 'required|max:50|unique:userrole,Code,' . $id,
            'IsActive' => 'required',
        ], [
            'Code.required' => 'The role code field is required.',
        ]);
       
        if ($validator->fails()) {
            return redirect()->route('role.edit', ['id' => $id])
                ->withErrors($validator)
                ->withInput();
        } else {
            $user_id = Auth::id();
            $data->RoleName = ucwords($request->RoleName);
            $data->Code  = ucwords($request->Code);
            $data->CanCreate = $request->CanCreate;
            $data->CanUpdate = $request->CanUpdate;
            $data->CanDelete = $request->CanDelete;
            $data->CanView = $request->CanView;
            $data->IsActive = $request->IsActive;
            $data->updatedBy = $user_id;
            $data->save();
            return redirect()->route('role.listing')->with('success', 'Role has been updated successfully.');
        }
    }

     /**
     * Remove the specified resource from storage.
     */
    public function trash(User_role $user_role, $id)
    {
        $data = User_role::find($id);
        if (!$data) {
            abort(404);
        }
        if ($data->IsActive == 0) {
            $data->delete();
            return redirect()->route('role.listing')->with('success', 'Role has been trashed successfully.');
        } else {
            return redirect()->route('role.listing')->with('error', 'Invalid status on deletion,Kindly do Status make Inactive.');
        }
    }

    /**
     * trashview the specified resource from storage.
     */
    public function trashview(User_role $user_role)
    {
        $data = User_role::onlyTrashed()->latest()->get();
        return view('backend.role.trash', compact('data'));
    }

    /**
     * restore the specified resource .
     */
    public function restore(User_role $user_role, $id)
    {
        // Restore a soft deleted 
        $data = User_role::withTrashed()->find($id);
        $data->restore();
        return redirect()->route('role.listing')->with('success', 'Role has been restored successfully.');
    }
    /**
     * trash the specified resource database permanent.
     */
    public function destroy(User_role $user_role, $id)
    {
        // Permanently delete a soft deleted 
        $data = User_role::withTrashed()->find($id);
        $data->forceDelete();
        return redirect()->route('role.trashview')->with('success', 'Role has been permanent delete successfully.');
    }
}
