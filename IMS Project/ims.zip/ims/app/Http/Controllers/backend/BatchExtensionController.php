<?php

namespace App\Http\Controllers\backend;

use App\Http\Controllers\Controller;
use App\Models\Batch;
use App\Models\StudentBatchExtension;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Validator;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class BatchExtensionController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {

        $data = Batch::join('faculty', 'batch.FacultyId', '=', 'faculty.id')
            ->select('batch.*', 'faculty.FirstName', 'faculty.LastName', 'faculty.UserId', 'faculty.BranchId')
            ->where('IsApproved', 0)
            ->where('faculty.BranchId', session('BranchId'));

        if (Auth::user()->RoleId == 1) {
            $data = $data->get();
        } elseif (Auth::user()->RoleId == 3) {
            // If role is 3, show only data where the faculty ID matches the authenticated user's ID
            $data = $data->where('UserId', Auth::id())
                ->where('BranchId', session('BranchId'))
                ->get();
        }
        return view('backend.batchextension.list', compact('data'));
    }

    /**
     * Display a listing of the resource with apporaval table.
     */
    public function batchextensionapproval()
    {
        $data = Batch::join('faculty', 'batch.FacultyId', '=', 'faculty.id')
            ->join('batchextension', 'batch.id', '=', 'batchextension.BatchId')
            ->select('batch.*', 'faculty.FirstName', 'faculty.LastName', 'batchextension.NewDate', 'batchextension.Remarks')
            ->where('batchextension.IsApproved', 0)
            ->where('batchextension.IsActive', 0)
            ->where('faculty.BranchId', session('BranchId'))
            ->get();
        return view('backend.batchextensionapproval.list', compact('data'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(StudentBatchExtension $studentBatchExtension)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(StudentBatchExtension $studentBatchExtension, $id)
    {
        $data = DB::table('batch')
            ->join('faculty', 'batch.FacultyId', '=', 'faculty.id')
            ->select('batch.*', 'faculty.UserId')
            ->where('batch.id', $id)
            ->first();

        // Check authorization based on user role
        if (Auth::user()->RoleId == 1) {
            // If role is 1, allow access to edit the batch
        } elseif (Auth::user()->RoleId == 3) {
            $facultyUserId = $data->UserId ?? null;
            if ($facultyUserId != Auth::id()) {
                // Unauthorized access - handle accordingly (e.g., show error message or redirect)
                abort(403, 'Unauthorized access');
            }
        }
        return view('backend.batchextension.edit', compact('data'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, StudentBatchExtension $studentBatchExtension, $id)
    {
        $validator = Validator::make(request()->all(), [
            'NewDate' => 'required|date',
        ]);
        if ($validator->fails()) {
            return redirect()->back()
                ->withErrors($validator)
                ->withInput();
        } else {
            $user_id = Auth::id();
            $studentBatchExtension->BatchId = $request->BatchId;
            $studentBatchExtension->NewDate = $request->NewDate;
            $studentBatchExtension->Remarks = $request->Remarks;
            $studentBatchExtension->IsApproved = '0';
            $studentBatchExtension->IsActive = '0';
            $studentBatchExtension->createdBy = $user_id;
            $studentBatchExtension->save();
            return redirect()->route('batchextension.listing')->with('success', 'Batch Extension has been created successfully.');
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(StudentBatchExtension $studentBatchExtension)
    {
        //
    }

    /**
     * approve the specified resource from storage.
     */
    public function approve(StudentBatchExtension $studentBatchExtension, $id)
    {
        $currentDateTime = Carbon::now();
        $user_id = Auth::id();
        // Step 1: Update the IsApproved field in the StudentBatchExtension table
        StudentBatchExtension::where('BatchId', $id)->update(['IsApproved' => 1, 'IsActive' => 1, 'VerifyBy' => $user_id, 'VerifyAt' => $currentDateTime, 'updatedBy' => $user_id]);
        // Step 2: Get the NewDate value from the BatchExtension table
        $newDate = StudentBatchExtension::where('BatchId', $id)->value('NewDate');
        // Step 3: Update the ToDate column in the Batch table
        Batch::where('id', $id)->update(['ToDate' => $newDate]);
        return redirect()->back()->with('success', 'Batch Extension has been Approved successfully.');
    }
    /**
     * cancel the specified resource from storage.
     */
    public function cancel(StudentBatchExtension $studentBatchExtension, $id)
    {
        $currentDateTime = Carbon::now();
        $user_id = Auth::id();
        // $deletedRows = StudentBatchExtension::where('batchid', $id)->delete();
        // Step 1: Update the IsApproved field in the StudentBatchExtension table
        StudentBatchExtension::where('BatchId', $id)->update(['IsApproved' => 0, 'IsActive' => 1, 'VerifyBy' => $user_id, 'VerifyAt' => $currentDateTime, 'updatedBy' => $user_id]);
        return redirect()->back()->with('success', 'Batch Extension cancelled successfully');
    }
}
