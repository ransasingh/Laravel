<?php

namespace App\Http\Controllers\backend;

use App\Http\Controllers\Controller;
use App\Models\Course;
use App\Models\Student;
use App\Models\State;
use App\Models\Institute;
use App\Models\CourseSubject;
use App\Models\StudentCourse;
use App\Models\Academicyear;
use App\Models\Batch;
use App\Models\Faculty;
use App\Models\User;
use App\Models\UserBranchRight;
use App\Models\Portfoliosubmission;
use App\Models\Usermoduleright;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Validator;


class StudentController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $data = Student::join('state', 'student.StateId', '=', 'state.id')
            ->join('course', 'student.CourseId', '=', 'course.id')
            ->select('student.*', 'state.Name as state_name', 'course.Name as course_name')
            ->where('BranchId', session('BranchId'))
            ->get();

        return view('backend.student.list', compact('data'));
    }
    /**
     * change password for student
     */
    public function changepassword()
    {
        $user = auth()->user();
        return view('backend.student.changepassword', compact('user'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $institutes = Institute::where('IsActive', '1')->get();
        $institutesid = $institutes[0]['id'];
        $states = State::where('IsActive', '1')->get();
        $courses = Course::where('IsActive', '1')->get();
        $faculties = Faculty::where('IsActive', '1')->get();
        return view('backend.student.add', compact('institutesid', 'states', 'courses', 'faculties'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {

        $validator = Validator::make(request()->all(), [
            'FirstName' => 'required|string',
            'LastName' => 'required|string',
            'MobileNumber' => 'required|numeric|digits:10|unique:student,MobileNumber',
            'ParentMobile' => 'required|numeric|different:MobileNumber|digits:10',
            'EmailId' => 'required|email|max:255|unique:sysuser,email',
            'password' => [
                'required',
                'string',
                'min:8',
                'confirmed',
                'regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]/',
            ],
            'password_confirmation' => 'required|string|min:8|same:password',

            'AddressLine1' => 'required',
            'StateId' => 'required|integer',
            'CityName' => 'required|string',
            'PostalCode' => 'required',
            'PrAddressLine1' => 'required',
            'PrStateId' => 'required|integer',
            'PrCityName' => 'required',
            'EmergencyContactNumber' => 'required|numeric|digits:10',
            'LastEducationQualification' => 'required',
            'BloodGroup' => 'required',
            'ModeOfCoaching' => 'required',
            'Status' => 'required',
            'DOB' => 'required|date',
            'AdmissionDate' => 'required|date',
            'CourseId' => 'required',
            'FacultyId' => 'required',
            'BatchFromMnt' => 'required|date_format:H:i',
            'BatchToMnt' => 'required|date_format:H:i|after_or_equal:BatchFromMnt',
            'ProfileImage' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
            'SignImage' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',

        ], [
            'EmailId.required' => 'Email is required',
            'EmailId.unique' => 'The provided email address is already in use',
            'FirstName.required' => 'First name is required',
            'LastName.required' => 'Last name is required',
            'MobileNumber.required' => 'Mobile number is required',
            'MobileNumber.numeric' => 'Mobile number must be numeric',
            'MobileNumber.digits' => 'Mobile number must be 10 digits',
            'password.regex' => 'The password must contain at least one lowercase letter, one uppercase letter, one digit, and one special character.',

            'AddressLine1.required' => 'Address is required',
            'PrAddressLine1.required' => 'Permanent address is required',
            'StateId.required' => 'Select state.',
            'PrStateId.required' => 'Select state.',
            'DOB.required' => 'Date of Birth is required.',
            'PrCityName.required' => 'Permanent city name is required.',

            'BatchToMnt.after_or_equal' => 'Batch end time must be equal to or after the start time',

            'ProfileImage.nullable' => 'Profile image must be an image',
            'ProfileImage.image' => 'Profile image must be a valid image file',
            'ProfileImage.mimes' => 'Profile image must be in one of the formats: jpeg, png, jpg, gif',
            'ProfileImage.max' => 'Profile image cannot exceed 2048 kilobytes',

            'SignImage.nullable' => 'Signature image must be an image',
            'SignImage.image' => 'Signature image must be a valid image file',
            'SignImage.mimes' => 'Signature image must be in one of the formats: jpeg, png, jpg, gif',
            'SignImage.max' => 'Signature image cannot exceed 2048 kilobytes',
        ]);

        if ($validator->fails()) {
            return redirect()->route('student.add')
                ->withErrors($validator)
                ->withInput();
        } else {
            DB::beginTransaction();
            try {
                $user_id = Auth::id();
                $user = new User;
                $user->name = $request->FirstName . " " . $request->LastName;
                $user->email   =  $request->EmailId;
                $user->password = bcrypt($request->password);
                $user->IsActive = '1';
                $user->RoleId = '4';
                $user->InstituteId = $request->InstituteId;
                $user->createdBy = $user_id;
                $user->save();

                $userBranchRight = new UserBranchRight;
                $userBranchRight->UserId  = $user->id;
                $userBranchRight->BranchId = session('BranchId');
                $userBranchRight->createdBy = $user_id;
                $userBranchRight->save();

                $usermoduleright = new Usermoduleright;
                $usermoduleright->UserId  = $user->id;
                $usermoduleright->ModuleId  = '1';
                $usermoduleright->save();

                $student = new Student;
                if ($request->hasFile('ProfileImage')) {
                    $ProfileImage = time() . '.' . $request->ProfileImage->getClientOriginalExtension();
                    $request->ProfileImage->move(public_path('uploads/student/profile'), $ProfileImage);
                    $student->ProfileImage = $ProfileImage;
                } else {
                    $student->ProfileImage = 'default.jpg';
                }
                if ($request->hasFile('SignImage')) {
                    $SignImage = time() . '.' . $request->SignImage->getClientOriginalExtension();
                    $request->SignImage->move(public_path('uploads/student/signature'), $SignImage);
                    $student->SignImage = $SignImage;
                } else {
                    $student->SignImage = 'sign.jpg';
                }

                $student->FirstName = ucwords($request->FirstName);
                $student->LastName =  ucwords($request->LastName);
                $student->MobileNumber = $request->MobileNumber;
                $student->EmailId = $request->EmailId;
                $student->AddressLine1 = $request->AddressLine1;
                $student->AddressLine2 = $request->AddressLine2;
                $student->StateId = $request->StateId;
                $student->CityName = $request->CityName;
                $student->PostalCode = $request->PostalCode;
                $student->InstituteId = $request->InstituteId;
                $student->UserId = $user->id;
                $student->createdBy = $user_id;
                $student->ParentMobile = $request->ParentMobile;
                $student->PrAddressLine1 = $request->PrAddressLine1;
                $student->PrAddressLine2 = $request->PrAddressLine2;
                $student->PrStateId = $request->PrStateId;
                $student->PrCityName = $request->PrCityName;
                $student->EmergencyContactNumber = $request->EmergencyContactNumber;
                $student->LastEducationQualification = $request->LastEducationQualification;
                $student->BloodGroup = $request->BloodGroup;
                $student->ModeOfCoaching = $request->ModeOfCoaching;
                $student->Status = $request->Status;
                $student->DOB = $request->DOB;
                $student->AdmissionDate = $request->AdmissionDate;
                $student->FacultyId = $request->FacultyId;
                $student->BatchFromMnt = $request->BatchFromMnt;
                $student->BatchToMnt = $request->BatchToMnt;
                $student->IsActive = $request->IsActive;
                $student->ShowFee = $request->ShowFee;
                $student->PossibilityForUpgradation = $request->PossibilityForUpgradation;
                $student->CourseId = $request->CourseId;
                $student->Description = $request->Description;
                $student->BranchId = session('BranchId');
                $student->save();

                $currentMonth = now()->format('M');
                $currentYear = now()->format('Y');
                // Update the business data
                Student::where('id', $student->id)->update([
                    'StudentCode' => 'Stu-' . $currentMonth . '-' . $currentYear . '-' . $student->id,
                ]);

                $courseSubjects = CourseSubject::where('CourseId', $student->CourseId)->get();
                $academicsName = Academicyear::where('IsCurrent', '1')->where('IsActive', '1')->latest()->value('Name');
                foreach ($courseSubjects as $courseSubject) {
                    $studentCourse = new StudentCourse;
                    $studentCourse->StudentId = $student->id;
                    $studentCourse->SubjectId = $courseSubject->SubjectId;
                    $studentCourse->AcademicYearId = $academicsName;
                    $studentCourse->IsExraSubject = '0';
                    $studentCourse->IsActive = '1';
                    $studentCourse->createdBy = $user_id;
                    $studentCourse->save();
                }

                DB::table('student')
                    ->join('feestructure', 'student.CourseId', '=', 'feestructure.CourseId')
                    ->join('feestructuremap', 'feestructure.id', '=', 'feestructuremap.FeeStructureId')
                    ->where('student.CourseId', $student->CourseId)
                    ->where('student.id', $student->id)
                    ->groupBy('student.id', 'feestructuremap.FeeStructureId')
                    ->update(['student.TotalFeeAmount' => DB::raw('(SELECT SUM(feestructuremap.Amount) FROM feestructuremap WHERE feestructuremap.FeeStructureId = feestructure.id)')]);

                DB::commit();
                return redirect()->route('student.listing')->with('success', 'student has been created successfully.');
            } catch (\Exception $e) {
                DB::rollBack();
                return redirect()->back()->withInput()->withErrors(['error' => $e->getMessage()]);
            }
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(Student $student)
    {

        $userId = auth()->id();
        // Retrieve the branch ID associated with the user
        $branchId = UserBranchRight::where('UserId', $userId)->value('BranchId');
        // Check if the branch ID is not null and matches the session's BranchId
        if ($branchId !== null && session('BranchId') == $branchId) {
            $record = Student::where('UserId', $userId)
                ->join('state', 'student.StateId', '=', 'state.id')
                ->select('student.*', 'state.Name as state_name')
                ->first();
            return view('backend.student.show', compact('record'));
        }
        abort(403);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Student $student, $id)
    {
        $data = Student::find($id);
        $states = State::where('IsActive', '1')->get();
        $courses = Course::where('IsActive', '1')->get();
        $faculties = Faculty::where('IsActive', '1')->get();
        return view('backend.student.edit', compact('data', 'states', 'courses', 'faculties'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Student $student, $id)
    {
        $data = Student::find($id);
        $validator = Validator::make(request()->all(), [
            'FirstName' => 'required|string',
            'LastName' => 'required|string',
            'MobileNumber' => 'required|numeric|digits:10|unique:student,MobileNumber,' . $id,
            'ParentMobile' => 'required|numeric|different:MobileNumber|digits:10',
            'EmailId' => 'required|email|max:255|unique:sysuser,email,' . $data->UserId,
            'AddressLine1' => 'required',
            'StateId' => 'required|integer',
            'CityName' => 'required|string',
            'PostalCode' => 'required',
            'PrAddressLine1' => 'required',
            'PrStateId' => 'required|integer',
            'PrCityName' => 'required',
            'EmergencyContactNumber' => 'required|numeric|digits:10',
            'LastEducationQualification' => 'required',
            'BloodGroup' => 'required',
            'ModeOfCoaching' => 'required',
            'Status' => 'required',
            'DOB' => 'required|date',
            'AdmissionDate' => 'required|date',
            'CourseId' => 'required',
            'FacultyId' => 'required',
            'BatchFromMnt' => 'required|date_format:H:i',
            'BatchToMnt' => 'required|date_format:H:i|after_or_equal:BatchFromMnt',
            'ProfileImage' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
            'SignImage' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',

        ], [
            'EmailId.required' => 'Email is required',
            'EmailId.unique' => 'The provided email address is already in use',
            'FirstName.required' => 'First name is required',
            'LastName.required' => 'Last name is required',
            'MobileNumber.required' => 'Mobile number is required',
            'MobileNumber.numeric' => 'Mobile number must be numeric',
            'MobileNumber.digits' => 'Mobile number must be 10 digits',
            'password.regex' => 'The password must contain at least one lowercase letter, one uppercase letter, one digit, and one special character.',

            'AddressLine1.required' => 'Address is required',
            'PrAddressLine1.required' => 'Permanent address is required',
            'StateId.required' => 'Select state.',
            'PrStateId.required' => 'Select state.',
            'DOB.required' => 'Date of Birth is required.',
            'PrCityName.required' => 'Permanent city name is required.',

            'BatchToMnt.after_or_equal' => 'Batch end time must be equal to or after the start time',

            'ProfileImage.nullable' => 'Profile image must be an image',
            'ProfileImage.image' => 'Profile image must be a valid image file',
            'ProfileImage.mimes' => 'Profile image must be in one of the formats: jpeg, png, jpg, gif',
            'ProfileImage.max' => 'Profile image cannot exceed 2048 kilobytes',

            'SignImage.nullable' => 'Signature image must be an image',
            'SignImage.image' => 'Signature image must be a valid image file',
            'SignImage.mimes' => 'Signature image must be in one of the formats: jpeg, png, jpg, gif',
            'SignImage.max' => 'Signature image cannot exceed 2048 kilobytes',
        ]);

        if ($validator->fails()) {
            return redirect()->route('student.edit', ['id' => $id])
                ->withErrors($validator)
                ->withInput();
        } else {
            DB::beginTransaction();
            try {
                $user_id = Auth::id();
                $user = User::where('id', $data->UserId)->first();
                if ($user) {
                    $user->name = $request->FirstName . " " . $request->LastName;
                    $user->email   =  $request->EmailId;
                    $user->IsActive = '1';
                    $user->RoleId = '4';
                    $user->InstituteId = $request->InstituteId;
                    $user->updatedBy = $user_id;
                    $user->save();
                }

                if ($request->hasFile('ProfileImage')) {
                    $ProfileImage = time() . '.' . $request->ProfileImage->getClientOriginalExtension();
                    $request->ProfileImage->move(public_path('uploads/student/profile'), $ProfileImage);
                    $data->ProfileImage = $ProfileImage;
                }
                if ($request->hasFile('SignImage')) {
                    $SignImage = time() . '.' . $request->SignImage->getClientOriginalExtension();
                    $request->SignImage->move(public_path('uploads/student/signature'), $SignImage);
                    $data->SignImage = $SignImage;
                }
                $data->FirstName = ucwords($request->FirstName);
                $data->LastName = ucwords($request->LastName);
                $data->MobileNumber = $request->MobileNumber;
                $data->EmailId = $request->EmailId;
                $data->AddressLine1 = $request->AddressLine1;
                $data->AddressLine2 = $request->AddressLine2;
                $data->StateId = $request->StateId;
                $data->CityName = $request->CityName;
                $data->PostalCode = $request->PostalCode;
                $data->InstituteId = $request->InstituteId;
                $data->UserId = $request->UserId;
                $data->updatedBy = $user_id;
                $data->ParentMobile = $request->ParentMobile;
                $data->PrAddressLine1 = $request->PrAddressLine1;
                $data->PrAddressLine2 = $request->PrAddressLine2;
                $data->PrStateId = $request->PrStateId;
                $data->PrCityName = $request->PrCityName;
                $data->EmergencyContactNumber = $request->EmergencyContactNumber;
                $data->LastEducationQualification = $request->LastEducationQualification;
                $data->BloodGroup = $request->BloodGroup;
                $data->ModeOfCoaching = $request->ModeOfCoaching;
                $data->Status = $request->Status;
                $data->DOB = $request->DOB;
                $data->AdmissionDate = $request->AdmissionDate;
                $data->FacultyId = $request->FacultyId;
                $data->BatchFromMnt = $request->BatchFromMnt;
                $data->BatchToMnt = $request->BatchToMnt;
                $data->IsActive = $request->IsActive;
                $data->ShowFee = $request->ShowFee;
                $data->PossibilityForUpgradation = $request->PossibilityForUpgradation;
                $data->CourseId = $request->CourseId;
                $data->Description = $request->Description;
                $data->BranchId = $request->BranchId;
                $data->save();

                // Start Student code
                $currentMonth = now()->format('M');
                $currentYear = now()->format('Y');
                // Update the business data
                Student::where('id', $data->id)->update([
                    'StudentCode' => 'Stu-' . $currentMonth . '-' . $currentYear . '-' . $data->id,
                ]);
                // End Student code

                // Start Student course
                $existingRecords = StudentCourse::where('StudentId', $data->id)->get();
                $oldSubjectIds = $existingRecords->pluck('SubjectId')->toArray();
                $newSubjectIds = CourseSubject::where('CourseId', $data->CourseId)->pluck('SubjectId')->toArray();

                $subjectsToAdd = array_diff($newSubjectIds, $oldSubjectIds);
                $subjectsToRemove = array_diff($oldSubjectIds, $newSubjectIds);

                // // Remove subjects that are no longer in the course
                // if (!empty($subjectsToRemove)) {
                //     StudentCourse::where('StudentId', $data->id)
                //         ->whereIn('SubjectId', $subjectsToRemove)
                //         ->forceDelete();
                // }

                $academicsName = Academicyear::where('IsCurrent', '1')->where('IsActive', '1')->latest()->value('Name');
                foreach ($subjectsToAdd as $newSubjectId) {
                    // Insert a new record
                    $studentCourse = new StudentCourse;
                    $studentCourse->StudentId = $data->id;
                    $studentCourse->SubjectId = $newSubjectId;
                    $studentCourse->AcademicYearId = $academicsName;
                    $studentCourse->IsExraSubject = '0';
                    $studentCourse->IsActive = '1';
                    $studentCourse->updatedBy = $user_id;
                    $studentCourse->save();
                }
                //End Student course

                DB::table('student')
                    ->join('feestructure', 'student.CourseId', '=', 'feestructure.CourseId')
                    ->join('feestructuremap', 'feestructure.id', '=', 'feestructuremap.FeeStructureId')
                    ->where('student.CourseId', $data->CourseId)
                    ->where('student.id', $data->id)
                    ->groupBy('student.id', 'feestructuremap.FeeStructureId') // Group by StudentId and FeeStructureId
                    ->update(['student.TotalFeeAmount' => DB::raw('(SELECT SUM(feestructuremap.Amount) FROM feestructuremap WHERE feestructuremap.FeeStructureId = feestructure.id)')]);


                DB::commit();
                return redirect()->route('student.listing')->with('success', 'student has been updated successfully.');
            } catch (\Exception $e) {
                DB::rollBack();
                return redirect()->back()->withInput()->withErrors(['error' => $e->getMessage()]);
            }
        }
    }

    public function deleteImage(Request $request, $id)
    {
        $data = Student::find($id);
        $imageType = $request->input('imageType');

        // Logic to remove the specified image type
        if ($imageType == 'ProfileImage') {
            $oldImagePath = public_path('uploads/student/profile/' . $data->ProfileImage);
            $data->update(['ProfileImage' => null]);
        } elseif ($imageType == 'SignImage') {
            $oldImagePath = public_path('uploads/student/signature/' . $data->SignImage);
            $data->update(['SignImage' => null]);
        } else {
            // Handle the case where imageType is not recognized
            return redirect()->back()->with('error', 'Invalid image type.');
        }

        // If the file exists, delete it
        if (file_exists($oldImagePath)) {
            unlink($oldImagePath);
            return redirect()->back()->with('success', 'Image deleted successfully.');
        }
        // If the file doesn't exist, update the database record anyway
        return redirect()->back()->with('error', 'Image not found.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function trash(Student $student, $id)
    {
        $data = Student::find($id);
        if (!$data) {
            abort(404);
        }
        if ($data->IsActive == 0) {
            $data->delete();
            return redirect()->route('student.listing')->with('success', 'student has been trashed successfully.');
        } else {
            return redirect()->route('student.listing')->with('error', 'Invalid status on deletion,Kindly do Status make Inactive.');
        }
    }

    /**
     * trashview the specified resource from storage.
     */
    public function trashview(Student $student)
    {
        $data = Student::onlyTrashed()
            ->join('state', 'student.StateId', '=', 'state.id')
            ->select('student.*', 'state.Name as state_name')
            ->get();
        return view('backend.student.trash', compact('data'));
    }

    /**
     * restore the specified resource .
     */
    public function restore(Student $student, $id)
    {
        // Restore a soft deleted 
        $data = Student::withTrashed()->find($id);
        $data->restore();
        return redirect()->route('student.listing')->with('success', 'student has been restored successfully.');
    }
    /**
     * trash the specified resource database permanent.
     */
    public function destroy(Student $student, $id)
    {
        DB::beginTransaction();

        try {
            // Permanently delete a soft deleted student
            $data = Student::withTrashed()->find($id);

            // Delete associated student courses
            $data->studentCourses()->forceDelete();

            // Delete associated images if they exist
            if ($data->ProfileImage != null && $data->ProfileImage != "default.jpg") {
                $this->deleteImg('uploads/student/profile/' . $data->ProfileImage);
            }
            if ($data->SignImage != null && $data->SignImage != "sign.jpg") {
                $this->deleteImg('uploads/student/signature/' . $data->SignImage);
            }

            // Fetch associated user data by user_id
            $user = User::find($data->UserId);

            // Delete associated records from userbranchright table
            DB::table('userbranchright')->where('UserId', $data->UserId)->delete();

            // Delete associated records from usermoduleright table
            DB::table('usermoduleright')->where('UserId', $data->UserId)->delete();

            // Delete the user if found
            if ($user) {
                $user->forceDelete();
            }

            // Finally, permanently delete the student record
            $data->forceDelete();

            DB::commit();

            return redirect()->route('student.trashview')->with('success', 'student has been permanent delete successfully.');
        } catch (\Exception $e) {
            DB::rollback();
            return redirect()->route('student.trashview')->with('error', 'Failed to delete student and associated data. Error: ' . $e->getMessage());
        }
    }

    // Helper function to delete an image
    private function deleteImg($path)
    {
        // Get the full path to the public directory
        $publicPath = public_path();

        // Combine the public path with the relative image path
        $imagePath = $publicPath . '/' . $path;

        // Check if the file exists before attempting to delete
        if (file_exists($imagePath)) {
            unlink($imagePath);
        }
    }

    public function updateTotalFee(Request $request, Student $student)
    {

        $request->validate([
            'TotalFeeAmount' => 'required|numeric|min:1',
        ]);
        $studentId = $request->input('StudentId');

        $student = Student::find($studentId);

        if ($student) {
            $student->update([
                'TotalFeeAmount' => $request->input('TotalFeeAmount')
            ]);

            return redirect()->back()->with('success', 'Fee has been updated successfully.');
        } else {
            return redirect()->back()->with('error', 'Student not found.');
        }
    }


    public function updatePassword(Request $request)
    {
        $request->validate([
            'password' => [
                'required',
                'string',
                'min:8',
                'confirmed',
                'regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]/',
            ],
            'password_confirmation' => 'required|string|min:8|same:password',
        ], [
            'password.required' => 'The password field is required.',
            'password.string' => 'The password must be a string.',
            'password.min' => 'The password must be at least :min characters.',
            'password.confirmed' => 'The password confirmation does not match.',
            'password.regex' => 'The password must contain at least one uppercase letter, one lowercase letter, one digit, and one special character.',
            'password_confirmation.required' => 'The password confirmation field is required.',
            'password_confirmation.string' => 'The password confirmation must be a string.',
            'password_confirmation.min' => 'The password confirmation must be at least :min characters.',
            'password_confirmation.same' => 'The password confirmation must match the password.',
        ]);
        $user = User::find($request->userid);
        if (!$user) {
            return redirect()->back()->with('error', 'User not found.');
        }

        $user->password = bcrypt($request->password);
        $user->save();

        return redirect()->back()->with('success', 'Password updated successfully.');
    }


    public function calender(Request $request)
    {
        // Get the authenticated user's ID
        $authId = Auth::id();

        // Fetch the student ID corresponding to the authenticated user
        $studentId = Student::where('UserId', $authId)->value('id');

        // Handle case where student ID is not found for the authenticated user
        if (!$studentId) {
            return redirect()->back()->with('error', 'Student not found for the authenticated user.');
        }

        $now = now()->toDateString();

        $allbatches = DB::table('batch')
            ->join('studentbatchassign', 'studentbatchassign.BatchDetailId', '=', 'batch.id')
            ->join('batchdetail', 'batch.id', '=', 'batchdetail.BatchId')
            ->where('batch.IsCompleted', 0)
            ->where('studentbatchassign.StudentId', $studentId)
            ->where('studentbatchassign.IsCompleted', 0)
            ->whereDate('batch.FromDate', '<=', $now)
            ->whereDate('batch.ToDate', '>=', $now)
            ->select(
                'batch.id',
                'batch.Name',
                'batch.FromDate',
                'batch.StartTimeInMinutes',
                'batch.EndTimeInMinutes',
                'batch.ToDate',
                'batchdetail.BatchDay'
            )
            ->get();

        // Initialize array to store organized batches
        $batches = [];

        // Iterate over each batch
        foreach ($allbatches as $batch) {
            $startDate = Carbon::parse($batch->FromDate);
            $endDate = Carbon::parse($batch->ToDate);
            $daysDiff = $endDate->diffInDays($startDate);

            for ($i = 0; $i <= $daysDiff; $i++) {
                $date = $startDate->copy()->addDays($i);
                $dayOfWeek = $date->dayOfWeek;

                if (strpos($batch->BatchDay, (string) $dayOfWeek) !== false) {
                    // Query attendance record for the current date
                    $attendanceRecord = DB::table('studentattandance')
                        ->where('BatchDetailId', $batch->id)
                        ->where('StudentId', $studentId)
                        ->whereDate('ForDate', $date->toDateString())
                        ->first();

                    // Determine the attendance status
                    if ($attendanceRecord === null) {
                        $attendanceStatusText = 'No attendance record';
                    } else {
                        $attendanceStatus = $attendanceRecord->DayAttandance;
                        if ($attendanceStatus === 1) {
                            $attendanceStatusText = 'Present';
                        } elseif ($attendanceStatus === 0) {
                            $attendanceStatusText = 'Absent';
                        } elseif ($attendanceStatus === 2) {
                            $attendanceStatusText = 'Late';
                        }
                    }

                    $batches[$date->format('Y-m-d')][] = [
                        'BatchId' => $batch->id,
                        'Name' => $batch->Name,
                        'FromDate' => $batch->FromDate,
                        'ToDate' => $batch->ToDate,
                        'AttendanceStatus' => $attendanceStatusText ?? 'No attendance record',
                        'StartTimeInMinutes' => $batch->StartTimeInMinutes,
                        'EndTimeInMinutes' => $batch->EndTimeInMinutes,
                    ];
                }
            }
        }

        // Pass the $batches data to the frontend for rendering in the calendar
        return view('backend.student.calender', compact('batches'));
    }


    public function scalender(Request $request)
    {
        $now = now()->toDateString();
        $allbatches = DB::table('batch')
            ->join('studentbatchassign', 'studentbatchassign.BatchDetailId', '=', 'batch.id')
            ->join('batchdetail', 'batch.id', '=', 'batchdetail.BatchId')
            ->where('batch.IsCompleted', 0)
            ->where('studentbatchassign.StudentId', $request->id)
            ->where('studentbatchassign.IsCompleted', 0)
            ->whereDate('batch.FromDate', '<=', $now)
            ->whereDate('batch.ToDate', '>=', $now)
            ->select(
                'batch.id',
                'batch.Name',
                'batch.FromDate',
                'batch.StartTimeInMinutes',
                'batch.EndTimeInMinutes',
                'batch.ToDate',
                'batchdetail.BatchDay'
            )
            ->get();

        // Initialize array to store organized batches
        $batches = [];

        // Iterate over each batch
        foreach ($allbatches as $batch) {
            $startDate = Carbon::parse($batch->FromDate);
            $endDate = Carbon::parse($batch->ToDate);
            $daysDiff = $endDate->diffInDays($startDate);

            for ($i = 0; $i <= $daysDiff; $i++) {
                $date = $startDate->copy()->addDays($i);
                $dayOfWeek = $date->dayOfWeek;

                if (strpos($batch->BatchDay, (string) $dayOfWeek) !== false) {
                    // Query attendance record for the current date
                    $attendanceRecord = DB::table('studentattandance')
                        ->where('BatchDetailId', $batch->id)
                        ->where('StudentId', $request->id)
                        ->whereDate('ForDate', $date->toDateString())
                        ->first();

                    // Determine the attendance status
                    if ($attendanceRecord === null) {
                        $attendanceStatusText = 'No attendance record';
                    } else {
                        $attendanceStatus = $attendanceRecord->DayAttandance;
                        if ($attendanceStatus === 1) {
                            $attendanceStatusText = 'Present';
                        } elseif ($attendanceStatus === 0) {
                            $attendanceStatusText = 'Absent';
                        } elseif ($attendanceStatus === 2) {
                            $attendanceStatusText = 'Late';
                        }
                    }

                    $batches[$date->format('Y-m-d')][] = [
                        'BatchId' => $batch->id,
                        'Name' => $batch->Name,
                        'FromDate' => $batch->FromDate,
                        'ToDate' => $batch->ToDate,
                        'AttendanceStatus' => $attendanceStatusText ?? 'No attendance record',
                        'StartTimeInMinutes' => $batch->StartTimeInMinutes,
                        'EndTimeInMinutes' => $batch->EndTimeInMinutes,
                    ];
                }
            }
        }
        // Pass the $batches data to the frontend for rendering in the calendar
        return view('backend.student.scalender', compact('batches'));
    }

    public function PortfolioSubmission(Request $request)
    {
        $userRole = auth()->user()->RoleId;

        // Initialize student ID
        $studentId = null;

        // Check if the user role is 4 (presumably a student)
        if ($userRole == 4) {
            // If the user is a student, fetch their ID from the authenticated user
            $authUserId = auth()->user()->id;

            $student = Student::where('UserId', $authUserId)->first();
            // Check if a student with the authenticated user's ID exists
            if ($student) {
                // If a student is found, use their ID as the student ID
                $studentId = $student->id;
            } else {
                abort(404);
            }
        } else {
            // If the user is not a student, retrieve the student ID from the request
            $studentId = $request->id;
        }

        // Fetch portfolio data based on the determined student ID
        $portfolio = Portfoliosubmission::where('portfoliosubmission.StudentId', $studentId)
            ->join('student', 'portfoliosubmission.StudentId', '=', 'student.id')
            ->join('subject', 'portfoliosubmission.SubjectId', '=', 'subject.id')
            ->select(
                'subject.Name as subject_name',
                'student.FirstName',
                'student.LastName',
                'portfoliosubmission.SubmissionDate',
                'portfoliosubmission.id',
                'portfoliosubmission.ApprovedAt',
                'portfoliosubmission.IsApproved',
                'portfoliosubmission.PortfolioFile',
                'portfoliosubmission.StudentId'
            )
            ->get();

        return view('backend.student.portfolio', compact('portfolio'));
    }
    public function batchcompletion(Request $request)
    {
        $userRole = auth()->user()->RoleId;

        // Initialize student ID
        $studentId = null;

        // Check if the user role is 4 (presumably a student)
        if ($userRole == 4) {
            // If the user is a student, fetch their ID from the authenticated user
            $authUserId = auth()->user()->id;

            $student = Student::where('UserId', $authUserId)->first();
            // Check if a student with the authenticated user's ID exists
            if ($student) {
                // If a student is found, use their ID as the student ID
                $studentId = $student->id;
            } else {
                abort(404);
            }
        } else {
            // If the user is not a student, retrieve the student ID from the request
            $studentId = $request->id;
        }

        $batchDetails = DB::table('studentbatchassign')
            ->where('studentbatchassign.StudentId', $studentId)
            ->where('studentbatchassign.IsCompleted', 1)
            ->join('batch', 'studentbatchassign.BatchDetailId', '=', 'batch.id')
            ->join('faculty', 'batch.FacultyId', '=', 'faculty.id')
            ->select(
                'batch.FromDate',
                'batch.ToDate',
                'batch.StartTimeInMinutes',
                'batch.EndTimeInMinutes',
                'batch.VerifyAt',
                'batch.Name as batch_name',
                'faculty.FirstName',
                'faculty.LastName'
            )
            ->get();

        return view('backend.student.batchcompletion', compact('batchDetails'));
    }
}
