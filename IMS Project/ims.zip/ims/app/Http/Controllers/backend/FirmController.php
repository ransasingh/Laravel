<?php

namespace App\Http\Controllers\backend;

use App\Models\Firm;
use App\Models\Institute;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Validator;

class FirmController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $data = Firm::all();
        return view('backend.firm.list', compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $institutes = Institute::where('IsActive', '1')->get();
        $institutesid = $institutes[0]['id'];

        return view('backend.firm.add', compact('institutesid'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request, Firm $firm)
    {
        $validator = Validator::make(request()->all(), [
            'Name' => 'required',
            'Code' => 'required|unique:bank,Code',
            'IfscCode' => [
                'nullable',
                'regex:/^[A-Z]{4}0[A-Z0-9]{6}$/',
            ],
            'IsActive' => 'required',
            'UpiQrCode' => ['nullable', 'image', 'mimes:png,jpg,jpeg,gif', 'max:2048'],
        ], [
            'IfscCode.regex' => 'The IFSC code must be in the format: ABCD0123456',
            'UpiQrCode.image' => 'The UPI QR Code must be an image.',
            'UpiQrCode.mimes' => 'The UPI QR Code must be in PNG, JPG, JPEG, or GIF format.',
            'UpiQrCode.max' => 'The UPI QR Code must not exceed 2MB.',
        ]);

        if ($validator->fails()) {
            return redirect()->route('firm.add')
                ->withErrors($validator)
                ->withInput();
        } else {
            if ($request->hasFile('UpiQrCode')) {
                $UpiQrCode = time() . '.' . $request->UpiQrCode->getClientOriginalExtension();
                $request->UpiQrCode->move(public_path('uploads/UpiQrCode'), $UpiQrCode);
                $firm->UpiQrCode = $UpiQrCode;
            }
            $user_id = Auth::id();
            $firm->Name = ucwords($request->Name);
            $firm->InstituteId  = $request->InstituteId;
            $firm->Code = strtoupper($request->Code);
            $firm->BankName = $request->BankName;
            $firm->AccountNumber = $request->AccountNumber;
            $firm->IfscCode = $request->IfscCode;
            $firm->Branch = $request->Branch;
            $firm->IsActive = $request->IsActive;
            $firm->createdBy = $user_id;
            $firm->save();
            return redirect()->route('firm.listing')->with('success', 'Firm has been created successfully.');
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(Firm $firm)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Firm $firm, $id)
    {
        $data = Firm::find($id);
        return view('backend.firm.edit', compact('data'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Firm $firm, $id)
    {
        $data = Firm::find($id);
        $validator = Validator::make(request()->all(), [
            'Name' => 'required',
            'Code' => 'required|unique:bank,Code,' . $id,
            'IfscCode' => [
                'nullable',
                'regex:/^[A-Z]{4}0[A-Z0-9]{6}$/',
            ],
            'IsActive' => 'required',
            'UpiQrCode' => ['nullable', 'image', 'mimes:png,jpg,jpeg,gif', 'max:2048'],
        ], [
            'IfscCode.regex' => 'The IFSC code must be in the format: ABCD0123456',
            'UpiQrCode.image' => 'The UPI QR Code must be an image.',
            'UpiQrCode.mimes' => 'The UPI QR Code must be in PNG, JPG, JPEG, or GIF format.',
            'UpiQrCode.max' => 'The UPI QR Code must not exceed 2MB.',
        ]);

        if ($validator->fails()) {
            return redirect()->route('firm.edit', ['id' => $id])
                ->withErrors($validator)
                ->withInput();
        } else {
            if ($request->hasFile('UpiQrCode')) {
                $UpiQrCode = time() . '.' . $request->UpiQrCode->getClientOriginalExtension();
                $request->UpiQrCode->move(public_path('uploads/UpiQrCode'), $UpiQrCode);
                $data->UpiQrCode = $UpiQrCode;
            }
            $user_id = Auth::id();
            $data->Name = ucwords($request->Name);
            $data->InstituteId  = $request->InstituteId;
            $data->Code = strtoupper($request->Code);
            $data->BankName = $request->BankName;
            $data->AccountNumber = $request->AccountNumber;
            $data->IfscCode = $request->IfscCode;
            $data->Branch = $request->Branch;
            $data->IsActive = $request->IsActive;
            $data->updatedBy = $user_id;
            $data->save();
            return redirect()->route('firm.listing')->with('success', 'Firm has been updated successfully.');
        }
    }

    public function deleteImage(Request $request, $id)
    {
        $data = Firm::find($id);
        $imageType = $request->input('imageType');

        // Logic to remove the specified image type
        if ($imageType == 'UpiQrCode') {
            $oldImagePath = public_path('uploads/UpiQrCode/' . $data->UpiQrCode);
            $data->update(['UpiQrCode' => null]);
        } else {
            // Handle the case where imageType is not recognized
            return redirect()->back()->with('error', 'Invalid image type.');
        }

        // If the file exists, delete it
        if (file_exists($oldImagePath)) {
            unlink($oldImagePath);
            return redirect()->back()->with('success', 'Image deleted successfully.');
        }
        // If the file doesn't exist, update the database record anyway
        return redirect()->back()->with('error', 'Image not found.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function trash(Firm $firm, $id)
    {
        $data = Firm::find($id);
        if (!$data) {
            abort(404);
        }
        if ($data->IsActive == 0) {
            $data->delete();
            return redirect()->route('firm.listing')->with('success', 'Firm has been trashed successfully.');
        } else {
            return redirect()->route('firm.listing')->with('error', 'Invalid status on deletion,Kindly do Status make Inactive.');
        }
    }

    /**
     * trashview the specified resource from storage.
     */
    public function trashview(Firm $firm)
    {
        $data = Firm::onlyTrashed()->latest()->get();
        return view('backend.firm.trash', compact('data'));
    }

    /**
     * restore the specified resource .
     */
    public function restore(Firm $firm, $id)
    {
        // Restore a soft deleted 
        $data = Firm::withTrashed()->find($id);
        $data->restore();
        return redirect()->route('firm.listing')->with('success', 'Firm has been restored successfully.');
    }
    /**
     * trash the specified resource database permanent.
     */
    public function destroy(Firm $firm, $id)
    {
        // Permanently delete a soft deleted 
        $data = Firm::withTrashed()->find($id);
        $data->forceDelete();

        // Delete associated images if they exist
        if ($data->UpiQrCode != null) {
            $this->deleteImg('uploads/UpiQrCode/' . $data->UpiQrCode);
        }

        return redirect()->route('firm.trashview')->with('success', 'Firm has been permanent delete successfully.');
    }

    // Helper function to delete an image
    private function deleteImg($path)
    {
        // Get the full path to the public directory
        $publicPath = public_path();

        // Combine the public path with the relative image path
        $imagePath = $publicPath . '/' . $path;

        // Check if the file exists before attempting to delete
        if (file_exists($imagePath)) {
            unlink($imagePath);
        }
    }
}
