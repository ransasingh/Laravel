<?php

namespace App\Http\Controllers\backend;

use App\Models\Institute;
use App\Http\Controllers\Controller;
use App\Models\State;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Validator;


class InstituteController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $data = Institute::all();
        return view('backend.institute.list', compact('data'));
    }


    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        // Get the count of institutes
        // $institutecount = Institute::count();
        // // Get the ID of a specific institute (for example, the first one)
        // $instituteId = Institute::first()->id;
        $states = State::where('IsActive', '1')->get();
        return view('backend.institute.add', compact('states'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request, Institute $institute)
    {
        $validator = Validator::make(request()->all(), [
            'Name' => 'required|unique:institute,Name',
            'EmailId' => ['required', 'email'],
            'MobileNumber' => ['required', 'numeric', 'digits:10'],
            'AddressLine1' => 'required',
            'StateId' => 'required',
            'CityName' => 'required',
            'PostalCode' => 'required',
            'IsActive' => 'required',
            'InstituteLogo' => ['nullable', 'image', 'mimes:png,jpg,jpeg,gif', 'max:2048'],
        ], [
            'MobileNumber.required' => 'The mobile number is required.',
            'MobileNumber.numeric' => 'The mobile number must be numeric.',
            'MobileNumber.digits' => 'The mobile number must be exactly 10 digits.',
            'InstituteLogo.image' => 'The Institute Logo must be an image file.',
            'InstituteLogo.mimes' => 'The Institute Logo must be a valid image format (png, jpg, jpeg, gif).',
            'InstituteLogo.max' => 'The Institute Logo must not be larger than 2 megabytes.',
            'StateId.required' => 'Please select state',
        ]);
        if ($validator->fails()) {
            return redirect()->route('institute.add')
                ->withErrors($validator)
                ->withInput();
        } else {
            if ($request->hasFile('InstituteLogo')) {
                $InstituteLogo = time() . '.' . $request->InstituteLogo->getClientOriginalExtension();
                $request->InstituteLogo->move(public_path('uploads/institute'), $InstituteLogo);
                $institute->InstituteLogo = $InstituteLogo;
            }
            $user_id = Auth::id();
            $institute->Name = ucwords($request->Name);
            $institute->MobileNumber  = $request->MobileNumber;
            $institute->EmailId = $request->EmailId;
            $institute->Website = $request->Website;
            $institute->AddressLine1 = $request->AddressLine1;
            $institute->AddressLine2 = $request->AddressLine2;
            $institute->StateId = $request->StateId;
            $institute->CityName = $request->CityName;
            $institute->PostalCode = $request->PostalCode;
            $institute->IsActive = $request->IsActive;
            $institute->createdBy = $user_id;
            $institute->save();

            // return redirect()->route('institute.edit', ['id' => $institute->id])->with('success', 'Institute has been created successfully.');
            return redirect()->route('institute.listing')->with('success', 'Institute has been created successfully.');
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(Institute $institute)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Institute $institute, $id)
    {
        $data = Institute::find($id);
        $states = State::where('IsActive', '1')->get();
        return view('backend.institute.edit', compact('data', 'states'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Institute $institute, $id)
    {
        $data = Institute::find($id);
        $validator = Validator::make(request()->all(), [
            'Name' => 'required|unique:institute,Name,' . $id,
            'EmailId' => ['required', 'email'],
            'MobileNumber' => ['required', 'numeric', 'digits:10'],
            'AddressLine1' => 'required',
            'StateId' => 'required',
            'CityName' => 'required',
            'PostalCode' => 'required',
            'IsActive' => 'required',
            'InstituteLogo' => ['nullable', 'image', 'mimes:png,jpg,jpeg,gif', 'max:2048'],
        ], [
            'MobileNumber.required' => 'The mobile number is required.',
            'MobileNumber.numeric' => 'The mobile number must be numeric.',
            'MobileNumber.digits' => 'The mobile number must be exactly 10 digits.',
            'InstituteLogo.image' => 'The Institute Logo must be an image file.',
            'InstituteLogo.mimes' => 'The Institute Logo must be a valid image format (png, jpg, jpeg, gif).',
            'InstituteLogo.max' => 'The Institute Logo must not be larger than 2 megabytes.',
            'StateId.required' => 'Please select state',
        ]);
        if ($validator->fails()) {
            return redirect()->route('institute.edit', ['id' => $id])
                ->withErrors($validator)
                ->withInput();
        } else {
            if ($request->hasFile('InstituteLogo')) {
                $InstituteLogo = time() . '.' . $request->InstituteLogo->getClientOriginalExtension();
                $request->InstituteLogo->move(public_path('uploads/institute'), $InstituteLogo);
                $data->InstituteLogo = $InstituteLogo;
            }
            $user_id = Auth::id();
            $data->Name = ucwords($request->Name);
            $data->MobileNumber  = $request->MobileNumber;
            $data->EmailId = $request->EmailId;
            $data->Website = $request->Website;
            $data->AddressLine1 = $request->AddressLine1;
            $data->AddressLine2 = $request->AddressLine2;
            $data->StateId = $request->StateId;
            $data->CityName = $request->CityName;
            $data->PostalCode = $request->PostalCode;
            $data->IsActive = $request->IsActive;
            $data->updatedBy = $user_id;
            $data->save();
            // return redirect()->route('institute.edit', ['id' => $id])->with('success', 'Institute has been updated successfully.');
            return redirect()->route('institute.listing')->with('success', 'Institute has been updated successfully.');
        }
    }

    public function deleteImage(Request $request, $id)
    {
        $data = Institute::find($id);
        $imageType = $request->input('imageType');

        // Logic to remove the specified image type
        if ($imageType == 'InstituteLogo') {
            $oldImagePath = public_path('uploads/institute/' . $data->InstituteLogo);
            $data->update(['InstituteLogo' => null]);
        } else {
            // Handle the case where imageType is not recognized
            return redirect()->back()->with('error', 'Invalid image type.');
        }

        // If the file exists, delete it
        if (file_exists($oldImagePath)) {
            unlink($oldImagePath);
            return redirect()->back()->with('success', 'Image deleted successfully.');
        }
        // If the file doesn't exist, update the database record anyway
        return redirect()->back()->with('error', 'Image not found.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function trash(Institute $institute, $id)
    {
        $data = Institute::find($id);
        if (!$data) {
            abort(404);
        }
        if ($data->IsActive == 0) {
            $data->delete();
            return redirect()->route('institute.listing')->with('success', 'Institute has been trashed successfully.');
        } else {
            return redirect()->route('institute.listing')->with('error', 'Invalid status on deletion,Kindly do Status make Inactive.');
        }
    }

    /**
     * trashview the specified resource from storage.
     */
    public function trashview(Institute $institute)
    {
        $data = Institute::onlyTrashed()->latest()->get();
        return view('backend.institute.trash', compact('data'));
    }

    /**
     * restore the specified resource .
     */
    public function restore(Institute $institute, $id)
    {
        // Restore a soft deleted 
        $data = Institute::withTrashed()->find($id);
        $data->restore();
        return redirect()->route('institute.listing')->with('success', 'Institute has been restored successfully.');
    }
    /**
     * trash the specified resource database permanent.
     */
    public function destroy(Institute $institute, $id)
    {
        // Permanently delete a soft deleted 
        $data = Institute::withTrashed()->find($id);
        $data->forceDelete();

        // Delete associated images if they exist
        $this->deleteImg('uploads/institute/' . $data->InstituteLogo);

        return redirect()->route('institute.trashview')->with('success', 'Institute has been permanent delete successfully.');
    }

    // Helper function to delete an image
    private function deleteImg($path)
    {
        // Get the full path to the public directory
        $publicPath = public_path();

        // Combine the public path with the relative image path
        $imagePath = $publicPath . '/' . $path;

        // Check if the file exists before attempting to delete
        if (file_exists($imagePath)) {
            unlink($imagePath);
        }
    }
}
