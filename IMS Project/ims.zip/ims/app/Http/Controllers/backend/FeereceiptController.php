<?php

namespace App\Http\Controllers\backend;

use App\Http\Controllers\Controller;
use App\Models\Feereceipt;
use App\Models\Finacialyear;
use App\Models\Firm;
use App\Models\Student;
use App\Models\Feereceiptdetail;
use App\Models\StudentFeeEmi;
use App\Models\UserBranchRight;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Validator;
use Carbon\Carbon;

use Illuminate\Support\Facades\DB;


class FeereceiptController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function detail(Request $request)
    {
        $userId = auth()->id();
        // Retrieve the branch ID associated with the user
        $branchId = UserBranchRight::where('UserId', $userId)->value('BranchId');
        if ($branchId !== null && session('BranchId') == $branchId) {
            $data = DB::table('student')
                ->join('feestructure', 'student.CourseId', '=', 'feestructure.CourseId')
                ->select(
                    'student.*',
                    'feestructure.id as FeeStructureId'
                )
                ->where('student.UserId', $userId)
                ->first();
            // Check if data is available
            if ($data) {
                $feedetails = FeeReceipt::leftJoin('feereceiptdetail', 'feereceiptdetail.FeeReceiptId', '=', 'feereceipt.id')
                    ->where('feereceipt.StudentId', $data->id)
                    ->select('feereceipt.id', 'feereceipt.ReceiptNo', 'feereceipt.FinancialYearId', 'feereceipt.ReceiptDate', DB::raw('SUM(feereceiptdetail.Amount) as totalAmount'))
                    ->groupBy('feereceipt.id', 'feereceipt.ReceiptNo', 'feereceipt.FinancialYearId', 'feereceipt.ReceiptDate')
                    ->get();
                $totalpaidAmount = 0;
                $totalRemainingAmount = 0;

                foreach ($feedetails as $feeDetail) {
                    if ($feeDetail->totalAmount > 0) {
                        $totalpaidAmount += $feeDetail->totalAmount;
                    }
                }

                $totalRemainingAmount = $data->TotalFeeAmount - $totalpaidAmount;
                $installments = StudentFeeEmi::where('StudentId', $data->id)->get();
                $totalInstallmentAmount = $installments->sum('InstallmentAmount');

                return view('backend.feereceipt.detail', compact('data', 'feedetails', 'installments', 'totalInstallmentAmount', 'totalRemainingAmount', 'totalpaidAmount'));
            } else {
                return redirect()->back()->with('error', 'Fee details could not be retrieved. Please ensure that the correct fee structure is selected for the chosen course.');
            }
        }
        abort(403);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create(Request $request)
    {

        $data = Student::join('feestructure', 'student.CourseId', '=', 'feestructure.CourseId')
            ->select('student.*', 'feestructure.id as FeeStructureId')
            ->where('student.id', $request->id)
            ->first();
        if ($data) {
            $studentId = $data->id;

            $feedetails = FeeReceipt::leftJoin('feereceiptdetail', 'feereceiptdetail.FeeReceiptId', '=', 'feereceipt.id')
                ->where('feereceipt.StudentId', $studentId)
                ->select('feereceipt.id', 'feereceipt.ReceiptNo', 'feereceipt.FinancialYearId', 'feereceipt.ReceiptDate', DB::raw('SUM(feereceiptdetail.Amount) as totalAmount'))
                ->groupBy('feereceipt.id', 'feereceipt.ReceiptNo', 'feereceipt.FinancialYearId', 'feereceipt.ReceiptDate')
                ->get();
            $totalpaidAmount = 0;
            $totalRemainingAmount = 0;

            foreach ($feedetails as $feeDetail) {
                if ($feeDetail->totalAmount > 0) {
                    $totalpaidAmount += $feeDetail->totalAmount;
                }
            }

            $totalRemainingAmount = $data->TotalFeeAmount - $totalpaidAmount;

            if ($totalRemainingAmount == 0) {
                // Update student table indicating fee is paid
                $data->IsFullPaid = 1;
                $data->save();
            } else {
                $data->IsFullPaid = 0;
                $data->save();
            }

            return view('backend.feereceipt.add', compact('data', 'feedetails', 'totalpaidAmount', 'totalRemainingAmount'));
        } else {
            return redirect()->back()->with('error', 'Fee details could not be retrieved. Please ensure that the correct fee structure is selected for the chosen course.');
        }
    }

    /**
     * Display the specified resource.
     */
    public function add(Request $request)
    {
        $student = Student::join('course', 'student.CourseId', '=', 'course.id')
            ->select('student.*', 'course.Name as course_name')
            ->where('student.id', $request->id)
            ->first();
        $firms = Firm::where('IsActive', '1')->get();
        $finacialyearname = Finacialyear::where('IsCurrent', '1')->where('IsActive', '1')->latest()->value('Name');

        $feeheads = DB::table('student')
            ->join('feestructure', 'student.CourseId', '=', 'feestructure.CourseId')
            ->join('feestructuremap', 'feestructure.id', '=', 'feestructuremap.FeeStructureId')
            ->join('feehead', 'feestructuremap.FeeHeadId', '=', 'feehead.id') // Join with feehead table
            ->leftJoin('feereceipt', function ($join) use ($student) {
                $join->on('feestructuremap.FeeStructureId', '=', 'feereceipt.FeeStructureId')
                    ->where('feereceipt.StudentId', $student->id);
            })
            ->leftJoin('feereceiptdetail', function ($join) {
                $join->on('feereceipt.id', '=', 'feereceiptdetail.FeeReceiptId')
                    ->on('feestructuremap.FeeHeadId', '=', 'feereceiptdetail.FeeHeadId');
            })
            ->where('student.CourseId', $student->CourseId)
            ->where('student.id', $student->id)
            ->select(
                'feehead.id as FeeHeadId',
                'feehead.Name as FeeHeadName',
                'feestructuremap.Amount',
                'feestructuremap.FeeStructureId',
                DB::raw('SUM(feereceiptdetail.Amount) as PaidAmount'),
                DB::raw('feestructuremap.Amount - SUM(feereceiptdetail.Amount) as RemainingAmount')
            )
            ->groupBy('feehead.id', 'feehead.Name', 'feestructuremap.Amount', 'feestructuremap.FeeStructureId')
            ->get();

        return view('backend.feereceipt.collect', compact('student', 'finacialyearname', 'firms', 'feeheads'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request, Feereceipt $feereceipt)
    {
        $validator = Validator::make(request()->all(), [
            'ReceiptDate' => 'required|date',
            'PaymentMode' => 'required|in:Cash,Cheque,Online',
            'BankId' => 'required_if:PaymentMode,Cash,Cheque,Online',
            'ChequeNoOrUtr' => 'required_if:PaymentMode,Cheque,Online',
            'ChequeDate' => 'required_if:PaymentMode,Cheque',
            'FeeHeadId.*' => 'numeric|min:0|' . ($request->input('feeHeadRemainingAmount') !== null ? 'max:' . $request->input('feeHeadRemainingAmount') : ''),
        ], [
            'ReceiptDate.required' => 'Please enter a receipt date.',
            'ReceiptDate.date' => 'Invalid date format for receipt date.',
            'PaymentMode.required' => 'Please select a payment mode.',
            'PaymentMode.in' => 'Invalid payment mode selected.',
            'BankId.required_if' => 'Please select a Firm.',
            'ChequeNoOrUtr.required_if' => 'Please enter Cheque number or UTR for Cheque or Online payment.',
            'ChequeDate.required_if' => 'Please select a Cheque date for Cheque payment.',
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                ->withErrors($validator)
                ->withInput();
        } else {
            DB::beginTransaction();
            try {
                $user_id = Auth::id();
                $feereceipt->StudentId = $request->StudentId;
                $feereceipt->FeeStructureId = $request->FeeStructureId;
                $feereceipt->FinancialYearId = $request->FinancialYearId;
                $feereceipt->ReceiptDate = $request->ReceiptDate;
                $feereceipt->IsActive = '1';
                $feereceipt->createdBy = $user_id;
                $feereceipt->FilePath = $request->FilePath;
                $feereceipt->PaymentMode = $request->PaymentMode;
                $feereceipt->ChequeNoOrUtr = $request->ChequeNoOrUtr;
                $feereceipt->ChequeDate = $request->ChequeDate;
                $feereceipt->BankId = $request->BankId;
                $feereceipt->save();
                // Update data
                Feereceipt::where('id', $feereceipt->id)->update([
                    'ReceiptSrNo' => $feereceipt->id,
                    'ReceiptNo' => $feereceipt->PaymentMode . '/' . $feereceipt->FinancialYearId . '/' . $feereceipt->id,
                ]);
                $feeHeadPayments = $request->input('FeeHeadId');
                // Check if $feeHeadPayments is not null before using foreach
                if (!is_null($feeHeadPayments)) {
                    foreach ($feeHeadPayments as $feeHeadId => $amount) {
                        // Assuming you have a 'feereceiptdetail' table
                        DB::table('feereceiptdetail')->insert([
                            'FeeHeadId' => $feeHeadId,
                            'Amount' => $amount,
                            'FeeReceiptId' => $feereceipt->id,
                        ]);

                        // Fetch all EMIs for the student and fee structure
                        $emis = DB::table('studentfeeemi')
                            ->where('StudentId', $feereceipt->StudentId)
                            ->where('FeeStructureId', $feereceipt->FeeStructureId)
                            ->where('IsActive', '0') // Assuming you want to update only inactive EMIs
                            ->get();

                        // Calculate the total amount of EMIs
                        $totalEmiAmount = $emis->sum('InstallmentAmount');

                        // Check if the total payment amount is greater than or equal to the total EMI amount
                        if ($amount >= $totalEmiAmount) {
                            // Set IsActive to '1' for all EMIs
                            DB::table('studentfeeemi')
                                ->where('StudentId', $feereceipt->StudentId)
                                ->where('FeeStructureId', $feereceipt->FeeStructureId)
                                ->update(['IsActive' => '1']);
                        } else {
                            // Iterate through EMIs and track the remaining amount to be covered
                            $remainingAmount = $amount;

                            foreach ($emis as $emi) {
                                if ($remainingAmount >= $emi->InstallmentAmount) {
                                    // If remaining amount is greater than or equal to EMI amount, set IsActive to '1'
                                    DB::table('studentfeeemi')
                                        ->where('id', $emi->id)
                                        ->update(['IsActive' => '1']);
                                    $remainingAmount -= $emi->InstallmentAmount;
                                } else {
                                    // If remaining amount is less than EMI amount, set IsActive to '0' for the current EMI
                                    DB::table('studentfeeemi')
                                        ->where('id', $emi->id)
                                        ->update(['IsActive' => '0']);

                                    // Exit the loop, as this EMI is not fully covered
                                    break;
                                }
                            }
                        }
                    }
                }

                DB::commit();
                return redirect()->route('feereceipt.add', ['id' => $feereceipt->StudentId])->with('success', 'Fee has been submitted successfully.');
            } catch (\Exception $e) {
                DB::rollBack();
                return redirect()->back()->withInput()->withErrors(['error' => $e->getMessage()]);
            }
        }
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Feereceipt $feereceipt)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Feereceipt $feereceipt)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Feereceipt $feereceipt, $id)
    {
        $data = Feereceipt::find($id);
        if (!$data) {
            abort(404);
        }
        // Fetch all EMIs for the student and fee structure
        $emis = DB::table('studentfeeemi')
            ->where('StudentId', $data->StudentId)
            ->where('FeeStructureId', $data->FeeStructureId)
            ->where('IsActive', '1')
            ->get();

        // Iterate through EMIs and set IsActive based on paid amount
        foreach ($emis as $emi) {
            // Check if the remaining paid amount is less than the installment amount
            $isActive = ($data->PaidAmount >= $emi->InstallmentAmount) ? '1' : '0';

            DB::table('studentfeeemi')
                ->where('id', $emi->id)
                ->update(['IsActive' => $isActive]);

            // If the paid amount is greater than or equal to the installment amount, deduct the installment amount from the paid amount
            if ($isActive == '1') {
                $data->PaidAmount -= $emi->InstallmentAmount;
            }
        }

        FeeReceiptDetail::where('FeeReceiptId', $data->id)->delete();

        // Delete the fee receipt
        $data->forceDelete();

        return redirect()->back()->with('success', 'Fee receipt has been deleted successfully.');
    }


    public function printReceipt($id)
    {
        $receipt = Feereceipt::join('sysuser', 'feereceipt.createdBy', '=', 'sysuser.id')
            ->select('feereceipt.*', 'sysuser.Name as created_by_name',)
            ->findOrFail($id);

        $details = DB::table('feereceiptdetail')
            ->join('feehead', 'feereceiptdetail.FeeHeadId', '=', 'feehead.id')
            ->select('feereceiptdetail.*', 'feehead.Name as fee_head_name')
            ->where('feereceiptdetail.FeeReceiptId', $id)
            ->get();
        $studentDetails = DB::table('feereceipt')
            ->join('student', 'feereceipt.StudentId', '=', 'student.id')
            ->join('course', 'student.CourseId', '=', 'course.id')
            ->join('institute', 'course.InstituteId', '=', 'institute.id')
            ->select(
                'student.FirstName',
                'student.LastName',
                'student.MobileNumber',
                'course.Name as course_name',
                'institute.Name as institute_name',
                'student.UserId'
            )
            ->where('feereceipt.id', $id)
            ->first();

        // Check if the authenticated user is a superadmin
        if (auth()->user()->RoleId == 1 || (auth()->user()->RoleId == 4 && $studentDetails->UserId == auth()->id())) {
            // User is a superadmin or the owner of the receipt, proceed with printing
            return view('backend.feereceipt.print', compact('receipt', 'details', 'studentDetails'));
        } else {
            // User is not authorized, redirect back or display an error
            return redirect()->back()->with('error', 'You are not authorized to print this receipt.');
        }
    }

    public function generatePDF($id)
    {
        $receipt = Feereceipt::join('sysuser', 'feereceipt.createdBy', '=', 'sysuser.id')
            ->select('feereceipt.*', 'sysuser.Name as created_by_name')
            ->findOrFail($id);

        $details = DB::table('feereceiptdetail')
            ->join('feehead', 'feereceiptdetail.FeeHeadId', '=', 'feehead.id')
            ->select('feereceiptdetail.*', 'feehead.Name as fee_head_name')
            ->where('feereceiptdetail.FeeReceiptId', $id)
            ->get();
        $studentDetails = DB::table('feereceipt')
            ->join('student', 'feereceipt.StudentId', '=', 'student.id')
            ->join('course', 'student.CourseId', '=', 'course.id')
            ->join('institute', 'course.InstituteId', '=', 'institute.id')
            ->select(
                'student.FirstName',
                'student.LastName',
                'student.MobileNumber',
                'course.Name as course_name',
                'institute.Name as institute_name',
                'student.UserId'
            )
            ->where('feereceipt.id', $id)
            ->first();

        $filename = $studentDetails->FirstName . '_' . now()->format('Ymd_His') . '.pdf';

        // Check if the authenticated user is a superadmin
        if (auth()->user()->RoleId == 1 || (auth()->user()->RoleId == 4 && $studentDetails->UserId == auth()->id())) {
            // User is a superadmin or the owner of the receipt, proceed with printing
            return View('backend.feereceipt.print', compact('receipt', 'details', 'studentDetails'));
        } else {
            // User is not authorized, redirect back or display an error
            return redirect()->back()->with('error', 'You are not authorized to print this receipt.');
        }
    }
}
