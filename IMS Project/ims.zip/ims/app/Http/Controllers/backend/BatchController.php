<?php

namespace App\Http\Controllers\backend;

use App\Models\Batch;
use App\Http\Controllers\Controller;
use App\Models\Batchdetail;
use App\Models\Faculty;
use App\Models\StudentBatchAssign;
use Illuminate\Http\Request;
use App\Models\subject;
use Illuminate\Support\Facades\Auth;
use Validator;
use Illuminate\Support\Facades\DB;

class BatchController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $data = Batch::join('faculty', 'batch.FacultyId', '=', 'faculty.id')
            ->select('batch.*', 'faculty.FirstName', 'faculty.LastName')
            ->where('faculty.BranchId', session('BranchId'))
            ->get();

        return view('backend.batch.list', compact('data'));
    }
    /**
     * Display a listing of the resource. for faculty listing batchwise
     */
    public function facultybatch(Request $request)
    {
        $facultyId = $request->input('facultyId');
        $data = Batch::join('faculty', 'batch.FacultyId', '=', 'faculty.id')
            ->leftJoin('batchdetail', 'batch.id', '=', 'batchdetail.BatchId')
            ->select(
                'batch.id',
                'batch.Name',
                'batch.StartTimeInMinutes',
                'batch.EndTimeInMinutes',
                'batch.FacultyId',
                'faculty.FirstName',
                'faculty.LastName',
                'batch.FromDate',
                'batch.ToDate',
                DB::raw("GROUP_CONCAT(DISTINCT batchdetail.BatchDay ORDER BY batchdetail.BatchDay SEPARATOR ', ') as BatchDays")
            )
            ->where('faculty.id', $facultyId)
            ->where('faculty.BranchId', session('BranchId'))
            ->groupBy(
                'batch.id',
                'batch.Name',
                'batch.StartTimeInMinutes',
                'batch.EndTimeInMinutes',
                'batch.FacultyId',
                'faculty.FirstName',
                'faculty.LastName',
                'batch.FromDate',
                'batch.ToDate',
            )
            ->get();


        return view('backend.batch.batch', compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $subjects = subject::where('IsActive', '1')->get();
        $faculties = Faculty::where('IsActive', '1')->get()
            ->where('BranchId', session('BranchId'));
        return view('backend.batch.add', compact('subjects', 'faculties'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request, Batch $batch)
    {
        $validator = Validator::make(request()->all(), [
            'SubjectId' => 'required|exists:subject,id',
            'StudentCapacity' => 'required|numeric|min:0',
            'FromDate' => 'required|date',
            'ToDate' => 'required|date|after_or_equal:FromDate',
            'StartTimeInMinutes' => 'required|date_format:H:i',
            'EndTimeInMinutes' => 'required|date_format:H:i|after:StartTimeInMinutes',
            'FacultyId' => [
                'required',
                'numeric',
                function ($attribute, $value, $fail) use ($request) {
                    if (empty($request->BatchDay)) {
                        $fail('Please select at least one Batch day.');
                        return;
                    }

                    $conflictingBatch = Batch::where('FacultyId', $request->FacultyId)
                        ->where('IsCompleted', 0)
                        ->where(function ($query) use ($request) {
                            $query->where(function ($subquery) use ($request) {
                                $subquery->where('StartTimeInMinutes', '>=', $request->StartTimeInMinutes)
                                    ->where('StartTimeInMinutes', '<', $request->EndTimeInMinutes);
                            })
                                ->orWhere(function ($subquery) use ($request) {
                                    $subquery->where('EndTimeInMinutes', '>', $request->StartTimeInMinutes)
                                        ->where('EndTimeInMinutes', '<=', $request->EndTimeInMinutes);
                                })
                                ->orWhere(function ($subquery) use ($request) {
                                    $subquery->where('StartTimeInMinutes', '<', $request->StartTimeInMinutes)
                                        ->where('EndTimeInMinutes', '>', $request->EndTimeInMinutes);
                                });
                        })
                        ->join('batchdetail', 'batch.id', '=', 'batchdetail.BatchId')
                        ->whereIn('batchdetail.BatchDay', $request->BatchDay)
                        ->first();

                    if ($conflictingBatch) {
                        $fail('The faculty is already assigned to a batch at the same time and day.');
                        return;
                    }
                },
            ],
            'IsActive' => 'required|in:0,1',
            'IsCompleted' => 'required|in:0,1',
            'BatchDay' => 'required|array',
            'BatchDay.*' => 'numeric|between:0,6',
        ], [
            'BatchDay.*.numeric' => 'Invalid value for Batch Day.',
            'BatchDay.*.between' => 'Batch Day should be between 0 and 6.',
            'FacultyId.required' => 'Select Faculty.',
            'BatchDay.required' => 'Please select at least one Batch day.',
        ]);

        if ($validator->fails()) {
            return redirect()->route('batch.add')
                ->withErrors($validator)
                ->withInput();
        } else {
            DB::beginTransaction();
            try {

                $subjectName = Subject::where('id', $request->SubjectId)->value('Name');
                $user_id = Auth::id();
                $batch->FacultyId = $request->FacultyId;
                $batch->Name = $subjectName;
                $batch->StartTimeInMinutes = $request->StartTimeInMinutes;
                $batch->EndTimeInMinutes = $request->EndTimeInMinutes;
                $batch->FromDate = $request->FromDate;
                $batch->ToDate = $request->ToDate;
                $batch->StudentCapacity = $request->StudentCapacity;
                $batch->IsCompleted = $request->IsCompleted;
                $batch->IsActive = $request->IsActive;
                $batch->createdBy = $user_id;
                $batch->save();

                foreach ($request->BatchDay as $day) {
                    // Use firstOrCreate to create a new record if it doesn't exist
                    Batchdetail::firstOrCreate(
                        [
                            'SubjectId' => $request->SubjectId,
                            'BatchDay' => $day,
                            'BatchId' => $batch->id,
                        ],
                        [
                            'IsActive' => '1',
                            'createdBy' => $user_id
                        ]
                    );
                }

                DB::commit();
                return redirect()->route('batch.edit', ['id' => $batch->id])->with('success', 'Batch has been created successfully.');
            } catch (\Exception $e) {
                DB::rollBack();
                return redirect()->back()->withInput()->withErrors(['error' => $e->getMessage()]);
            }
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(Batch $batch)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Batch $batch, $id)
    {
        $data = Batch::find($id);
        $batchDetailData = Batchdetail::where('BatchId', $id)->get();
        $subjects = subject::where('IsActive', '1')->get();
        $faculties = Faculty::where('IsActive', '1')->get();

        $studentsInSubject = BatchDetail::where('BatchId', $id)
            ->join('studentcourse as subject1', 'batchdetail.SubjectId', '=', 'subject1.SubjectId')
            ->join('student', function ($join) {
                $join->on('subject1.StudentId', '=', 'student.id');
            })
            ->select('student.*')
            ->whereNotIn('student.id', function ($query) use ($id) {
                $query->select('studentbatchassign.StudentId')
                    ->from('studentbatchassign')
                    ->join('batchdetail', 'studentbatchassign.BatchDetailId', '=', 'batchdetail.BatchId')
                    ->where('batchdetail.BatchId', $id);
            })
            ->distinct()
            ->get();


        $studentBatchAssignData = StudentBatchAssign::where('BatchDetailId', $data->id)
            ->join('student', 'studentbatchassign.StudentId', '=', 'student.id')
            ->join('batch', 'studentbatchassign.BatchDetailId', '=', 'batch.id')
            ->join('faculty', 'batch.FacultyId', '=', 'faculty.id')
            ->select('student.*', 'studentbatchassign.id as assigned_id', 'faculty.FirstName as ffname', 'faculty.LastName as flname')
            ->distinct()
            ->get();

        return view('backend.batch.edit', compact('data', 'batchDetailData', 'subjects', 'faculties', 'studentsInSubject', 'studentBatchAssignData'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Batch $batch, $id)
    {
        $data = Batch::find($id);
        $validator = Validator::make(request()->all(), [
            'SubjectId' => 'required|exists:subject,id',
            'StudentCapacity' => 'required|numeric|min:0',
            'FromDate' => 'required|date',
            'ToDate' => 'required|date|after_or_equal:FromDate',
            'StartTimeInMinutes' => 'required|date_format:H:i',
            'EndTimeInMinutes' => 'required|date_format:H:i|after:StartTimeInMinutes',
            'FacultyId' => [
                'required',
                'numeric',
                function ($attribute, $value, $fail) use ($request, $id) {
                    // Check if at least one checkbox is selected
                    if (empty($request->BatchDay)) {
                        $fail('Please Check at least one Batch day.');
                        return;
                    }

                    // Check if the faculty is already assigned to a batch at the same time and day
                    $conflictingBatch = Batch::where('FacultyId', $request->FacultyId)
                        ->where('IsCompleted', 0)
                        ->where(function ($query) use ($request) {
                            $query->where(function ($subquery) use ($request) {
                                $subquery->where('StartTimeInMinutes', '>=', $request->StartTimeInMinutes)
                                    ->where('StartTimeInMinutes', '<', $request->EndTimeInMinutes);
                            })
                                ->orWhere(function ($subquery) use ($request) {
                                    $subquery->where('EndTimeInMinutes', '>', $request->StartTimeInMinutes)
                                        ->where('EndTimeInMinutes', '<=', $request->EndTimeInMinutes);
                                })
                                ->orWhere(function ($subquery) use ($request) {
                                    $subquery->where('StartTimeInMinutes', '<', $request->StartTimeInMinutes)
                                        ->where('EndTimeInMinutes', '>', $request->EndTimeInMinutes);
                                });
                        })
                        ->join('batchdetail', 'batch.id', '=', 'batchdetail.BatchId')
                        ->whereIn('batchdetail.BatchDay', $request->BatchDay)
                        ->where('batch.id', '<>', $id)
                        ->first();

                    if ($conflictingBatch) {
                        return redirect()->route('batch.edit', ['id' => $id])->withErrors(['error' => 'The faculty is already assigned to a batch at the same time and day.']);
                    }
                },
            ],

            'IsActive' => 'required|in:0,1',
            'IsCompleted' => 'required|in:0,1',
            'BatchDay' => 'required|array',
            'BatchDay.*' => 'numeric|between:0,6',
        ], [
            'BatchDay.*.numeric' => 'Invalid value for Batch Day.',
            'BatchDay.*.between' => 'Batch Day should be between 0 and 6.',
        ]);

        if ($validator->fails()) {
            return redirect()->route('batch.edit', ['id' => $id])
                ->withErrors($validator)
                ->withInput();
        } else {
            DB::beginTransaction();
            try {
                $subjectName = Subject::where('id', $request->SubjectId)->value('Name');
                $user_id = Auth::id();
                $data->FacultyId = $request->FacultyId;
                $data->Name = $subjectName;
                $data->StartTimeInMinutes = $request->StartTimeInMinutes;
                $data->EndTimeInMinutes = $request->EndTimeInMinutes;
                $data->FromDate = $request->FromDate;
                $data->ToDate = $request->ToDate;
                $data->StudentCapacity = $request->StudentCapacity;
                $data->IsCompleted = $request->IsCompleted;
                $data->IsActive = $request->IsActive;
                $data->updatedBy = $user_id;
                $data->save();


                // Save each day into the BatchDay table
                $uncheckedDays = array_diff([0, 1, 2, 3, 4, 5, 6], $request->BatchDay);
                Batchdetail::where('BatchId', $data->id)
                    ->whereIn('BatchDay', $uncheckedDays)
                    ->forcedelete();
                // Save each day into the BatchDay table
                foreach ($request->BatchDay as $day) {
                    // Use updateOrCreate to update existing records or create new ones if they don't exist
                    Batchdetail::updateOrCreate(
                        [
                            'SubjectId' => $request->SubjectId,
                            'BatchDay' => $day,
                            'BatchId' => $data->id,
                        ],
                        [
                            'IsActive' => '1',
                            'updatedBy' => $user_id
                        ]
                    );
                }

                DB::commit();
                return redirect()->route('batch.listing')->with('success', 'Batch has been updated successfully.');
            } catch (\Exception $e) {
                DB::rollBack();
                dd($e->getMessage());
                return redirect()->back()->withInput()->withErrors(['error' => $e->getMessage()]);
            }
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function trash(Batch $batch, $id)
    {
        $data = Batch::find($id);
        if (!$data) {
            abort(404);
        }
        if ($data->IsActive == 0) {
            $data->delete();
            return redirect()->route('batch.listing')->with('success', 'Batch has been trashed successfully.');
        } else {
            return redirect()->route('batch.listing')->with('error', 'Invalid status on deletion,Kindly do Status make Inactive.');
        }
    }

    /**
     * trashview the specified resource from storage.
     */
    public function trashview(Batch $batch)
    {
        $data = Batch::onlyTrashed()
            ->join('faculty', 'batch.FacultyId', '=', 'faculty.id')
            ->select('batch.*', 'faculty.FirstName', 'faculty.LastName')
            ->latest()
            ->get();

        return view('backend.batch.trash', compact('data'));
    }

    /**
     * restore the specified resource .
     */
    public function restore(Batch $batch, $id)
    {
        // Restore a soft deleted 
        $data = Batch::withTrashed()->find($id);
        $data->restore();
        return redirect()->route('batch.listing')->with('success', 'Batch has been restored successfully.');
    }
    /**
     * trash the specified resource database permanent.
     */
    public function destroy(Batch $batch, $id)
    {
        // Permanently delete a soft deleted 
        $data = Batch::withTrashed()->find($id);
        if ($data) {
            $batchDetails = BatchDetail::where('BatchId', $data->id)->get();
            $studentAssignments = StudentBatchAssign::where('BatchDetailId', $data->id)->get();

            DB::beginTransaction(); // Starting transaction

            try {
                foreach ($batchDetails as $batchDetail) {
                    $batchDetail->forceDelete();
                }

                foreach ($studentAssignments as $studentAssignment) {
                    $studentAssignment->forceDelete();
                }

                $data->forceDelete();

                DB::commit(); // Committing transaction

                return redirect()->route('batch.trashview')->with('success', 'Batch has been permanent delete successfully.');
            } catch (\Exception $e) {
                DB::rollback(); // Rolling back transaction if an exception occurs
                return "Error occurred: " . $e->getMessage();
            }
        } else {
            return "Batch not found.";
        }
    }
}
