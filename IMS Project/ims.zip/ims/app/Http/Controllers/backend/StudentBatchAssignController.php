<?php

namespace App\Http\Controllers\backend;

use App\Http\Controllers\Controller;
use App\Models\StudentBatchAssign;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class StudentBatchAssignController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request, StudentBatchAssign $studentBatchAssign)
    {
        $batchDetailId = $request->input('BatchDetailId');
        $studentIds = $request->input('StudentId');
        $user_id = Auth::id();
        foreach ($studentIds as $studentId) {
            // Check if there is an existing association for the student and batch detail
            $existingAssignment = StudentBatchAssign::where('StudentId', $studentId)
                ->where('BatchDetailId', $batchDetailId)
                ->first();

            if ($existingAssignment) {
                // Update the existing record if needed
                $existingAssignment->update([
                    'StudentId' => $studentId,
                    'BatchDetailId' => $batchDetailId,
                    'IsActive' => '1',
                    'IsCompleted' => '0',
                    'updatedBy' => $user_id,

                ]);
            } else {
                // Create a new record if there is no existing association
                StudentBatchAssign::create([
                    'StudentId' => $studentId,
                    'BatchDetailId' => $batchDetailId,
                    'IsActive' => '1',
                    'IsCompleted' => '0',
                    'createdBy' => $user_id,
                ]);
            }
        }

        // Redirect back with success message
        return redirect()->back()->with('success', 'StudentBatchAssign records updated successfully.');
    }

    /**
     * Display the specified resource.
     */
    public function show(StudentBatchAssign $studentBatchAssign)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(StudentBatchAssign $studentBatchAssign)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, StudentBatchAssign $studentBatchAssign)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(StudentBatchAssign $studentBatchAssign,$id)
    {
        $data = StudentBatchAssign::find($id);
      
        if (!$data) {
            abort(404);
        }
        $data->forceDelete();
        return redirect()->route('batch.edit', ['id' => $data->BatchDetailId])->with('success', 'StudentBatchAssign records deleted successfully.');
    }
}
