<?php

namespace App\Http\Controllers\backend;

use App\Http\Controllers\Controller;
use App\Models\Batch;
use App\Models\CourseSubject;
use App\Models\Faculty;
use App\Models\User;
use App\Models\User_role;
use App\Models\Institute;
use App\Models\Module;
use App\Models\Student;
use App\Models\StudentCourse;
use App\Models\UserBranchRight;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Validator;
use Illuminate\Support\Facades\DB;


class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        if (Auth::check()) {
            $userRole = Auth::user()->RoleId;

            if ($userRole == 1) {
                return redirect()->route('dashboard');
            } elseif ($userRole == 4) {
                // Role 4 logic (redirect to student dashboard)
                return redirect()->route('student.dashboard');
            } elseif ($userRole == 3) {
                // Role 4 logic (redirect to student dashboard)
                return redirect()->route('faculty.dashboard');
            }
            // Add more elseif blocks for other roles as needed
        }

        // User is not authenticated or no role-based redirection was defined
        return view('backend.login.login');
    }

    /**
     * change password for superadmin
     */
    public function changepassword()
    {
        $user = auth()->user();

        return view('backend.users.changepassword', compact('user'));
    }

    public function dashboard()
    {
        $userRole = auth()->user()->RoleId;
        if ($userRole == 1) {
            // Count total number of students in the branch
            $studentCount = Student::where('BranchId', session('BranchId'))->count();
            // Count number of active students in the branch
            $activeStudentCount = Student::where('BranchId', session('BranchId'))->where('IsActive', 1)->count();
            // Count number of inactive students in the branch
            $inactiveStudentCount = Student::where('BranchId', session('BranchId'))->where('IsActive', 0)->count();

            $batchapprovalcount = Batch::join('faculty', 'batch.FacultyId', '=', 'faculty.id')
                ->where('batch.IsCompleted', 1)
                ->where('batch.IsApproved', 0)
                ->where('faculty.BranchId', session('BranchId'))
                ->count();
            $batchextenstionapprovalcount = Batch::join('faculty', 'batch.FacultyId', '=', 'faculty.id')
                ->join('batchextension', 'batch.id', '=', 'batchextension.BatchId')
                ->where('batchextension.IsApproved', 0)
                ->where('batchextension.IsActive', 0)
                ->where('faculty.BranchId', session('BranchId'))
                ->count();

            $studentDueemi = DB::table('studentfeeemi')
                ->join('student', 'studentfeeemi.StudentId', '=', 'student.id')
                ->select('student.FirstName', 'student.LastName', 'studentfeeemi.InstallmentDueDate', 'studentfeeemi.InstallmentAmount')
                ->where('studentfeeemi.IsActive', 0)
                ->whereDate('studentfeeemi.InstallmentDueDate', '<=', now()) // Filter based on InstallmentDueDate
                ->where('student.BranchId', session('BranchId')) // Filter based on BranchId
                ->get();

            return view('backend.dashboard.dashboard', compact('studentCount', 'activeStudentCount', 'inactiveStudentCount', 'batchapprovalcount', 'studentDueemi', 'batchextenstionapprovalcount'));
        } else {
            abort(403);
        }
    }

    public function studentdashboard()
    {

        $userId = auth()->id();
        // Retrieve the branch ID associated with the user
        $branchId = UserBranchRight::where('UserId', $userId)->value('BranchId');

        // Check if the branch ID is not null and matches the session's BranchId
        if ($branchId !== null && session('BranchId') == $branchId) {
            // Count the distinct SubjectId associated with the student's ID and branch ID
            $subjectCount = StudentCourse::join('student', 'student.id', '=', 'studentcourse.StudentId')
                ->where('student.UserId', $userId)
                ->where('student.BranchId', $branchId)
                ->distinct('SubjectId')
                ->count('SubjectId');
            // Count the batches associated with the student's ID
            $batchCount = DB::table('studentbatchassign')
                ->join('student', 'student.id', '=', 'studentbatchassign.StudentId')
                ->where('student.UserId', $userId)
                ->count();
            // Count the emi associated with the student's ID
            $emiCount = DB::table('studentfeeemi')
                ->join('student', 'student.id', '=', 'studentfeeemi.StudentId')
                ->where('student.UserId', $userId)
                ->count();

            $studentDueemi = DB::table('studentfeeemi')
                ->join('student', 'student.id', '=', 'studentfeeemi.StudentId')
                ->select('student.FirstName', 'student.LastName', 'studentfeeemi.InstallmentDueDate', 'studentfeeemi.InstallmentAmount')
                ->where('student.UserId', $userId)
                ->where('studentfeeemi.IsActive', 0)
                ->whereDate('studentfeeemi.InstallmentDueDate', '<=', now()) // Filter based on InstallmentDueDate
                ->get();
            $paidEmiCount = DB::table('studentfeeemi')
                ->join('student', 'student.id', '=', 'studentfeeemi.StudentId')
                ->where('student.UserId', $userId)
                ->where('studentfeeemi.IsActive', 1)
                ->count();

            return view('backend.dashboard.studentdashboard', compact('subjectCount', 'batchCount', 'emiCount', 'studentDueemi', 'paidEmiCount'));
        }

        // If branch ID is null or doesn't match, abort with a 403 Forbidden error
        abort(403);
    }
    public function facultydashboard()
    {
        $userId = auth()->id();
        // Retrieve the branch ID associated with the user
        $branchId = UserBranchRight::where('UserId', $userId)->value('BranchId');

        // Check if the branch ID is not null and matches the session's BranchId
        if ($branchId !== null && session('BranchId') == $branchId) {
            $subjectCount = Batch::join('faculty', 'faculty.id', '=', 'batch.FacultyId')
                ->join('batchdetail', 'batchdetail.BatchId', '=', 'batch.id')
                ->join('studentbatchassign', 'studentbatchassign.BatchDetailId', '=', 'batch.id')
                ->where('faculty.UserId', $userId)
                ->where('faculty.BranchId', $branchId)
                ->select(
                    'faculty.id as faculty_id',
                    DB::raw('COUNT(DISTINCT batchdetail.SubjectId) as subject_count'),
                    DB::raw('COUNT(DISTINCT batch.id) as batch_count'),
                    DB::raw('COUNT(DISTINCT studentbatchassign.StudentId) as student_count')
                )
                ->groupBy('faculty.id')
                ->first();

            $subjectCount = [
                'faculty_id' => $subjectCount->faculty_id ?? null,
                'subject_count' => $subjectCount->subject_count ?? 0,
                'batch_count' => $subjectCount->batch_count ?? 0,
                'student_count' => $subjectCount->student_count ?? 0,
            ];

            $facultyId = DB::table('faculty')
                ->where('UserId', $userId)
                ->value('id');
            $batches = Batch::where('FacultyId', $facultyId)->get();

            $completebatchcount = Batch::where('FacultyId', $facultyId)
                ->where('IsCompleted', 1)
                ->where('IsApproved', 1)
                ->count();

            return view('backend.dashboard.facultydashboard', compact('subjectCount', 'batches', 'completebatchcount'));
        }

        // If branch ID is null or doesn't match, abort with a 403 Forbidden error
        abort(403);
    }

    public function list(Request $request)
    {

        $data = User::join('userrole', 'sysuser.RoleId', '=', 'userrole.id')
            ->leftJoin('userbranchright', function ($join) {
                $join->on('userbranchright.UserId', '=', 'sysuser.id')
                    ->where('userbranchright.BranchId', '=', session('BranchId'));
            })
            ->where(function ($query) {
                $query->where('sysuser.RoleId', 1) // Include super admin records
                    ->orWhere(function ($query) {
                        $query->where('sysuser.RoleId', '!=', 1) // Exclude super admin records
                            ->whereNotNull('userbranchright.id'); // Include other roles managed by userbranchright
                    });
            })
            ->select('sysuser.*', 'userrole.RoleName as role_name')
            ->get();

        return view('backend.users.list', compact('data'));
    }
    public function create()
    {
        // $roles = User_role::all();
        $roles = User_role::whereNotIn('id', [3, 4])->get();
        $institutes = Institute::where('IsActive', '1')->get();
        $institutesid = $institutes[0]['id'];
        // $modules = Module::all();
        $modules = Module::where('id', 1)->get();

        return view('backend.users.add', compact('roles', 'institutesid', 'modules'));
    }
    /**
     * login admin
     */
    public function login(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
            'password' => 'required|min:8',
        ], [
            'email.required' => 'Please enter email address.',
            'password.required' => 'Please enter password.',
            'password.min' => 'Password must be at least 8 characters.',
        ]);
        if (Auth::attempt($request->only('email', 'password'), $request->has('remember'))) {
            // Check the role after authentication
            if (Auth::user()->RoleId == 1) {
                $request->session()->regenerate();
                return redirect()->intended(route('dashboard'))->with('success', 'Welcome ' . auth()->user()->name);
            } elseif (Auth::user()->RoleId == 4) {
                $userId = auth()->id();
                // Fetch the branch ID for the authenticated user
                $branchId = DB::table('userbranchright')
                    ->where('UserId', $userId)
                    ->value('BranchId');
                $request->session()->put('BranchId', $branchId);
                $request->session()->regenerate();
                return redirect()->intended(route('student.dashboard'))->with('success', 'Welcome ' . auth()->user()->name);
            } elseif (Auth::user()->RoleId == 3) {
                $userId = auth()->id();
                // Fetch the branch ID for the authenticated user
                $branchId = DB::table('userbranchright')
                    ->where('UserId', $userId)
                    ->value('BranchId');
                $request->session()->put('BranchId', $branchId);
                $request->session()->regenerate();
                return redirect()->intended(route('faculty.dashboard'))->with('success', 'Welcome ' . auth()->user()->name);
            } else {
                // Logout the user if the role is not 1 (admin)
                Auth::logout();
                return redirect()->route('login')->with('error', 'Unauthorized access');
            }
        }
        return redirect()->back()->with('error', 'Login failed. Please check your credentials.');
    }

    /**
     * store the specified resource.
     */
    public function store(Request $request, User $user)
    {

        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:sysuser,email',
            'password' => [
                'required',
                'string',
                'min:8',
                'confirmed',
                'regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]/',
            ],
            'password_confirmation' => 'required|string|min:8|same:password',
            'RoleId' => 'required|exists:userrole,id',
            'ModuleId' => 'required|array',
            'ModuleId.*' => 'exists:module,id',
        ], [
            'password.regex' => 'The password must contain at least one lowercase letter, one uppercase letter, one digit, and one special character.',
            'ModuleId.required' => 'Please select at least one module.',
            'ModuleId.array' => 'Invalid input for modules.',
            'ModuleId.*.exists' => 'One or more selected modules do not exist.',
        ]);
        if ($validator->fails()) {
            return redirect()->route('users.add')
                ->withErrors($validator)
                ->withInput();
        } else {
            DB::beginTransaction();
            try {
                $user_id = Auth::id();
                $user = new User;
                $user->name = ucwords($request->name);
                $user->email  = $request->email;
                $user->RoleId  = $request->RoleId;
                $user->InstituteId  = $request->InstituteId;
                $user->IsActive  = $request->IsActive;
                $user->password  = bcrypt($request->password);
                $user->createdBy = $user_id;
                $user->save();

                // Insert multiple rows into the custom pivot table
                foreach ($request->input('ModuleId') as $moduleId) {
                    DB::table('usermoduleright')->insert([
                        'UserId' => $user->id,
                        'ModuleId' => $moduleId,
                        'created_at' => now(),
                        'updated_at' => now(),
                    ]);
                }

                $userBranchRight = new UserBranchRight();
                $userBranchRight->UserId  = $user->id;
                $userBranchRight->BranchId = session('BranchId');
                $userBranchRight->createdBy = $user_id;
                $userBranchRight->save();

                // Commit the transaction if all operations are successful
                DB::commit();

                return redirect()->route('users.listing')->with('success', 'User has been added successfully.');
            } catch (\Exception $e) {
                // If an exception occurs, rollback the transaction
                DB::rollBack();
                // Handle the exception (e.g., log it, show error message)
                return back()->with('error', 'An error occurred while adding the user: ' . $e->getMessage());
            }
        }
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(User $user, $id)
    {
        $data = User::find($id);
        // $modules = Module::all();
        $modules = Module::where('id', 1)->get();
        // Get the module IDs associated with the user
        $userModuleIds = DB::table('usermoduleright')
            ->where('UserId', $data->id)
            ->pluck('ModuleId')
            ->toArray();
        $roles = User_role::all();
        return view('backend.users.edit', compact('data', 'modules', 'userModuleIds', 'roles'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, User $user, $id)
    {
        $data = User::find($id);

        $rules = [
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:sysuser,email,' . $id,
            'RoleId' => 'required|exists:userrole,id',
            'ModuleId' => 'required|array',
            'ModuleId.*' => 'exists:module,id',
        ];

        $validator = Validator::make($request->all(), $rules, [
            'password.regex' => 'The password must contain at least one lowercase letter, one uppercase letter, one digit, and one special character.',
            'ModuleId.required' => 'Please select at least one module.',
            'ModuleId.array' => 'Invalid input for modules.',
            'ModuleId.*.exists' => 'One or more selected modules do not exist.',
        ]);

        // Check if the password field is present in the request
        if ($request->has('password')) {
            $passwordRules = [
                'password' => [
                    'required',
                    'string',
                    'min:8',
                    'confirmed',
                    'regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]/',
                ],
                'password_confirmation' => 'required|string|min:8|same:password',
            ];

            // Merge password rules into the main rules array
            $rules = array_merge($rules, $passwordRules);
        }


        if ($validator->fails()) {
            return redirect()->route('users.edit', ['id' => $id])
                ->withErrors($validator)
                ->withInput();
        } else {
            DB::beginTransaction();
            try {
                $name = $request->name;
                $nameparts = explode(' ', $name, 2);
                $user_id = Auth::id();

                $data->name = ucwords($request->name);
                $data->email  = $request->email;
                $data->RoleId  = $request->RoleId;
                $data->InstituteId  = $request->InstituteId;
                $data->IsActive  = $request->IsActive;
                $data->password  = bcrypt($request->password);
                $data->updatedBy = $user_id;
                $data->save();

                $userBranchRight = UserBranchRight::where('UserId', $data->id)->first();
                if ($userBranchRight) {
                    $userBranchRight->UserId  = $data->id;
                    $userBranchRight->BranchId = $userBranchRight->BranchId;
                    $userBranchRight->updatedBy = $user_id;
                    $userBranchRight->save();
                }
                // Remove existing entries that are not present in the new set of ModuleId
                DB::table('usermoduleright')
                    ->where('UserId', $data->id)
                    ->whereNotIn('ModuleId', $request->input('ModuleId'))
                    ->delete();

                // Insert new entries into the pivot table for the updated set of ModuleId
                foreach ($request->input('ModuleId') as $moduleId) {
                    DB::table('usermoduleright')->updateOrInsert(
                        ['UserId' => $data->id, 'ModuleId' => $moduleId],
                        ['created_at' => now(), 'updated_at' => now()]
                    );
                }

                if ($data->RoleId == 3) {
                    // Retrieve faculty data
                    $faculty = Faculty::where('UserId', $data->id)->first();
                    // Update faculty data
                    $faculty->FirstName = $nameparts[0];
                    $faculty->LastName = $nameparts[1] ?? '';
                    $faculty->EmailId = $request->email;
                    // Save updated faculty data
                    $faculty->save();
                }

                if ($data->RoleId == 4) {
                    // Retrieve faculty data
                    $student = Student::where('UserId', $data->id)->first();
                    // Update faculty data
                    $student->FirstName = $nameparts[0];
                    $student->LastName = $nameparts[1] ?? '';
                    $student->EmailId = $request->email;
                    // Save updated faculty data
                    $student->save();
                }


                DB::commit();

                return redirect()->route('users.listing')->with('success', 'User has been updated successfully.');
            } catch (\Exception $e) {
                // If an exception occurs, rollback the transaction
                DB::rollBack();
                // Handle the exception (e.g., log it, show error message)
                return back()->with('error', 'An error occurred while updating the user: ' . $e->getMessage());
            }
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function trash(User $user, $id)
    {
        $data = User::find($id);
        if (!$data) {
            abort(404);
        }
        if ($data->IsActive == 0) {
            $data->delete();
            return redirect()->route('users.listing')->with('success', 'User has been trashed successfully.');
        } else {
            return redirect()->route('users.listing')->with('error', 'Invalid status on deletion,Kindly do Status make Inactive.');
        }
    }

    /**
     * trashview the specified resource from storage.
     */
    public function trashview(User $user)
    {
        $data = User::onlyTrashed()
            ->join('userrole', 'sysuser.RoleId', '=', 'userrole.id')
            ->select('sysuser.*', 'userrole.RoleName  as role_name')
            ->get();

        return view('backend.users.trash', compact('data'));
    }

    /**
     * restore the specified resource .
     */
    public function restore(User $user, $id)
    {
        // Restore a soft deleted 
        $data = User::withTrashed()->find($id);
        $data->restore();
        return redirect()->route('users.listing')->with('success', 'User has been restored successfully.');
    }
    /**
     * trash the specified resource database permanent.
     */
    public function destroy(User $user, $id)
    {
        // Permanently delete a soft deleted 
        $data = User::withTrashed()->find($id);
        $data->forceDelete();

        // other table course delete
        DB::table('usermoduleright')->where('UserId', $data->id)->delete();

        // Delete associated records from userbranchright table
        DB::table('userbranchright')->where('UserId', $data->id)->delete();

        return redirect()->route('users.trashview')->with('success', 'User has been permanent delete successfully.');
    }

    public function logout()
    {
        Auth::logout();
        return redirect()->route('login')->with('success', 'You have been successfully logged out.');
    }

    public function updatePassword(Request $request)
    {
        $request->validate([
            'password' => [
                'required',
                'string',
                'min:8',
                'confirmed',
                'regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]/',
            ],
            'password_confirmation' => 'required|string|min:8|same:password',
        ], [
            'password.required' => 'The password field is required.',
            'password.string' => 'The password must be a string.',
            'password.min' => 'The password must be at least :min characters.',
            'password.confirmed' => 'The password confirmation does not match.',
            'password.regex' => 'The password must contain at least one uppercase letter, one lowercase letter, one digit, and one special character.',
            'password_confirmation.required' => 'The password confirmation field is required.',
            'password_confirmation.string' => 'The password confirmation must be a string.',
            'password_confirmation.min' => 'The password confirmation must be at least :min characters.',
            'password_confirmation.same' => 'The password confirmation must match the password.',
        ]);
        $user = User::find($request->userid);
        if (!$user) {
            return redirect()->back()->with('error', 'User not found.');
        }

        $user->password = bcrypt($request->password);
        $user->save();

        return redirect()->back()->with('success', 'Password updated successfully.');
    }
}
