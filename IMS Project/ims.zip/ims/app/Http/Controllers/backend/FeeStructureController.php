<?php

namespace App\Http\Controllers\backend;

use App\Models\FeeStructure;
use App\Models\Course;
use App\Models\Academicyear;
use App\Models\FeeStructureMap;
use App\Http\Controllers\Controller;
use App\Models\Feehead;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Validator;
use Illuminate\Support\Facades\DB;

class FeeStructureController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $data = FeeStructure::join('course', 'feestructure.CourseId', '=', 'course.id')
            ->select('feestructure.*', 'course.Name as course_name')
            ->get();
        return view('backend.feestructure.list', compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $academicsName = Academicyear::where('IsCurrent', '1')->where('IsActive', '1')->latest()->value('Name');
        $courses = Course::where('IsActive', '1')->get();
        return view('backend.feestructure.add', compact('academicsName', 'courses'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request, FeeStructure $feeStructure)
    {
        $validator = Validator::make(request()->all(), [
            'Name' => 'required|unique:feestructure,Name',
            'EffectiveDate' => 'required|date',
            'CourseId' => 'required|exists:course,id',
            'IsActive' => 'required',
        ], [
            'Name.required' => 'Structure Name is required.',
            'Name.unique' => 'The Structure name is already taken.',

            'EffectiveDate.required' => 'Effective Date is required.',
            'EffectiveDate.date' => 'Effective Date must be a valid date.',

            'CourseId.required' => 'Course is required.',
            'CourseId.exists' => 'Selected Course is invalid.',

            'IsActive.required' => 'Status is required.',
        ]);
        if ($validator->fails()) {
            return redirect()->route('feestructure.add')
                ->withErrors($validator)
                ->withInput();
        } else {
            $user_id = Auth::id();
            $feeStructure->Name = ucwords($request->Name);
            $feeStructure->AcademicYearId = $request->AcademicYearId;
            $feeStructure->CourseId = $request->CourseId;
            $feeStructure->EffectiveDate = $request->EffectiveDate;
            $feeStructure->IsActive = $request->IsActive;
            $feeStructure->createdBy = $user_id;
            $feeStructure->save();

            return redirect()->route('feestructure.edit', ['id' => $feeStructure->id])->with('success', 'Fee Structure has been created successfully.');
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(FeeStructure $feeStructure)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(FeeStructure $feeStructure, $id)
    {
        $data = FeeStructure::find($id);
        $courses = Course::where('IsActive', '1')->get();
        $feeheads = Feehead::where('IsActive', '1')
            ->whereNotIn('id', function ($query) use ($id) {
                $query->select('FeeHeadId')
                    ->from('feestructuremap')
                    ->where('FeeStructureId', $id);
            })
            ->get();

        $feestructuremaplisting = FeeStructureMap::where('FeeStructureId', $id)
            ->join('feehead', 'feestructuremap.FeeHeadId', '=', 'feehead.id')
            ->select('feestructuremap.*', 'feehead.Name as feehead_name')
            ->get();
        return view('backend.feestructure.edit', compact('data', 'courses', 'feeheads', 'feestructuremaplisting'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, FeeStructure $feeStructure, $id)
    {
        $data = FeeStructure::find($id);
        $validator = Validator::make(request()->all(), [
            'Name' => 'required|unique:feestructure,Name,' . $id,
            'EffectiveDate' => 'required|date',
            'IsActive' => 'required',
        ], [
            'Name.required' => 'Structure Name is required.',
            'Name.unique' => 'The Structure name is already taken.',

            'EffectiveDate.required' => 'Effective Date is required.',
            'EffectiveDate.date' => 'Effective Date must be a valid date.',

            'IsActive.required' => 'Status is required.',
        ]);
        if ($validator->fails()) {
            return redirect()->route('feestructure.edit', ['id' => $id])
                ->withErrors($validator)
                ->withInput();
        } else {
            $user_id = Auth::id();
            $data->Name = ucwords($request->Name);
            $data->AcademicYearId = $request->AcademicYearId;
            $data->CourseId = $request->CourseId;
            $data->EffectiveDate = $request->EffectiveDate;
            $data->IsActive = $request->IsActive;
            $data->updatedBy = $user_id;
            $data->save();

            return redirect()->route('feestructure.listing')->with('success', 'Fee Structure has been updated successfully.');
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function trash(FeeStructure $feeStructure, $id)
    {
        $data = FeeStructure::find($id);
        if (!$data) {
            abort(404);
        }
        if ($data->IsActive == 0) {
            $data->delete();
            return redirect()->route('feestructure.listing')->with('success', 'Fee Structure has been trashed successfully.');
        } else {
            return redirect()->route('feestructure.listing')->with('error', 'Invalid status on deletion,Kindly do Status make Inactive.');
        }
    }

    /**
     * trashview the specified resource from storage.
     */
    public function trashview(FeeStructure $feeStructure)
    {
        $data = FeeStructure::onlyTrashed()
            ->join('course', 'feestructure.CourseId', '=', 'course.id')
            ->select('feestructure.*', 'course.Name as course_name')
            ->get();
        return view('backend.feestructure.trash', compact('data'));
    }

    /**
     * restore the specified resource .
     */
    public function restore(FeeStructure $feeStructure, $id)
    {
        // Restore a soft deleted 
        $data = FeeStructure::withTrashed()->find($id);
        $data->restore();
        return redirect()->route('feestructure.listing')->with('success', 'Fee Structure has been restored successfully.');
    }
    /**
     * trash the specified resource database permanent.
     */
    public function destroy(FeeStructure $feeStructure, $id)
    {
        // Permanently delete a soft deleted 
        $data = FeeStructure::withTrashed()->find($id);
       
        $data->forceDelete();

        // other table course delete
        DB::table('feestructuremap')->where('FeeStructureId', $data->id)->delete();

        return redirect()->route('feestructure.trashview')->with('success', 'Fee Structure has been permanent delete successfully.');
    }
}
