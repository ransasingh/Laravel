<?php
/**
 * code by Ranjeet Singh
 */

namespace App\Http\Controllers\backend;

use App\Models\Inquiry_fors;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Validator;
use Yajra\DataTables\Facades\DataTables;

class Inquiry_forsController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {  
        $data = Inquiry_fors::all();
        return view('backend.inquiry.list', compact('data'));       
  
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('backend.inquiry.add');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request,Inquiry_fors $inquiry_fors)
    {
       
        $validator = Validator::make(request()->all(), [
            'Name' => 'required|max:50',           
            'IsActive' => 'required',          
        ]);
        if ($validator->fails()) {
            return redirect()->route('inquiry.add')
                ->withErrors($validator)
                ->withInput();
        } else {
            $user_id = Auth::id();
            $inquiry_fors->Name = ucwords($request->Name);            
            $inquiry_fors->IsActive = $request->IsActive;
            $inquiry_fors->createdBy = $user_id;
            $inquiry_fors->save();
            return redirect()->route('inquiry.listing')->with('success', 'Inquiry has been created successfully.');
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(Inquiry_fors $inquiry_fors)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Inquiry_fors $inquiry_fors,$id)
    {
        $data = Inquiry_fors::find($id);
        return view('backend.inquiry.edit', compact('data'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Inquiry_fors $inquiry_fors,$id)
    {
        $data = Inquiry_fors::find($id);
        $validator = Validator::make(request()->all(), [
            'Name' => 'required|max:50',           
            'IsActive' => 'required',          
        ]);

        if ($validator->fails()) {
            return redirect()->route('subject.edit', ['id' => $id])
                ->withErrors($validator)
                ->withInput();
        } else {
            $user_id = Auth::id();
            $data->Name = ucwords($request->Name);            
            $data->IsActive = $request->IsActive;
            $data->createdBy = $user_id;
            $data->save();
            return redirect()->route('inquiry.listing')->with('success', 'Inquiry has been updated successfully.');
        }
    }

    public function trash(Inquiry_fors $inquiry_fors,$id)
    {
        $data = Inquiry_fors::find($id);
        if (!$data) {
            abort(404);
        }
        if ($data->IsActive == 0) {
            $data->delete();
            return redirect()->route('inquiry.listing')->with('success', 'Inquiry has been trashed successfully.');
        } else {
            return redirect()->route('inquiry.listing')->with('error', 'Invalid status on deletion,Kindly do Status make Inactive.');
        }
    }

    public function trashview(Inquiry_fors $inquiry_fors)
    {
        $data = Inquiry_fors::onlyTrashed()->latest()->get();
        return view('backend.inquiry.trash', compact('data'));
    }

    /**
     * restore the specified resource .
     */
    public function restore(Inquiry_fors $inquiry_fors, $id)
    {
        // Restore a soft deleted 
        $data = Inquiry_fors::withTrashed()->find($id);
        $data->restore();
        return redirect()->route('inquiry.listing')->with('success', 'Inquiry has been restored successfully.');
    }

     /**
     * trash the specified resource database permanent.
     */
    public function destroy(Inquiry_fors $inquiry_fors, $id)
    {
        // Permanently delete a soft deleted 
        $data = Inquiry_fors::withTrashed()->find($id);
        $data->forceDelete();
        return redirect()->route('inquiry.trashview')->with('success', 'Inquiry has been permanent delete successfully.');
    }
}
