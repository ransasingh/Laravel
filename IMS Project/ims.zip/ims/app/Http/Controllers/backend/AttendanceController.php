<?php

namespace App\Http\Controllers\backend;

use App\Http\Controllers\Controller;
use App\Models\StudentAttendance;
use App\Models\FacultyAttendance;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Validator;
use Carbon\Carbon;

class AttendanceController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'student_attendance_data' => 'required|array',
                'faculty_attendance_data' => 'required|array',

            ]);

            if ($validator->fails()) {
                $errors = $validator->errors()->all();
                return response()->json(['errors' => $errors], 422); // Return validation errors
            }

            // Check if the date is the current day
            $currentDate = Carbon::now()->format('Y-m-d');
            $requestedDate = Carbon::parse($request->input('faculty_attendance_data.ForDate'))->format('Y-m-d');

            if ($currentDate != $requestedDate) {
               return back('only currant date attendance allow');
            }

            DB::beginTransaction();

            $user_id = Auth::id();
            // Process faculty attendance
            $facultyData = $request->input('faculty_attendance_data');

            // Format the date for faculty attendance
            $facultyData['ForDate'] = Carbon::parse($facultyData['ForDate'])->format('Y-m-d');
            $facultyData['StartTime'] = $facultyData['ForDate'] . ' ' . $facultyData['StartTime']; // Concatenate date with time
            $facultyData['EndTime'] = $facultyData['ForDate'] . ' ' . $facultyData['EndTime']; // Concatenate date with time

            $existingFacultyAttendance = FacultyAttendance::where('BatchDetailId', $facultyData['BatchDetailId'])
                ->where('ForDate', $facultyData['ForDate'])
                ->first();

            if ($existingFacultyAttendance) {
                $facultyData['updatedBy'] = $user_id;
                $existingFacultyAttendance->update($facultyData); // Update existing faculty attendance
            } else {
                $facultyData['createdBy'] = $user_id;
                FacultyAttendance::create($facultyData); // Create new faculty attendance
            }

            // Process student attendance
            $studentData = $request->input('student_attendance_data');

            foreach ($studentData as &$data) {
                // Format the date for student attendance
                $data['ForDate'] = Carbon::parse($data['ForDate'])->format('Y-m-d');
                $data['StartTime'] = $data['ForDate'] . ' ' . $data['StartTime']; // Concatenate date with time
                $data['EndTime'] = $data['ForDate'] . ' ' . $data['EndTime']; // Concatenate date with time

                $existingAttendance = StudentAttendance::where('BatchDetailId', $data['BatchDetailId'])
                    ->where('ForDate', $data['ForDate'])
                    ->where('StudentId', $data['StudentId'])
                    ->first();

                if ($existingAttendance) {
                    $data['updatedBy'] = $user_id;
                    $existingAttendance->update($data); // Update existing student attendance
                } else {
                    $data['createdBy'] = $user_id;
                    StudentAttendance::create($data); // Create new student attendance
                }
            }

            DB::commit(); // Commit transaction

            return response()->json(['message' => 'Attendance saved successfully']);
        } catch (\Exception $e) {
            DB::rollBack(); // Rollback transaction on error
            return response()->json(['message' => 'Failed to save attendance', 'error' => $e->getMessage()], 500);
        }
    }


    /**
     * Display the specified resource.
     */
    public function show(StudentAttendance $studentAttendance)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(StudentAttendance $studentAttendance)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, StudentAttendance $studentAttendance)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(StudentAttendance $studentAttendance)
    {
        //
    }
}
