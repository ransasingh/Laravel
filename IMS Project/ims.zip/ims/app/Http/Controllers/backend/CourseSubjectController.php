<?php

namespace App\Http\Controllers\backend;

use App\Models\CourseSubject;
use App\Http\Controllers\Controller;
use App\Models\Course;
use App\Models\subject;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Validator;

class CourseSubjectController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $data = CourseSubject::join('course', 'coursesubject.CourseId', '=', 'course.id')
            ->join('subject', 'coursesubject.SubjectId', '=', 'subject.id')
            ->select('coursesubject.*', 'course.Name as course_name', 'subject.Name as subject_name')
            ->get();

        return view('backend.coursesubject.list', compact('data'));
    }


    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request, CourseSubject $courseSubject)
    {

        $validator = Validator::make(request()->all(), [
            'SubjectId' => 'required|exists:subject,id',
            'CourseId' => 'required|exists:course,id|unique:coursesubject,CourseId,NULL,id,SubjectId,' . request()->input('SubjectId'),
        ], [
            'SubjectId.required' => 'Please select Subject.',
            'CourseId.required' => 'Please select Course.',
            'SubjectId.exists' => 'The selected subject does not exist.',
            'CourseId.exists' => 'The selected course does not exist.',
            'CourseId.unique' => 'This combination of Course and Subject already exists.',
        ]);
        if ($validator->fails()) {
            return redirect()->route('course.edit', ['id' => $request->CourseId])
                ->withErrors($validator)
                ->withInput();
        } else {
            $user_id = Auth::id();
            $courseSubject->SubjectId = $request->SubjectId;
            $courseSubject->CourseId = $request->CourseId;
            $courseSubject->IsActive = "1";
            $courseSubject->createdBy = $user_id;
            $courseSubject->save();
            return redirect()->route('course.edit', ['id' => $request->CourseId])->with('success', 'Course subject has been created successfully.');
        }
    }


    /**
     * Remove the specified resource from storage.
     */
    public function destroy(CourseSubject $courseSubject, $id)
    {
        $data = CourseSubject::find($id);
        if (!$data) {
            abort(404);
        }
        $data->forceDelete();
        return redirect()->route('course.edit', ['id' => $data->CourseId])->with('success', 'Course subject has been deleted successfully.');
    }
}
