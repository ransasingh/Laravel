<?php

namespace App\Http\Controllers\backend;

use App\Models\Course;
use App\Http\Controllers\Controller;
use App\Models\CourseSubject;
use App\Models\Institute;
use App\Models\subject;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Validator;
use Illuminate\Support\Facades\DB;

class CourseController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $data = Course::join('institute', 'course.InstituteId', '=', 'institute.id')
            ->select('course.*', 'institute.Name as institute_name')
            ->get();
        return view('backend.course.list', compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $institutes = Institute::where('IsActive', '1')->get();
        return view('backend.course.add', compact('institutes'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request, Course $course)
    {
        $validator = Validator::make(request()->all(), [
            'Name' => 'required|unique:course,Name',
            'Code' => 'unique:course,Code',
            'IsActive' => 'required',
        ], [
            'Name.required' => 'The course name is required.',
            'Name.unique' => 'The course name is already taken.',
            'Code.unique' => 'The course code is already taken.',
            'InstituteId.required' => 'Please select Institue.',
        ]);
        if ($validator->fails()) {
            return redirect()->route('course.add')
                ->withErrors($validator)
                ->withInput();
        } else {
            $user_id = Auth::id();
            $course->Name = ucwords($request->Name);
            $course->InstituteId = '1';
            $course->IsActive = $request->IsActive;
            $course->createdBy = $user_id;
            $course->save();
            // Update the business data
            Course::where('id', $course->id)->update([
                'Code' => 'CCode-' . $course->id,
            ]);

            return redirect()->route('course.edit', ['id' => $course->id])->with('success', 'Course has been created successfully.');
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(Course $course)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Course $course, $id)
    {
        $data = Course::find($id);
        // $subjects = subject::where('IsActive', '1')->get();
        $subjects = Subject::where('IsActive', '1')
            ->whereNotIn('id', function ($query) use ($id) {
                $query->select('SubjectId')
                    ->from('coursesubject')
                    ->where('CourseId', $id);
            })
            ->get();
        $subjectlist = CourseSubject::where('CourseId', $id)
            ->join('course', 'coursesubject.CourseId', '=', 'course.id')
            ->join('subject', 'coursesubject.SubjectId', '=', 'subject.id')
            ->select('coursesubject.*', 'course.Name as course_name', 'subject.Name as subject_name')
            ->get();
        return view('backend.course.edit', compact('data', 'subjects', 'subjectlist'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Course $course, $id)
    {
        $data = Course::find($id);
        $validator = Validator::make(request()->all(), [
            'Name' => 'required|unique:course,Name,' . $id,
            'Code' => 'unique:course,Code,' . $id,
            'IsActive' => 'required',
        ], [
            'Name.required' => 'The course name is required.',
            'Name.unique' => 'The course name is already taken.',
            'Code.unique' => 'The course code is already taken.',
        ]);
        if ($validator->fails()) {
            return redirect()->route('course.edit', ['id' => $id])
                ->withErrors($validator)
                ->withInput();
        } else {
            $user_id = Auth::id();
            $data->Name = ucwords($request->Name);
            $data->InstituteId = '1';
            $data->IsActive = $request->IsActive;
            $data->updatedBy = $user_id;
            $data->save();
            // Update the business data
            Course::where('id', $data->id)->update([
                'Code' => 'CCode-' . $data->id,
            ]);

            return redirect()->route('course.listing')->with('success', 'Course has been updated successfully.');
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function trash(Course $course, $id)
    {
        $data = Course::find($id);
        if (!$data) {
            abort(404);
        }
        if ($data->IsActive == 0) {
            $data->delete();
            return redirect()->route('course.listing')->with('success', 'Course has been trashed successfully.');
        } else {
            return redirect()->route('course.listing')->with('error', 'Invalid status on deletion,Kindly do Status make Inactive.');
        }
    }

    /**
     * trashview the specified resource from storage.
     */
    public function trashview(Course $course)
    {
        $data = Course::onlyTrashed()
            ->join('institute', 'course.InstituteId', '=', 'institute.id')
            ->select('course.*', 'institute.Name as institute_name')
            ->get();
        return view('backend.course.trash', compact('data'));
    }

    /**
     * restore the specified resource .
     */
    public function restore(Course $course, $id)
    {
        // Restore a soft deleted 
        $data = Course::withTrashed()->find($id);
        $data->restore();
        return redirect()->route('course.listing')->with('success', 'Course has been restored successfully.');
    }
    /**
     * trash the specified resource database permanent.
     */
    public function destroy(Course $course, $id)
    {
        // Permanently delete a soft deleted 
        $data = Course::withTrashed()->find($id);
        $data->forceDelete();

        // other table course delete
        DB::table('coursesubject')->where('CourseId', $data->id)->delete();

        return redirect()->route('course.trashview')->with('success', 'Course has been permanent delete successfully.');
    }
}
