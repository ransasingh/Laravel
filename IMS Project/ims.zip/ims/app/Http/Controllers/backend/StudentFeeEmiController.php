<?php

namespace App\Http\Controllers\backend;

use App\Http\Controllers\Controller;
use App\Models\Feereceiptdetail;
use App\Models\FeeStructure;
use App\Models\FeeStructureMap;
use App\Models\Student;
use App\Models\StudentFeeEmi;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Validator;
use Illuminate\Validation\ValidationException;


class StudentFeeEmiController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request, StudentFeeEmi $studentFeeEmi)
    {

        // Validate the request data
        $validator = $request->validate([
            'emiData' => 'required|array',
            'emiData.*.installmentAmount' => 'required|numeric|min:0',
            'emiData.*.dueDate' => 'required|date',
            'emiData.*.isPaid' => 'required|boolean',
            'studentId' => 'required',
            'feeStructureId' => 'required',

        ]);

        // Retrieve and process the validated data
        $emiData = $validator['emiData'];
        $studentId = $validator['studentId'];
        $feeStructureId = $validator['feeStructureId'];

        // Fetch the total amount from the student table
        $results = DB::table('student')
            ->select(
                'student.TotalFeeAmount',
                DB::raw('COALESCE(SUM(feereceiptdetail.Amount), 0) as sum_amount')
            )
            ->leftJoin('feereceipt', 'student.id', '=', 'feereceipt.StudentId')
            ->leftJoin('feereceiptdetail', 'feereceipt.id', '=', 'feereceiptdetail.FeeReceiptId')
            ->where('student.id', $studentId)
            ->groupBy('student.id', 'student.TotalFeeAmount')
            ->first();
        $totalAmount = $results->TotalFeeAmount;
        $sumAmount = $results->sum_amount;
        $remainingAmount = $totalAmount - $sumAmount;
        // Calculate the total installment amount from the request data
        $totalInstallmentAmount = array_sum(array_column($emiData, 'installmentAmount'));

        // Check if adding new installments would exceed or equal the remaining amount
        if ($remainingAmount < $totalInstallmentAmount) {
            return response()->json([
                'message' => 'Adding new installments would exceed or equal the remaining amount.',
            ], 400);
        }

        // Save the new EMI data
        foreach ($emiData as $emiItem) {
            StudentFeeEmi::create([
                'StudentId' => $studentId,
                'FeeStructureId' => $feeStructureId,
                'InstallmentAmount' => $emiItem['installmentAmount'],
                'InstallmentDueDate' => $emiItem['dueDate'],
                'IsActive' => $emiItem['isPaid'],
            ]);
        }

        return response()->json([
            'message' => 'Data saved successfully',
            'StudentId' => $studentId,
        ]);
    }

    /**
     * Display the specified resource.
     */
    public function show(StudentFeeEmi $studentFeeEmi, $studentId)
    {

        $installments = StudentFeeEmi::where('StudentId', $studentId)->get();

     
        return response()->json(['installments' => $installments]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(StudentFeeEmi $studentFeeEmi)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, StudentFeeEmi $studentFeeEmi)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($installmentId, $studentId)
    {
        $installment = StudentFeeEmi::find($installmentId);

        if (!$installment) {
            return redirect()->back()->with('error', 'Installment not found');
        }

        $installment->delete();

        return redirect()->back()->with('success', 'Installment deleted successfully');
    }
}
