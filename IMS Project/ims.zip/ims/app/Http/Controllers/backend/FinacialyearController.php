<?php

namespace App\Http\Controllers\backend;

use App\Http\Controllers\Controller;
use App\Models\Finacialyear;
use App\Models\Institute;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Validator;
use Carbon\Carbon;


class FinacialyearController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $data = Finacialyear::all();
        return view('backend.finacialyear.list', compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $institutes = Institute::where('IsActive', '1')->get();
        $institutesid = $institutes[0]['id'];

        return view('backend.finacialyear.add', compact('institutesid'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request,Finacialyear $finacialyear)
    {
        $validator = Validator::make(request()->all(), [
            'Name' => ['required', 'regex:/^\d{4}$/', 'unique:finacialyear,Name'],
            'FromDate' => 'required|date',
            'ToDate' => [
                'required',
                'date',
                'after:FromDate',
                function ($attribute, $value, $fail) use ($request) {
                    $fromDate = Carbon::parse($request->input('FromDate'));
                    $toDate = Carbon::parse($value);

                    // Check if 'ToDate' is within 12 months after 'FromDate'
                    if ($toDate->diffInMonths($fromDate) > 12) {
                        $fail('The To Date must be within 12 months after the From Date.');
                    }
                },
            ],
            'IsCurrent' => 'required',
            'IsActive' => 'required',

        ], [
            'Name.regex' => 'Please enter a valid four-digit year.',
            'Name.unique' => 'This year is already taken. Please choose a different one.',
            'FromDate.required' => 'The from date field is required.',
            'FromDate.date' => 'The from date must be a valid date.',
            'ToDate.required' => 'The to date field is required.',
            'ToDate.date' => 'The to date must be a valid date.',
            'ToDate.after' => 'The to date must be after the from date.',
            'IsCurrent.required' => 'The is current field is required.',
            'IsActive.required' => 'The is active field is required.',
        ]);
        if ($validator->fails()) {
            return redirect()->route('finacialyear.add')
                ->withErrors($validator)
                ->withInput();
        } else {
            $user_id = Auth::id();
            $finacialyear->Name = $request->Name;
            $finacialyear->FromDate  = $request->FromDate;
            $finacialyear->ToDate  = $request->ToDate;
            $finacialyear->InstituteId  = $request->InstituteId;
            $finacialyear->IsCurrent  = $request->IsCurrent;
            $finacialyear->IsActive = $request->IsActive;
            $finacialyear->createdBy = $user_id;
            $finacialyear->save();
            return redirect()->route('finacialyear.listing')->with('success', 'Finacial year has been created successfully.');
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(Finacialyear $finacialyear)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Finacialyear $finacialyear,$id)
    {
        $data = Finacialyear::find($id);
        return view('backend.finacialyear.edit', compact('data'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Finacialyear $finacialyear,$id)
    {
        $data = Finacialyear::find($id);
        $validator = Validator::make(request()->all(), [
            'Name' => ['required', 'regex:/^\d{4}$/', 'unique:finacialyear,Name,' . $id],
            'FromDate' => 'required|date',
            'ToDate' => [
                'required',
                'date',
                'after:FromDate',
                function ($attribute, $value, $fail) use ($request) {
                    $fromDate = Carbon::parse($request->input('FromDate'));
                    $toDate = Carbon::parse($value);

                    // Check if 'ToDate' is within 12 months after 'FromDate'
                    if ($toDate->diffInMonths($fromDate) > 12) {
                        $fail('The To Date must be within 12 months after the From Date.');
                    }
                },
            ],
            'IsCurrent' => 'required',
            'IsActive' => 'required',

        ], [
            'Name.regex' => 'Please enter a valid four-digit year.',
            'Name.unique' => 'This year is already taken. Please choose a different one.',
            'FromDate.required' => 'The from date field is required.',
            'FromDate.date' => 'The from date must be a valid date.',
            'ToDate.required' => 'The to date field is required.',
            'ToDate.date' => 'The to date must be a valid date.',
            'ToDate.after' => 'The to date must be after the from date.',
            'IsCurrent.required' => 'The is current field is required.',
            'IsActive.required' => 'The is active field is required.',
        ]);
        if ($validator->fails()) {
            return redirect()->route('finacialyear.edit', ['id' => $id])
                ->withErrors($validator)
                ->withInput();
        } else {
            $user_id = Auth::id();
            $data->Name = $request->Name;
            $data->FromDate  = $request->FromDate;
            $data->ToDate  = $request->ToDate;
            $data->InstituteId  = $request->InstituteId;
            $data->IsCurrent  = $request->IsCurrent;
            $data->IsActive = $request->IsActive;
            $data->updatedBy = $user_id;
            $data->save();
            return redirect()->route('finacialyear.listing')->with('success', 'Finacial year has been updated successfully.');
        }
    }

   /**
     * Remove the specified resource from storage.
     */
    public function trash( Finacialyear $finacialyear, $id)
    {
        $data = Finacialyear::find($id);
        if (!$data) {
            abort(404);
        }
        if ($data->IsActive == 0) {
            $data->delete();
            return redirect()->route('finacialyear.listing')->with('success', 'Finacial year has been trashed successfully.');
        } else {
            return redirect()->route('finacialyear.listing')->with('error', 'Invalid status on deletion,Kindly do Status make Inactive.');
        }
    }

    /**
     * trashview the specified resource from storage.
     */
    public function trashview( Finacialyear $finacialyear)
    {
        $data = Finacialyear::onlyTrashed()->latest()->get();
        return view('backend.finacialyear.trash', compact('data'));
    }

    /**
     * restore the specified resource .
     */
    public function restore( Finacialyear $finacialyear, $id)
    {
        // Restore a soft deleted 
        $data = Finacialyear::withTrashed()->find($id);
        $data->restore();
        return redirect()->route('finacialyear.listing')->with('success', 'Finacial year has been restored successfully.');
    }
    /**
     * trash the specified resource database permanent.
     */
    public function destroy( Finacialyear $finacialyear, $id)
    {
        // Permanently delete a soft deleted 
        $data = Finacialyear::withTrashed()->find($id);
        $data->forceDelete();

        return redirect()->route('finacialyear.trashview')->with('success', 'Finacial year has been permanent delete successfully.');
    }
}
