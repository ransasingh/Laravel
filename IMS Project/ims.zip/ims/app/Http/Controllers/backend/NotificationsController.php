<?php

namespace App\Http\Controllers\backend;

use App\Models\Notifications;
use App\Http\Controllers\Controller;
use App\Models\User_role;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Validator;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class NotificationsController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $data =  Notifications::all();
        return view('backend.notifications.list', compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $roles = User_role::all();
        return view('backend.notifications.add', compact('roles'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request, Notifications $notifications)
    {
        $validator = Validator::make(request()->all(), [
            'Subject' => 'required|string|max:255',
            'FromDate' => 'required|date',
            'ToDate' => 'required|date|after_or_equal:FromDate',
            'Body' => 'required|string',
            'IsActive' => 'required',
            'RoleId' => 'required|array',
        ], [
            'FromDate.required' => 'The From Date field is required.',
            'ToDate.required' => 'The To Date field is required.',
            'ToDate.after_or_equal' => 'The To Date must be after or equal to the From Date.',
            'RoleId.required' => 'Please Checked at least one Role.',
        ]);
        if ($validator->fails()) {
            return redirect()->route('notifications.add')
                ->withErrors($validator)
                ->withInput();
        } else {
            try {

                DB::beginTransaction();

                $user_id = Auth::id();
                $notifications->Subject = ucwords($request->Subject);
                $notifications->Body = $request->Body;
                $notifications->FromDate = $request->FromDate;
                $notifications->ToDate = $request->ToDate;
                $notifications->IsActive = $request->IsActive;
                $notifications->createdBy = $user_id;
                $notifications->save();

                // Insert multiple rows into the custom pivot table
                foreach ($request->input('RoleId') as $RoleId) {
                    DB::table('notificationrole')->insert([
                        'NotificationId' => $notifications->id,
                        'RoleId' => $RoleId,
                        'created_at' => now(),
                        'updated_at' => now(),
                    ]);
                }
                DB::commit();

                // Redirect back with success message if successful
                return redirect()->route('notifications.listing')->with('success', 'Notifications have been created successfully.');
            } catch (\Exception $e) {
                // If an exception occurs, roll back the database transaction
                DB::rollBack();

                // Log the error or handle it accordingly
                // For now, we'll redirect back with an error message
                return redirect()->back()->with('error', 'An error occurred while creating notifications. Please try again.');
            }
        }
    }

    /**
     * Display the specified resource.
     */
    public function show($id = null)
    {
        // Get the authenticated user's role ID
        $userRoleId = Auth::user()->RoleId;
        $currentDate = now()->toDateString();

        // Query to fetch notifications associated with the user's role and within the valid date range
        $query = DB::table('notificationrole')
            ->join('notification', 'notificationrole.NotificationId', '=', 'notification.id')
            ->where('notificationrole.RoleId', $userRoleId)
            ->where('notification.FromDate', '<=', $currentDate)
            ->where('notification.ToDate', '>=', $currentDate)
            ->select('notification.id', 'notification.Subject','notification.Body');

        // If an ID is provided, filter by that ID
        if ($id !== null) {
            $notification = $query->where('notification.id', $id)->first();
            if ($notification) {
                return response()->json([$notification]);
            } else {
                return response()->json(['error' => 'Notification not found.'], 404);
            }
        }

        // If no ID is provided, fetch all notifications
        $notifications = $query->get();

        return response()->json($notifications);
    }

    public function count()
    {
        // Get the authenticated user's role ID
        $userRoleId = Auth::user()->RoleId;

        // Get the current date
        $currentDate = Carbon::now()->toDateString();

        // Count notifications based on the user's role and within the valid date range
        $count = DB::table('notificationrole')
            ->join('notification', 'notificationrole.NotificationId', '=', 'notification.id')
            ->where('notificationrole.RoleId', $userRoleId)
            ->where('notification.FromDate', '<=', $currentDate)
            ->where('notification.ToDate', '>=', $currentDate)
            ->count();

        return response()->json(['count' => $count]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Notifications $notifications, $id)
    {
        $data = Notifications::find($id);
        $roles = User_role::all();
        $notificationroleIds = DB::table('notificationrole')
            ->where('NotificationId', $data->id)
            ->pluck('RoleId')
            ->toArray();

        return view('backend.notifications.edit', compact('data', 'roles', 'notificationroleIds'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Notifications $notifications, $id)
    {
        $data = Notifications::find($id);
        $validator = Validator::make(request()->all(), [
            'Subject' => 'required|string|max:255',
            'FromDate' => 'required|date',
            'ToDate' => 'required|date|after_or_equal:FromDate',
            'Body' => 'required|string',
            'IsActive' => 'required',
            'RoleId' => 'required|array',
        ], [
            'FromDate.required' => 'The From Date field is required.',
            'ToDate.required' => 'The To Date field is required.',
            'ToDate.after_or_equal' => 'The To Date must be after or equal to the From Date.',
            'RoleId.required' => 'Please Checked at least one Role.',
        ]);

        if ($validator->fails()) {
            return redirect()->route('notifications.edit', ['id' => $id])
                ->withErrors($validator)
                ->withInput();
        } else {
            try {
                DB::beginTransaction();
                $user_id = Auth::id();
                $data->Subject = ucwords($request->Subject);
                $data->Body = $request->Body;
                $data->FromDate = $request->FromDate;
                $data->ToDate = $request->ToDate;
                $data->IsActive = $request->IsActive;
                $data->updatedBy = $user_id;
                $data->save();

                // Remove existing entries that are not present in the new set of ModuleId
                DB::table('notificationrole')
                    ->where('NotificationId', $data->id)
                    ->whereNotIn('RoleId', $request->input('RoleId'))
                    ->delete();

                // Insert new entries into the pivot table for the updated set of ModuleId
                foreach ($request->input('RoleId') as $RoleId) {
                    DB::table('notificationrole')->updateOrInsert(
                        ['NotificationId' => $data->id, 'RoleId' => $RoleId],
                        ['created_at' => now(), 'updated_at' => now()]
                    );
                }
                DB::commit();

                return redirect()->route('notifications.listing')->with('success', 'Notifications has been updated successfully.');
            } catch (\Exception $e) {
                DB::rollBack();
                return redirect()->back()->with('error', 'An error occurred while updating notifications. Please try again.');
            }
        }
    }

    public function trash(Notifications $notifications, $id)
    {
        $data = Notifications::find($id);
        if (!$data) {
            abort(404);
        }
        if ($data->IsActive == 0) {
            $data->delete();
            return redirect()->route('notifications.listing')->with('success', 'Notifications has been trashed successfully.');
        } else {
            return redirect()->route('notifications.listing')->with('error', 'Invalid status on deletion,Kindly do Status make Inactive.');
        }
    }
    public function trashview(Notifications $notifications)
    {
        $data = Notifications::onlyTrashed()->latest()->get();
        return view('backend.notifications.trash', compact('data'));
    }

    /**
     * Remove the specified resource from storage.
     */
    public function restore(Notifications $notifications, $id)
    {
        // Restore a soft deleted 
        $data = Notifications::withTrashed()->find($id);
        $data->restore();
        return redirect()->route('notifications.listing')->with('success', 'Notifications has been restored successfully.');
    }

    /**
     * trash the specified resource database permanent.
     */
    public function destroy(Notifications $notifications, $id)
    {
        // Permanently delete a soft deleted 
        $data = Notifications::withTrashed()->find($id);
        $data->forceDelete();
        // other table course delete
        DB::table('notificationrole')->where('NotificationId', $data->id)->delete();

        return redirect()->route('notifications.trashview')->with('success', 'Notifications has been permanent delete successfully.');
    }
}
