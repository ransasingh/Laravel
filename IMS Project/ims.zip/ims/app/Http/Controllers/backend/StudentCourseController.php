<?php

namespace App\Http\Controllers\backend;

use App\Http\Controllers\Controller;
use App\Models\Academicyear;
use App\Models\StudentCourse;
use Illuminate\Http\Request;
use App\Models\Student;
use App\Models\subject;
use App\Models\UserBranchRight;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Validator;

class StudentCourseController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create(Request $request)
    {
        $student = Student::find($request->id);
        $sid = $student->id;

        $subjects = Subject::where('IsActive', '1')
            ->whereNotIn('id', function ($query) use ($sid) {
                $query->select('SubjectId')
                    ->from('studentcourse')
                    ->where('StudentId', $sid);
            })
            ->get();

        $academicyears = Academicyear::where('IsActive', '1')->get();

        if ($student) {
            $data = StudentCourse::join('subject', 'studentcourse.SubjectId', '=', 'subject.id')
                ->where('StudentId', $sid)
                ->get(['studentcourse.*', 'subject.Name as subject_name']);

            return view('backend.studentcourse.add', compact('data', 'subjects', 'academicyears'));
        } else {
            abort(404);
        }
    }


    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request, StudentCourse $studentCourse)
    {
        $validator = Validator::make(request()->all(), [
            'SubjectId' => 'required',
            'AcademicYearId' => 'required',

        ], [
            'SubjectId.required' => 'Select Subject.',
            'AcademicYearId.required' => 'Select Academic year.',
        ]);
        if ($validator->fails()) {
            return redirect()->back()
                ->withErrors($validator)
                ->withInput();
        } else {
            $user_id = Auth::id();
            $studentCourse->SubjectId = $request->SubjectId;
            $studentCourse->AcademicYearId = $request->AcademicYearId;
            $studentCourse->IsExraSubject = $request->IsExraSubject;
            $studentCourse->StudentId = $request->StudentId;
            $studentCourse->IsActive = $request->IsActive;
            $studentCourse->createdBy = $user_id;
            $studentCourse->save();
            return redirect()->route('studentcourse.add', ['id' => $request->StudentId])->with('success', 'Student Course has been created successfully.');
        }
    }

    /**
     * Display the specified resource.
     */
    public function detail(StudentCourse $studentCourse)
    {
        $userId = auth()->id();
        // Retrieve the branch ID associated with the user
        $branchId = UserBranchRight::where('UserId', $userId)->value('BranchId');
        if ($branchId !== null && session('BranchId') == $branchId) {
            $data = DB::table('student')
                ->join('studentcourse', 'student.id', '=', 'studentcourse.StudentId')
                ->join('subject', 'studentcourse.SubjectId', '=', 'subject.id')
                ->where('student.UserId', $userId)
                ->select('studentcourse.*', 'subject.Name as subject_name')
                ->get();
            return view('backend.studentcourse.detail', compact('data'));
        }
        abort(403);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(StudentCourse $studentCourse)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, StudentCourse $studentCourse)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(StudentCourse $studentCourse, $id)
    {
        $data = StudentCourse::find($id);
        if (!$data) {
            abort(404);
        }
        $data->forceDelete();
        return redirect()->route('studentcourse.add', ['id' => $data->StudentId])->with('success', 'Student Course has been deleted successfully.');
    }
}
