<?php

namespace App\Http\Controllers\backend;

use App\Models\subject;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Validator;
use Yajra\DataTables\Facades\DataTables;

class subjectController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $data = subject::all();
        return view('backend.subject.list', compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('backend.subject.add');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request, subject $subject)
    {

        $validator = Validator::make(request()->all(), [
            'Name' => 'required|unique:subject,Name',
            'IsActive' => 'required',
            'NoOfSession' => 'required',
        ]);
        if ($validator->fails()) {
            return redirect()->route('subject.add')
                ->withErrors($validator)
                ->withInput();
        } else {
            $user_id = Auth::id();
            $subject->Name = ucwords($request->Name);
            $subject->NoOfSession = $request->NoOfSession;
            $subject->IsActive = $request->IsActive;
            $subject->createdBy = $user_id;
            $subject->save();

            subject::where('id', $subject->id)->update([
                'Code' => 'SCode-' . $subject->id,
            ]);
            return redirect()->route('subject.listing')->with('success', 'Subject has been created successfully.');
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(subject $subject)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(subject $subject, $id)
    {
        $data = subject::find($id);
        return view('backend.subject.edit', compact('data'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, subject $subject, $id)
    {
        $data = subject::find($id);
        $validator = Validator::make(request()->all(), [
            'Name' => 'required|unique:subject,Name,' . $id,
            'IsActive' => 'required',
            'NoOfSession' => 'required',
        ]);

        if ($validator->fails()) {
            return redirect()->route('subject.edit', ['id' => $id])
                ->withErrors($validator)
                ->withInput();
        } else {
            $user_id = Auth::id();
            $data->Name = ucwords($request->Name);
            $data->NoOfSession = $request->NoOfSession;
            $data->IsActive = $request->IsActive;
            $data->createdBy = $user_id;
            $data->save();

            subject::where('id', $data->id)->update([
                'Code' => 'SCode-' . $data->id,
            ]);

            return redirect()->route('subject.listing')->with('success', 'Subject has been updated successfully.');
        }
    }
    public function trash(subject $subject, $id)
    {
        $data = subject::find($id);
        if (!$data) {
            abort(404);
        }
        if ($data->IsActive == 0) {
            $data->delete();
            return redirect()->route('subject.listing')->with('success', 'Subject has been trashed successfully.');
        } else {
            return redirect()->route('subject.listing')->with('error', 'Invalid status on deletion,Kindly do Status make Inactive.');
        }
    }
    public function trashview(subject $subject)
    {
        $data = subject::onlyTrashed()->latest()->get();
        return view('backend.subject.trash', compact('data'));
    }
    /**
     * restore the specified resource .
     */
    public function restore(subject $subject, $id)
    {
        // Restore a soft deleted 
        $data = subject::withTrashed()->find($id);
        $data->restore();
        return redirect()->route('subject.listing')->with('success', 'Subject has been restored successfully.');
    }

    /**
     * trash the specified resource database permanent.
     */
    public function destroy(subject $subject, $id)
    {
        // Permanently delete a soft deleted 
        $data = subject::withTrashed()->find($id);
        $data->forceDelete();
        return redirect()->route('subject.trashview')->with('success', 'Subject has been permanent delete successfully.');
    }
}
