<?php

namespace App\Http\Controllers\backend;

use App\Models\Faculty;
use App\Models\State;
use App\Models\Institute;
use App\Models\User;
use App\Http\Controllers\Controller;
use App\Models\Batch;
use App\Models\FacultyAttendance;
use App\Models\Student;
use App\Models\StudentBatchAssign;
use App\Models\UserBranchRight;
use App\Models\Usermoduleright;
use App\Models\Portfoliosubmission;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Validator;
use Carbon\Carbon;

class FacultyController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $data = Faculty::join('state', 'faculty.StateId', '=', 'state.id')
            ->select('faculty.*', 'state.Name as state_name') // Add other fields from the state table as needed
            ->where('BranchId', session('BranchId'))
            ->get();

        return view('backend.faculty.list', compact('data'));
    }
    /**
     * change password for faculty
     */
    public function changepassword()
    {
        $user = auth()->user();

        return view('backend.faculty.changepassword', compact('user'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $institutes = Institute::where('IsActive', '1')->get();
        $institutesid = $institutes[0]['id'];
        $states = State::where('IsActive', '1')->get();
        return view('backend.faculty.add', compact('institutesid', 'states'));
    }
    /**
     * Show the form for creating a new resource.
     */
    public function calender(Request $request)
    {
        $userRole = auth()->user()->RoleId;

        // Initialize student ID
        $facultyId = null;

        // Check if the user role is 4 (presumably a student)
        if ($userRole == 3) {
            // If the user is a student, fetch their ID from the authenticated user
            $authUserId = auth()->user()->id;

            $Faculty = Faculty::where('UserId', $authUserId)->first();
            // Check if a student with the authenticated user's ID exists
            if ($Faculty) {
                // If a student is found, use their ID as the student ID
                $id = $Faculty->id;
            } else {
                abort(404);
            }
        } else {
            // If the user is not a student, retrieve the student ID from the request
            $id = $request->id;
        }

        // Fetch all batches for the given faculty ID within the date range
        $allbatches = Batch::where('FacultyId', $id)
            ->whereDate('FromDate', '<=', now())
            ->whereDate('ToDate', '>=', now())
            ->where('IsCompleted', 0)
            ->join('batchdetail', 'batch.id', '=', 'batchdetail.BatchId')
            ->select('batch.*', 'batchdetail.BatchDay')
            ->get();
        if ($allbatches->isEmpty()) {
            // Redirect back with an error message
            return view('backend.faculty.blankcalender');
        }
        // Transform batches into day-wise format
        $batches = [];
        foreach ($allbatches as $batch) {
            $startDate = Carbon::parse($batch->FromDate);
            $endDate = Carbon::parse($batch->ToDate);
            $daysDiff = $endDate->diffInDays($startDate);

            for ($i = 0; $i <= $daysDiff; $i++) {
                $date = $startDate->copy()->addDays($i);
                $dayOfWeek = $date->dayOfWeek;

                if (strpos($batch->BatchDay, (string)$dayOfWeek) !== false) {
                    $batches[$date->format('Y-m-d')][] = [
                        'BatchId' => $batch->id,
                        'Name' => $batch->Name,
                        'FromDate' => $batch->FromDate,
                        'ToDate' => $batch->ToDate,
                        'StudentCapacity' => $batch->StudentCapacity,
                        'StartTimeInMinutes' => $batch->StartTimeInMinutes,
                        'EndTimeInMinutes' => $batch->EndTimeInMinutes,
                        'FacultyId' => $batch->FacultyId,

                    ];
                }
            }
        }

        // Extract faculty IDs from the batches
        $facultyIds = [];
        foreach ($allbatches as $batch) {
            $facultyIds[] = $batch->FacultyId;
        }
        $facultyIds = array_unique($facultyIds);

        // Retrieve faculty users
        $facultyUsers = Faculty::whereIn('id', $facultyIds)->pluck('UserId', 'id');

        // Get the faculty user ID for the current faculty
        $facultyUserId = $facultyUsers[$id] ?? null;
        // Check authorization
        if (isset($facultyUserId) || auth()->user()->RoleId == 1) {
            // Fetch students enrolled in the batches
            $students = DB::table('student')
                ->join('studentbatchassign', 'student.id', '=', 'studentbatchassign.StudentId')
                ->join('batch', 'studentbatchassign.BatchDetailId', '=', 'batch.id')
                ->join('course', 'student.CourseId', '=', 'course.id')
                ->whereIn('batch.id', $allbatches->pluck('id')->toArray())
                ->select('student.id', 'student.FirstName', 'student.LastName', 'student.CourseId', 'course.Name AS course_name')
                ->distinct()
                ->get();
            // Check authorization again (in case faculty ID is not found in batches)
            if (auth()->user()->RoleId == 1 || (auth()->user()->RoleId == 3 && $facultyUserId == auth()->id())) {

                return view('backend.faculty.calender', compact('batches', 'students'));
            } else {
                // User is not authorized, redirect back or display an error
                return redirect()->back()->with('error', 'You are not authorized.');
            }
        }
        // If faculty ID is not found in batches or faculty user ID is not found
        abort(404);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request, Faculty $faculty)
    {

        $validator = Validator::make(request()->all(), [
            'FirstName' => 'required|string',
            'LastName' => 'required|string',
            'MobileNumber' => 'required|numeric|digits:10',
            'EmailId' => 'required|email|max:255|unique:sysuser,email',
            'password' => [
                'required',
                'string',
                'min:8',
                'confirmed',
                'regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]/',
            ],
            'password_confirmation' => 'required|string|min:8|same:password',

            'AddressLine1' => 'required',
            'StateId' => 'required|integer',
            'CityName' => 'required|string',
            'PostalCode' => 'required',
            'PrAddressLine1' => 'required',
            'PrStateId' => 'required|integer',
            'PrCityName' => 'required',
            'EmergencyContactNumber' => 'required|numeric|digits:10',
            'BloodGroup' => 'required',

            'ProfileImage' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
            'SignImage' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',

        ], [
            'EmailId.required' => 'Email is required',
            'EmailId.unique' => 'The provided email address is already in use',
            'FirstName.required' => 'First name is required',
            'LastName.required' => 'Last name is required',
            'MobileNumber.required' => 'Mobile number is required',
            'MobileNumber.numeric' => 'Mobile number must be numeric',
            'MobileNumber.digits' => 'Mobile number must be 10 digits',
            'password.regex' => 'The password must contain at least one lowercase letter, one uppercase letter, one digit, and one special character.',

            'AddressLine1.required' => 'Address is required',
            'PrAddressLine1.required' => 'Permanent address is required',
            'StateId.required' => 'Select state.',
            'PrStateId.required' => 'Select state.',
            'DOB.required' => 'Date of Birth is required.',
            'PrCityName.required' => 'Permanent city name is required.',

            'ProfileImage.nullable' => 'Profile image must be an image',
            'ProfileImage.image' => 'Profile image must be a valid image file',
            'ProfileImage.mimes' => 'Profile image must be in one of the formats: jpeg, png, jpg, gif',
            'ProfileImage.max' => 'Profile image cannot exceed 2048 kilobytes',

            'SignImage.nullable' => 'Signature image must be an image',
            'SignImage.image' => 'Signature image must be a valid image file',
            'SignImage.mimes' => 'Signature image must be in one of the formats: jpeg, png, jpg, gif',
            'SignImage.max' => 'Signature image cannot exceed 2048 kilobytes',
        ]);

        if ($validator->fails()) {

            return redirect()->route('faculty.add')
                ->withErrors($validator)
                ->withInput();
        } else {

            DB::beginTransaction();
            try {
                $user_id = Auth::id();
                $user = new User;
                $user->name = $request->FirstName . " " . $request->LastName;
                $user->email   =  $request->EmailId;
                $user->password = bcrypt($request->password);
                $user->IsActive = '1';
                $user->RoleId = '3';
                $user->InstituteId = $request->InstituteId;
                $user->createdBy = $user_id;
                $user->save();

                $userBranchRight = new UserBranchRight;
                $userBranchRight->UserId  = $user->id;
                $userBranchRight->BranchId = session('BranchId');
                $userBranchRight->createdBy = $user_id;
                $userBranchRight->save();

                $usermoduleright = new Usermoduleright();
                $usermoduleright->UserId  = $user->id;
                $usermoduleright->ModuleId  = '1';
                $usermoduleright->save();

                $faculty = new Faculty;
                if ($request->hasFile('ProfileImage')) {
                    $ProfileImage = time() . '.' . $request->ProfileImage->getClientOriginalExtension();
                    $request->ProfileImage->move(public_path('uploads/faculty/profile'), $ProfileImage);
                    $faculty->ProfileImage = $ProfileImage;
                } else {
                    $faculty->ProfileImage = 'default.jpg';
                }
                if ($request->hasFile('SignImage')) {
                    $SignImage = time() . '.' . $request->SignImage->getClientOriginalExtension();
                    $request->SignImage->move(public_path('uploads/faculty/signature'), $SignImage);
                    $faculty->SignImage = $SignImage;
                } else {
                    $faculty->SignImage = 'sign.jpg';
                }

                $faculty->FirstName = ucwords($request->FirstName);
                $faculty->LastName = ucwords($request->LastName);
                $faculty->MobileNumber = $request->MobileNumber;
                $faculty->EmailId = $request->EmailId;
                $faculty->AddressLine1 = $request->AddressLine1;
                $faculty->AddressLine2 = $request->AddressLine2;
                $faculty->StateId = $request->StateId;
                $faculty->CityName = $request->CityName;
                $faculty->PostalCode = $request->PostalCode;
                $faculty->InstituteId = $request->InstituteId;
                $faculty->UserId = $user->id;
                $faculty->createdBy = $user_id;
                $faculty->PrAddressLine1 = $request->PrAddressLine1;
                $faculty->PrAddressLine2 = $request->PrAddressLine2;
                $faculty->PrStateId = $request->PrStateId;
                $faculty->PrCityName = $request->PrCityName;
                $faculty->EmergencyContactNumber = $request->EmergencyContactNumber;
                $faculty->BloodGroup = $request->BloodGroup;
                $faculty->IsActive = $request->IsActive;
                $faculty->BranchId = session('BranchId');
                $faculty->save();
                $currentMonth = now()->format('M');
                $currentYear = now()->format('Y');
                // Update the business data
                Faculty::where('id', $faculty->id)->update([
                    'EmployeeCode' => 'F-' . $currentMonth . '-' . $currentYear . '-' . $faculty->id,
                ]);
                DB::commit();
                return redirect()->route('faculty.listing')->with('success', 'Faculty has been created successfully.');
            } catch (\Exception $e) {
                DB::rollBack();

                return redirect()->back()->withInput()->withErrors(['error' => $e->getMessage()]);
            }
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(Faculty $faculty)
    {
        $userId = auth()->id();
        // Retrieve the branch ID associated with the user
        $branchId = UserBranchRight::where('UserId', $userId)->value('BranchId');
        // Check if the branch ID is not null and matches the session's BranchId
        if ($branchId !== null && session('BranchId') == $branchId) {
            $record = Faculty::where('UserId', $userId)
                ->join('state', 'faculty.StateId', '=', 'state.id')
                ->select('faculty.*', 'state.Name as state_name')
                ->first();

            return view('backend.faculty.show', compact('record'));
        }
        abort(403);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Faculty $faculty, $id)
    {
        $data = Faculty::find($id);
        $states = State::where('IsActive', '1')->get();
        return view('backend.faculty.edit', compact('data', 'states'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Faculty $faculty, $id)
    {
        $data = Faculty::find($id);
        $validator = Validator::make(request()->all(), [
            'FirstName' => 'required|string',
            'LastName' => 'required|string',
            'MobileNumber' => 'required|numeric|digits:10',
            'EmailId' => 'required|email|max:255|unique:sysuser,email,' . $data->UserId,
            'AddressLine1' => 'required',
            'StateId' => 'required|integer',
            'CityName' => 'required|string',
            'PostalCode' => 'required',
            'PrAddressLine1' => 'required',
            'PrStateId' => 'required|integer',
            'PrCityName' => 'required',
            'EmergencyContactNumber' => 'required|numeric|digits:10',
            'BloodGroup' => 'required',
            'ProfileImage' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
            'SignImage' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',

        ], [
            'EmailId.required' => 'Email is required',
            'EmailId.unique' => 'The provided email address is already in use',
            'FirstName.required' => 'First name is required',
            'LastName.required' => 'Last name is required',
            'MobileNumber.required' => 'Mobile number is required',
            'MobileNumber.numeric' => 'Mobile number must be numeric',
            'MobileNumber.digits' => 'Mobile number must be 10 digits',
            'password.regex' => 'The password must contain at least one lowercase letter, one uppercase letter, one digit, and one special character.',
            'AddressLine1.required' => 'Address is required',
            'PrAddressLine1.required' => 'Permanent address is required',
            'StateId.required' => 'Select state.',
            'PrStateId.required' => 'Select state.',
            'DOB.required' => 'Date of Birth is required.',
            'PrCityName.required' => 'Permanent city name is required.',
            'ProfileImage.nullable' => 'Profile image must be an image',
            'ProfileImage.image' => 'Profile image must be a valid image file',
            'ProfileImage.mimes' => 'Profile image must be in one of the formats: jpeg, png, jpg, gif',
            'ProfileImage.max' => 'Profile image cannot exceed 2048 kilobytes',
            'SignImage.nullable' => 'Signature image must be an image',
            'SignImage.image' => 'Signature image must be a valid image file',
            'SignImage.mimes' => 'Signature image must be in one of the formats: jpeg, png, jpg, gif',
            'SignImage.max' => 'Signature image cannot exceed 2048 kilobytes',
        ]);

        if ($validator->fails()) {
            return redirect()->route('faculty.edit', ['id' => $id])
                ->withErrors($validator)
                ->withInput();
        } else {
            DB::beginTransaction();
            try {
                $user_id = Auth::id();
                $user = User::where('id', $data->UserId)->first();
                if ($user) {
                    $user->name = $request->FirstName . " " . $request->LastName;
                    $user->email   =  $request->EmailId;
                    $user->IsActive = '1';
                    $user->RoleId = '3';
                    $user->InstituteId = $request->InstituteId;
                    $user->updatedBy = $user_id;
                    $user->save();
                }

                if ($request->hasFile('ProfileImage')) {
                    $ProfileImage = time() . '.' . $request->ProfileImage->getClientOriginalExtension();
                    $request->ProfileImage->move(public_path('uploads/faculty/profile'), $ProfileImage);
                    $data->ProfileImage = $ProfileImage;
                }
                if ($request->hasFile('SignImage')) {
                    $SignImage = time() . '.' . $request->SignImage->getClientOriginalExtension();
                    $request->SignImage->move(public_path('uploads/faculty/signature'), $SignImage);
                    $data->SignImage = $SignImage;
                }
                $data->FirstName = ucwords($request->FirstName);
                $data->LastName = ucwords($request->LastName);
                $data->MobileNumber = $request->MobileNumber;
                $data->EmailId = $request->EmailId;
                $data->AddressLine1 = $request->AddressLine1;
                $data->AddressLine2 = $request->AddressLine2;
                $data->StateId = $request->StateId;
                $data->CityName = $request->CityName;
                $data->PostalCode = $request->PostalCode;
                $data->InstituteId = $request->InstituteId;
                $data->UserId = $request->UserId;
                $data->updatedBy = $user_id;

                $data->PrAddressLine1 = $request->PrAddressLine1;
                $data->PrAddressLine2 = $request->PrAddressLine2;
                $data->PrStateId = $request->PrStateId;
                $data->PrCityName = $request->PrCityName;
                $data->EmergencyContactNumber = $request->EmergencyContactNumber;

                $data->BloodGroup = $request->BloodGroup;


                $data->IsActive = $request->IsActive;

                $data->BranchId = $request->BranchId;
                $data->save();

                $currentMonth = now()->format('M');
                $currentYear = now()->format('Y');
                // Update the business data
                Faculty::where('id', $data->id)->update([
                    'EmployeeCode' => 'F-' . $currentMonth . '-' . $currentYear . '-' . $data->id,
                ]);
                DB::commit();
                return redirect()->route('faculty.listing')->with('success', 'Faculty has been updated successfully.');
            } catch (\Exception $e) {
                DB::rollBack();
                return redirect()->back()->withInput()->withErrors(['error' => $e->getMessage()]);
            }
        }
    }

    public function deleteImage(Request $request, $id)
    {
        $data = Faculty::find($id);
        $imageType = $request->input('imageType');

        // Logic to remove the specified image type
        if ($imageType == 'ProfileImage') {
            $oldImagePath = public_path('uploads/faculty/profile/' . $data->ProfileImage);
            $data->update(['ProfileImage' => null]);
        } elseif ($imageType == 'SignImage') {
            $oldImagePath = public_path('uploads/faculty/signature/' . $data->SignImage);
            $data->update(['SignImage' => null]);
        } else {
            // Handle the case where imageType is not recognized
            return redirect()->back()->with('error', 'Invalid image type.');
        }

        // If the file exists, delete it
        if (file_exists($oldImagePath)) {
            unlink($oldImagePath);
            return redirect()->back()->with('success', 'Image deleted successfully.');
        }
        // If the file doesn't exist, update the database record anyway
        return redirect()->back()->with('error', 'Image not found.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function trash(Faculty $faculty, $id)
    {
        $data = Faculty::find($id);
        if (!$data) {
            abort(404);
        }
        if ($data->IsActive == 0) {
            $data->delete();
            return redirect()->route('faculty.listing')->with('success', 'Faculty has been trashed successfully.');
        } else {
            return redirect()->route('faculty.listing')->with('error', 'faculty status on deletion,Kindly do Status make Inactive.');
        }
    }

    public function trashview(Faculty $faculty)
    {
        $data = Faculty::onlyTrashed()
            ->join('state', 'faculty.StateId', '=', 'state.id')
            ->select('faculty.*', 'state.Name as state_name')
            ->get();
        return view('backend.faculty.trash', compact('data'));
    }

    public function restore(Faculty $faculty, $id)
    {
        // Restore a soft deleted 
        $data = Faculty::withTrashed()->find($id);
        $data->restore();
        return redirect()->route('faculty.listing')->with('success', 'Faculty has been restored successfully.');
    }

    public function destroy(Faculty $faculty, $id)
    {
        DB::beginTransaction();
        try {
            // Permanently delete a soft deleted faculty
            $data = Faculty::withTrashed()->find($id);
            $data->forceDelete();

            // Delete associated images if they exist
            if ($data->ProfileImage != null && $data->ProfileImage != "default.jpg") {
                $this->deleteImg('uploads/faculty/profile/' . $data->ProfileImage);
            }
            if ($data->SignImage != null && $data->SignImage != "sign.jpg") {
                $this->deleteImg('uploads/faculty/signature/' . $data->SignImage);
            }

            // Fetch associated user data by user_id
            $user = User::find($data->UserId);

            // Delete associated records from userbranchright table
            DB::table('userbranchright')->where('UserId', $data->UserId)->delete();

            // Delete associated records from usermoduleright table
            DB::table('usermoduleright')->where('UserId', $data->UserId)->delete();

            // Delete the user if found
            if ($user) {
                $user->forceDelete();
            }

            DB::commit();

            return redirect()->route('faculty.trashview')->with('success', ' Faculty has been permanent delete successfully.');
        } catch (\Exception $e) {
            DB::rollback();
            return redirect()->route('faculty.trashview')->with('error', 'Failed to delete faculty and associated data. Error: ' . $e->getMessage());
        }
    }

    private function deleteImg($path)
    {
        // Get the full path to the public directory
        $publicPath = public_path();

        // Combine the public path with the relative image path
        $imagePath = $publicPath . '/' . $path;

        // Check if the file exists before attempting to delete
        if (file_exists($imagePath)) {
            unlink($imagePath);
        }
    }




    public function updatePassword(Request $request)
    {
        $request->validate([
            'password' => [
                'required',
                'string',
                'min:8',
                'confirmed',
                'regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]/',
            ],
            'password_confirmation' => 'required|string|min:8|same:password',
        ], [
            'password.required' => 'The password field is required.',
            'password.string' => 'The password must be a string.',
            'password.min' => 'The password must be at least :min characters.',
            'password.confirmed' => 'The password confirmation does not match.',
            'password.regex' => 'The password must contain at least one uppercase letter, one lowercase letter, one digit, and one special character.',
            'password_confirmation.required' => 'The password confirmation field is required.',
            'password_confirmation.string' => 'The password confirmation must be a string.',
            'password_confirmation.min' => 'The password confirmation must be at least :min characters.',
            'password_confirmation.same' => 'The password confirmation must match the password.',
        ]);
        $user = User::find($request->userid);
        if (!$user) {
            return redirect()->back()->with('error', 'User not found.');
        }

        $user->password = bcrypt($request->password);
        $user->save();

        return redirect()->back()->with('success', 'Password updated successfully.');
    }

    public function PortfolioSubmission(Request $request)
    {

        $userRole = auth()->user()->RoleId;

        // Initialize student ID
        $facultyId = null;

        // Check if the user role is 4 (presumably a student)
        if ($userRole == 3) {
            // If the user is a student, fetch their ID from the authenticated user
            $authUserId = auth()->user()->id;

            $student = Faculty::where('UserId', $authUserId)->first();
            // Check if a student with the authenticated user's ID exists
            if ($student) {
                // If a student is found, use their ID as the student ID
                $facultyId = $student->id;
            } else {
                abort(404);
            }
        } else {
            // If the user is not a student, retrieve the student ID from the request
            $facultyId = $request->id;
        }

        $data = DB::table('batch')
            ->join('batchdetail', 'batch.id', '=', 'batchdetail.BatchId')
            ->join('subject', 'batchdetail.SubjectId', '=', 'subject.id')
            ->join('studentbatchassign', 'batch.id', '=', 'studentbatchassign.BatchDetailId')
            ->join('student', 'studentbatchassign.StudentId', '=', 'student.id')
            ->where('batch.FacultyId', $facultyId)
            ->where('studentbatchassign.IsCompleted', 1)
            ->where('batch.IsCompleted', 1)
            ->whereNotExists(function ($query) {
                $query->select(DB::raw(1))
                    ->from('portfoliosubmission')
                    ->whereRaw('portfoliosubmission.StudentId = studentbatchassign.StudentId')
                    ->whereRaw('portfoliosubmission.SubjectId = batchdetail.SubjectId');
            })
            ->select(
                'batch.Name as batch_name',
                'subject.Name as subject_name',
                'student.FirstName',
                'student.LastName',
                'studentbatchassign.updated_at',
                'student.id as studentId',
                'subject.id as subjectId',
                'batch.FacultyId as facultyId',
            )
            ->distinct()
            ->get();

        $portfolio = Portfoliosubmission::where('portfoliosubmission.FacultyId', $facultyId)
            ->join('student', 'portfoliosubmission.StudentId', '=', 'student.id')
            ->join('subject', 'portfoliosubmission.SubjectId', '=', 'subject.id')
            ->select(
                'subject.Name as subject_name',
                'student.FirstName',
                'student.LastName',
                'portfoliosubmission.SubmissionDate',
                'portfoliosubmission.id',
                'portfoliosubmission.ApprovedAt',
                'portfoliosubmission.IsApproved',
                'portfoliosubmission.PortfolioFile',
            )
            ->get();

        return view('backend.faculty.portfolio', compact('data', 'portfolio'));
    }

    public function SavePortfolioSubmission(Request $request)
    {
        // Validate the request data
        $validator = Validator::make($request->all(), [
            'StudentId' => 'required|numeric',
            'SubjectId' => 'required|numeric',
            'FacultyId' => 'required|numeric',
            'SubmissionDate' => 'required|date',
            'ApprovedAt' => 'required|date',
            'PortfolioFile' => 'required|string',
            'IsApproved' => 'required|boolean',
        ], [
            'StudentId.required' => 'Student ID is required.',
            'StudentId.numeric' => 'Student ID must be a number.',
            'SubjectId.required' => 'Subject ID is required.',
            'SubjectId.numeric' => 'Subject ID must be a number.',
            'FacultyId.required' => 'Faculty ID is required.',
            'FacultyId.numeric' => 'Faculty ID must be a number.',
            'SubmissionDate.required' => 'Submission date is required.',
            'SubmissionDate.date' => 'Submission date must be a valid date.',
            'ApprovedAt.date' => 'Investigate Date must be a valid date.',
            'ApprovedAt.required' => 'Investigate Date is required.',
            'PortfolioFile.required' => 'Remark is required.',
            'PortfolioFile.string' => 'Remark must be a string.',
            'IsApproved.required' => 'IsApproved is required.',

        ]);

        // Check if validation fails
        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }
        $user_id = Auth::id();
        // Save the portfolio submission
        $portfolioSubmission = new PortfolioSubmission();
        $portfolioSubmission->StudentId = $request->input('StudentId');
        $portfolioSubmission->SubjectId = $request->input('SubjectId');
        $portfolioSubmission->FacultyId = $request->input('FacultyId');
        $portfolioSubmission->SubmissionDate = $request->input('SubmissionDate');
        $portfolioSubmission->ApprovedAt = $request->input('ApprovedAt');
        $portfolioSubmission->PortfolioFile = $request->input('PortfolioFile');
        $portfolioSubmission->IsApproved = $request->input('IsApproved');
        $portfolioSubmission->createdBy = $user_id;
        $portfolioSubmission->ApprovedBy = $user_id;
        $portfolioSubmission->save();

        // Return success response
        return response()->json(['message' => 'Portfolio submission saved successfully'], 200);
    }

    public function DeletePortfolioSubmission(Request $request, $id)
    {
        $data = Portfoliosubmission::find($id);
        if (!$data) {
            abort(404);
        }
        $data->delete();
        return redirect()->back()->with('success', 'Portfolio submission Deleted successfully.');
    }
}
