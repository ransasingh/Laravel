<?php

namespace App\Http\Controllers\backend;

use App\Models\Leadstatuses;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Validator;
use Yajra\DataTables\Facades\DataTables;

class LeadstatusesController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Leadstatuses $leadstatuses)
    {
        $data=  Leadstatuses::all();
        return view('backend.leadstatuses.list',compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('backend.leadstatuses.add');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request,Leadstatuses $leadstatuses)
    {
        $validator = Validator::make(request()->all(), [
            'Name' => 'required|max:50',
            'IsActive' => 'required',
           
        ]);
        if ($validator->fails()) {
            return redirect()->route('leadstatuses.add')
                ->withErrors($validator)
                ->withInput();
        } else {
            $user_id = Auth::id();
           $leadstatuses->Name =$request->Name;           
           $leadstatuses->IsActive =$request->IsActive;
           $leadstatuses->createdBy = $user_id;
           $leadstatuses->save();
            return redirect()->route('leadstatuses.listing')->with('success', 'Leads status has been created successfully.');
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(Leadstatuses $leadstatuses)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Leadstatuses $leadstatuses,$id)
    {
        $data = Leadstatuses::find($id);
        return view('backend.leadstatuses.edit', compact('data'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Leadstatuses $leadstatuses,$id)
    {
        $data = Leadstatuses::find($id);
        $validator = Validator::make(request()->all(), [
            'Name' => 'required|max:50',
            'IsActive' => 'required',
           
        ]);

        if ($validator->fails()) {
            return redirect()->route('leadstatuses.edit', ['id' => $id])
                ->withErrors($validator)
                ->withInput();
        } else {
            $user_id = Auth::id();
            $data->Name =$request->Name;           
            $data->IsActive =$request->IsActive;
            $data->createdBy = $user_id;
            $data->save();
            return redirect()->route('leadstatuses.listing')->with('success', 'Lead status has been updated successfully.');
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function trash(Leadstatuses $leadstatuses,$id)
    {
        $data = Leadstatuses::find($id);
        if (!$data) {
            abort(404);
        }
        if ($data->IsActive == 0) {
            $data->delete();
            return redirect()->route('leadstatuses.listing')->with('success', 'Lead status has been trashed successfully.');
        } else {
            return redirect()->route('leadstatuses.listing')->with('error', 'Invalid status on deletion,Kindly do Status make Inactive.');
        }
    }

    public function trashview(Leadstatuses $leadstatuses)
    {
        $data = Leadstatuses::onlyTrashed()->latest()->get();
        return view('backend.leadstatuses.trash', compact('data'));
    }

    public function restore(Leadstatuses $leadstatuses, $id)
    {
        // Restore a soft deleted 
        $data = Leadstatuses::withTrashed()->find($id);
        $data->restore();
        return redirect()->route('leadstatuses.listing')->with('success', 'leadstatuses has been restored successfully.');
    }

     /**
     * trash the specified resource database permanent.
     */
    public function destroy(Leadstatuses $leadstatuses, $id)
    {
       // Permanently delete a soft deleted 
       $data = Leadstatuses::withTrashed()->find($id);
       $data->forceDelete();
       return redirect()->route('leadstatuses.trashview')->with('success', 'leadstatuses has been permanent delete successfully.');
       
    }
}
