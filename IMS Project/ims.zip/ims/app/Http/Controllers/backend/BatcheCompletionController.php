<?php

namespace App\Http\Controllers\backend;

use App\Http\Controllers\Controller;
use App\Models\Batch;
use App\Models\StudentBatchAssign;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;



class BatcheCompletionController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $data = Batch::join('faculty', 'batch.FacultyId', '=', 'faculty.id')
            ->select('batch.*', 'faculty.FirstName', 'faculty.LastName', 'faculty.UserId', 'faculty.BranchId')
            ->whereDate('ToDate', '<=', now());

        if (Auth::user()->RoleId == 1) {
            $data =  $data->where('faculty.BranchId', session('BranchId'))
                ->get();
        } elseif (Auth::user()->RoleId == 3) {
            // If role is 3, show only data where the faculty ID matches the authenticated user's ID
            $data = $data->where('UserId', Auth::id())
                ->where('BranchId', session('BranchId'))
                ->get();
        }

        return view('backend.batchcompletion.list', compact('data'));
    }
    /**
     * Display a listing of the resource for batchecompletionapproval.
     */
    public function batchecompletionapproval()
    {
        $data = Batch::join('faculty', 'batch.FacultyId', '=', 'faculty.id')
            ->select('batch.*', 'faculty.FirstName', 'faculty.LastName')
            ->where('IsCompleted', 1)
            ->where('IsApproved', 0)
            ->get();
        return view('backend.batchecompletionapproval.list', compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create(Request $request, $id)
    {
        $data = DB::table('batch')
            ->join('faculty', 'batch.FacultyId', '=', 'faculty.id')
            ->select('batch.*', 'faculty.UserId')
            ->where('batch.id', $id)
            ->whereDate('ToDate', '<=', now())
            ->first();
        if (!$data) {
            abort(404); // Batch not found or does not meet conditions
        }
        $batchDetails = DB::table('batchdetail')
            ->join('subject', 'batchdetail.SubjectId', '=', 'subject.id')
            ->select('subject.Name as subject_name', 'subject.NoOfSession', 'batchdetail.BatchId')
            ->where('batchdetail.BatchId', $data->id)
            ->distinct('batchdetail.SubjectId') // Ensure only one row per unique SubjectId
            ->get();
        $students = DB::table('studentbatchassign')
            ->join('student', 'studentbatchassign.StudentId', '=', 'student.id')
            ->join('course', 'student.CourseID', '=', 'course.id')
            ->select('student.id', 'student.FirstName', 'student.LastName', 'studentbatchassign.BatchDetailId', 'course.name as course_name')
            ->where('studentbatchassign.BatchDetailId', $data->id)
            ->get();

        $attendanceCounts = DB::table('studentattandance')
            ->select('StudentId', DB::raw('COUNT(*) as attendance_count'))
            ->where('BatchDetailId', $data->id)
            ->where('DayAttandance', '!=', 0) // Filter rows where DayAttandance is not equal to 0
            ->groupBy('StudentId')
            ->get();

        // Check authorization based on user role
        if (Auth::user()->RoleId == 1) {
            // If role is 1, allow access to edit the batch
        } elseif (Auth::user()->RoleId == 3) {
            $facultyUserId = $data->UserId ?? null;
            if ($facultyUserId != Auth::id()) {
                // Unauthorized access - handle accordingly (e.g., show error message or redirect)
                abort(403, 'Unauthorized access');
            }
        }

        return view('backend.batchcompletion.approve', compact('batchDetails', 'students', 'attendanceCounts', 'data'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request, $id)
    {
        $data = Batch::find($id);
        $user_id = Auth::id();
        $selectedStudents = $request->input('selectedStudents');
        // Update the IsCompleted field in the student batch assign table for the selected students and the batch ID
        StudentBatchAssign::whereIn('StudentId', $selectedStudents)
            ->where('BatchDetailId', $data->id) // Match the batch ID
            ->update(['IsCompleted' => 1, 'updatedBy' => $user_id]);

        $data->update(['IsCompleted' => 1, 'updatedBy' => $user_id]);
        return redirect()->route('batchecompletion.listing')->with('success', 'Batch completion added successfully.');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Request $request, $id)
    {
        $data = Batch::find($id);
        if ($data->IsCompleted == 1) {
            $batchDetails = DB::table('batchdetail')
                ->join('subject', 'batchdetail.SubjectId', '=', 'subject.id')
                ->select('subject.Name as subject_name', 'subject.NoOfSession', 'batchdetail.BatchId')
                ->where('batchdetail.BatchId', $data->id)
                ->distinct('batchdetail.SubjectId') // Ensure only one row per unique SubjectId
                ->get();
        }
        $students = DB::table('studentbatchassign')
            ->join('student', 'studentbatchassign.StudentId', '=', 'student.id')
            ->join('course', 'student.CourseID', '=', 'course.id')
            ->select('student.id', 'student.FirstName', 'student.LastName', 'studentbatchassign.BatchDetailId', 'course.name as course_name')
            ->where('studentbatchassign.BatchDetailId', $data->id)
            ->where('studentbatchassign.IsCompleted', 1)
            ->get();

        $attendanceCounts = DB::table('studentattandance')
            ->select('StudentId', DB::raw('COUNT(*) as attendance_count'))
            ->where('BatchDetailId', $data->id)
            ->where('DayAttandance', '!=', 0) // Filter rows where DayAttandance is not equal to 0
            ->groupBy('StudentId')
            ->get();

        return view('backend.batchecompletionapproval.approve', compact('batchDetails', 'students', 'attendanceCounts', 'data'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        $data = Batch::find($id);
        $user_id = Auth::id();
        if ($request->has('action')) {
            $action = $request->input('action');

            // Check which action was triggered
            if ($action === 'approve') {
                $data->update(['IsApproved' => 1, 'VerifyBy' => $user_id, 'VerifyAt' => now(), 'updatedBy' => $user_id]);
                return redirect()->route('batchecompletionapproval.listing')->with('success', 'Batch completion approved successfully.');
            } elseif ($action === 'reject') {
                $selectedStudents = $request->input('selectedStudents');
                // Update the IsCompleted field in the student batch assign table for the selected students and the batch ID
                StudentBatchAssign::whereIn('StudentId', $selectedStudents)
                    ->where('BatchDetailId', $data->id) // Match the batch ID
                    ->update(['IsCompleted' => 0, 'updatedBy' => $user_id]);
                $data->update(['IsCompleted' => 0, 'updatedBy' => $user_id]);
                return redirect()->route('batchecompletionapproval.listing')->with('error', 'Batch completion rejected.');
            }
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
