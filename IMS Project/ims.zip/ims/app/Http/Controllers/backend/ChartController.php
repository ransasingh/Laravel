<?php

namespace App\Http\Controllers\backend;

use App\Http\Controllers\Controller;
use App\Models\Course;
use App\Models\Student;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ChartController extends Controller
{
    public function getCourseIncomeData(Request $request)
    {
        // Get the selected time period from the request
        $timePeriod = $request->input('timePeriod');

        // Define the date range based on the selected time period
        $startDate = null;
        $endDate = now(); // Default to current date

        switch ($timePeriod) {
            case 'current_month':
                $startDate = now()->startOfMonth();
                break;
            case 'current_year':
                $startDate = now()->startOfYear();
                break;
            case 'last_month':
                $startDate = now()->subMonth()->startOfMonth();
                $endDate = now()->subMonth()->endOfMonth();
                break;
            case 'last_3_months':
                $startDate = now()->subMonths(2)->startOfMonth();
                break;
            case 'last_year':
                $startDate = now()->subYear()->startOfYear();
                $endDate = now()->subYear()->endOfYear();
                break;
            default:
                // Default to current month
                $startDate = now()->startOfMonth();
        }

        // Fetch course data based on the selected time period
        $courseData = Course::select('course.Name as course_name', DB::raw('SUM(feereceiptdetail.Amount) as TotalIncome'))
            ->join('feestructure', 'course.id', '=', 'feestructure.CourseId')
            ->join('feereceipt', 'feestructure.id', '=', 'feereceipt.FeeStructureId')
            ->join('feereceiptdetail', 'feereceipt.id', '=', 'feereceiptdetail.FeeReceiptId')
            ->join('student', 'feereceipt.StudentId', '=', 'student.id') // Join with the Student table
            ->where('student.BranchId', session('BranchId')) // Filter based on BranchId
            ->whereBetween('feereceipt.ReceiptDate', [$startDate, $endDate])
            ->groupBy('course.Name')
            ->get();

        return response()->json($courseData);
    }

    public function getCourseTrafficData(Request $request)
    {
        // Get the selected time period from the request
        $timePeriod = $request->input('TrafficChartPeriod');

        // Define the date range based on the selected time period
        $startDate = null;
        $endDate = now(); // Default to current date

        switch ($timePeriod) {
            case 'current_month':
                $startDate = now()->startOfMonth();
                break;
            case 'current_year':
                $startDate = now()->startOfYear();
                break;
            case 'last_6_months':
                $startDate = now()->subMonths(5)->startOfMonth();
                break;
            case 'last_3_months':
                $startDate = now()->subMonths(2)->startOfMonth();
                break;
            case 'last_year':
                $startDate = now()->subYear()->startOfYear();
                $endDate = now()->subYear()->endOfYear();
                break;
            default:
                // Default to current month
                $startDate = now()->startOfMonth();
        }

        $courses = Course::all();
        $data = [];

        foreach ($courses as $course) {
            $studentCount = Student::where('CourseId', $course->id)
                ->where('BranchId', session('BranchId')) // Check if BranchId matches the session value
                ->whereBetween('created_at', [$startDate, $endDate])
                ->count();

            $data[] = [
                'name' => $course->Name,
                'student_count' => $studentCount,
            ];
        }

        return response()->json($data);
    }
    public function getSubjectWiseBatchData(Request $request)
    {
        // Get the authenticated user's ID
        $userId = auth()->id();
        $studentId = DB::table('student')
            ->where('UserId', $userId)
            ->value('id');

        // Query to fetch subject-wise batch data
        $subjectWiseBatchData = DB::table('student')
            ->select('batch.Name', 'batchdetail.BatchDay', 'subject.Name as SubjectName')
            ->join('studentbatchassign', 'studentbatchassign.StudentId', '=', 'student.id')
            ->join('batchdetail', 'batchdetail.BatchId', '=', 'studentbatchassign.BatchDetailId')
            ->join('batch', 'batch.id', '=', 'batchdetail.BatchId')
            ->join('subject', 'subject.id', '=', 'batchdetail.SubjectId')
            ->where('student.id', $studentId)
            ->where('student.UserId', $userId)
            ->get();

        // Process the fetched data to organize it by day and count the number of batches for each day
        $batchesByDay = [];
        foreach ($subjectWiseBatchData as $data) {
            // Convert BatchDay integer to day name
            $dayName = $this->getDayName($data->BatchDay);

            if (!isset($batchesByDay[$dayName])) {
                $batchesByDay[$dayName] = [];
            }

            if (!in_array($data->Name, $batchesByDay[$dayName])) {
                $batchesByDay[$dayName][] = [
                    'batch' => $data->Name,
                    'subject' => $data->SubjectName,
                ];
            }
        }

        // Define day labels
        $labels = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

        // Organize data for response
        $responseData = [];
        foreach ($labels as $dayName) {
            $dayIndex = array_search($dayName, $labels);
            $responseData[] = [
                'student_id' => $studentId,
                'day' => $dayName,
                'batches' => $batchesByDay[$dayName] ?? [],
                'count' => count($batchesByDay[$dayName] ?? []),
            ];
        }

        return response()->json($responseData);
    }

    public function getFacultySubjectWiseBatchData(Request $request)
    {
        // Get the authenticated user's ID
        $userId = auth()->id();
        $facultyId = DB::table('faculty')
            ->where('UserId', $userId)
            ->value('id');
        // Query to fetch subject-wise batch data
        $subjectWiseBatchData = DB::table('faculty')
            ->select('batch.Name', 'batchdetail.BatchDay', 'subject.Name as SubjectName')
            ->join('batch', 'batch.FacultyId', '=', 'faculty.id')
            ->join('batchdetail', 'batchdetail.BatchId', '=', 'batch.id')
            ->join('subject', 'subject.id', '=', 'batchdetail.SubjectId')
            ->where('faculty.id', $facultyId)
            ->where('faculty.UserId', $userId)
            ->where('faculty.BranchId', session('BranchId'))
            ->get();

        // Process the fetched data to organize it by day and count the number of batches for each day
        $batchesByDay = [];
        foreach ($subjectWiseBatchData as $data) {
            $dayName = $this->getDayName($data->BatchDay);

            if (!isset($batchesByDay[$dayName])) {
                $batchesByDay[$dayName] = [];
            }

            if (!in_array($data->Name, $batchesByDay[$dayName])) {
                $batchesByDay[$dayName][] = [
                    'batch' => $data->Name,
                    'subject' => $data->SubjectName,
                ];
            }
        }

        // Define day labels
        $labels = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

        // Organize data for response
        $responseData = [];
        foreach ($labels as $dayName) {
            $dayIndex = array_search($dayName, $labels);
            $responseData[] = [
                'faculty_id' => $facultyId,
                'day' => $dayName,
                'batches' => $batchesByDay[$dayName] ?? [],
                'count' => count($batchesByDay[$dayName] ?? []),
            ];
        }

        return response()->json($responseData);
    }


    private function getDayName($dayIndex)
    {
        $dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        return $dayNames[$dayIndex];
    }
}
