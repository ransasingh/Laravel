<?php

namespace App\Http\Controllers\backend;

use App\Models\InstituteBranch;
use App\Http\Controllers\Controller;
use App\Models\Institute;
use App\Models\State;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Validator;
use Illuminate\Support\Facades\Session;

class InstituteBranchController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $data = InstituteBranch::join('institute', 'institutebranch.InstituteId', '=', 'institute.id')
            ->select('institutebranch.*', 'institute.Name as institute_name')
            ->get();
        return view('backend.institutebranch.list', compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $institutes = Institute::where('IsActive', '1')->get();
        $states = State::where('IsActive', '1')->get();
        return view('backend.institutebranch.add', compact('states', 'institutes'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request, InstituteBranch $instituteBranch)
    {
        $validator = Validator::make(request()->all(), [
            'Name' => 'required',
            'BranchCode' => 'required|unique:institutebranch,BranchCode',
            'EmailId' => ['required', 'email'],
            'MobileNumber' => ['required', 'numeric', 'digits:10'],
            'AddressLine1' => 'required',
            'StateId' => 'required',
            'InstituteId' => 'required',
            'CityName' => 'required',
            'PostalCode' => 'required',
            'IsActive' => 'required',

        ], [
            'MobileNumber.required' => 'The mobile number is required.',
            'MobileNumber.numeric' => 'The mobile number must be numeric.',
            'MobileNumber.digits' => 'The mobile number must be exactly 10 digits.',
            'StateId.required' => 'Please select state',
            'InstituteId.required' => 'Please select institute',
        ]);
        if ($validator->fails()) {
            return redirect()->route('institutebranch.add')
                ->withErrors($validator)
                ->withInput();
        } else {
            $user_id = Auth::id();
            $instituteBranch->Name = ucwords($request->Name);
            $instituteBranch->BranchCode  = $request->BranchCode;
            $instituteBranch->InstituteId  = $request->InstituteId;
            $instituteBranch->MobileNumber  = $request->MobileNumber;
            $instituteBranch->EmailId = $request->EmailId;
            $instituteBranch->Website = $request->Website;
            $instituteBranch->AddressLine1 = $request->AddressLine1;
            $instituteBranch->AddressLine2 = $request->AddressLine2;
            $instituteBranch->StateId = $request->StateId;
            $instituteBranch->CityName = $request->CityName;
            $instituteBranch->PostalCode = $request->PostalCode;
            $instituteBranch->IsActive = $request->IsActive;
            $instituteBranch->createdBy = $user_id;
            $instituteBranch->save();
            return redirect()->route('institutebranch.listing')->with('success', 'Institute branch has been created successfully.');
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(InstituteBranch $instituteBranch)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(InstituteBranch $instituteBranch, $id)
    {
        $data = InstituteBranch::find($id);
        $institutes = Institute::where('IsActive', '1')->get();
        $states = State::where('IsActive', '1')->get();
        return view('backend.institutebranch.edit', compact('data', 'states', 'institutes'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, InstituteBranch $instituteBranch, $id)
    {
        $data = InstituteBranch::find($id);
        $validator = Validator::make(request()->all(), [
            'Name' => 'required',
            'BranchCode' => 'required|unique:institutebranch,BranchCode,' . $id,
            'EmailId' => ['required', 'email'],
            'MobileNumber' => ['required', 'numeric', 'digits:10'],
            'AddressLine1' => 'required',
            'StateId' => 'required',
            'InstituteId' => 'required',
            'CityName' => 'required',
            'PostalCode' => 'required',
            'IsActive' => 'required',

        ], [
            'MobileNumber.required' => 'The mobile number is required.',
            'MobileNumber.numeric' => 'The mobile number must be numeric.',
            'MobileNumber.digits' => 'The mobile number must be exactly 10 digits.',
            'StateId.required' => 'Please select state',
            'InstituteId.required' => 'Please select institute',
        ]);
        if ($validator->fails()) {
            return redirect()->route('institutebranch.edit', ['id' => $id])
                ->withErrors($validator)
                ->withInput();
        } else {
            $user_id = Auth::id();
            $data->Name = ucwords($request->Name);
            $data->BranchCode  = $request->BranchCode;
            $data->InstituteId  = $request->InstituteId;
            $data->MobileNumber  = $request->MobileNumber;
            $data->EmailId = $request->EmailId;
            $data->Website = $request->Website;
            $data->AddressLine1 = $request->AddressLine1;
            $data->AddressLine2 = $request->AddressLine2;
            $data->StateId = $request->StateId;
            $data->CityName = $request->CityName;
            $data->PostalCode = $request->PostalCode;
            $data->IsActive = $request->IsActive;
            $data->updatedBy = $user_id;
            $data->save();
            return redirect()->route('institutebranch.listing')->with('success', 'Institute branch has been updated successfully.');
        }
    }
    /**
     * Remove the specified resource from storage.
     */
    public function trash(InstituteBranch $instituteBranch, $id)
    {
        $data = InstituteBranch::find($id);
        if (!$data) {
            abort(404);
        }
        if ($data->IsActive == 0) {
            $data->delete();
            return redirect()->route('institutebranch.listing')->with('success', 'Institute branch has been trashed successfully.');
        } else {
            return redirect()->route('institutebranch.listing')->with('error', 'Invalid status on deletion,Kindly do Status make Inactive.');
        }
    }

    /**
     * trashview the specified resource from storage.
     */
    public function trashview(InstituteBranch $instituteBranch)
    {
        $data = InstituteBranch::onlyTrashed()
            ->join('institute', 'institutebranch.InstituteId', '=', 'institute.id')
            ->select('institutebranch.*', 'institute.Name as institute_name')
            ->get();

        return view('backend.institutebranch.trash', compact('data'));
    }

    /**
     * restore the specified resource .
     */
    public function restore(InstituteBranch $instituteBranch, $id)
    {
        // Restore a soft deleted 
        $data = InstituteBranch::withTrashed()->find($id);
        $data->restore();
        return redirect()->route('institutebranch.listing')->with('success', 'Institute branch has been restored successfully.');
    }
    /**
     * trash the specified resource database permanent.
     */
    public function destroy(InstituteBranch $instituteBranch, $id)
    {
        // Permanently delete a soft deleted 
        $data = InstituteBranch::withTrashed()->find($id);
        $data->forceDelete();

        return redirect()->route('institutebranch.trashview')->with('success', 'Institute branch has been permanent delete successfully.');
    }


    public function changeBranch(Request $request)
    {

        // Get the selected branch ID from the request
        $selectedBranchId = $request->input('branch');
     
        // Save the selected branch ID in the session for the current user
        Session::put('BranchId', $selectedBranchId);

        // Redirect back or to a specific route after changing the branch
        return redirect()->back();
    }
}
