<?php

namespace App\Http\Controllers\backend;

use App\Models\State;
use App\Http\Controllers\Controller;
use App\Models\Country;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Validator;

class StateController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $data = State::all();
        return view('backend.states.list', compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $countries = Country::where('IsActive', 1)->get();
        return view('backend.states.add', compact('countries'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request, State $state)
    {
        $validator = Validator::make(request()->all(), [
            'Name' => 'required|max:50|unique:state,Name',
            'StateCode' => 'required|max:50|unique:state,StateCode',
            'CountryId' => 'required',
            'IsActive' => 'required',
        ], [
            'CountryId.required' => 'Please select country.',
        ]);
        if ($validator->fails()) {
            return redirect()->route('states.add')
                ->withErrors($validator)
                ->withInput();
        } else {
            $user_id = Auth::id();
            $state->Name = ucwords($request->Name);
            $state->StateCode  = strtoupper($request->StateCode);
            $state->CountryId  = $request->CountryId;
            $state->IsActive = $request->IsActive;
            $state->createdBy = $user_id;
            $state->save();
            return redirect()->route('states.listing')->with('success', 'State has been created successfully.');
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(State $state)
    {
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(State $state, $id)
    {
        $data = State::find($id);
        $countries = Country::where('IsActive', 1)->get();
        return view('backend.states.edit', compact('data', 'countries'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, State $state, $id)
    {
        $data = State::find($id);
        $validator = Validator::make(request()->all(), [
            'Name' => 'required|max:50|unique:state,Name,' . $id,
            'StateCode' => 'required|max:50|unique:state,StateCode,' . $id,
            'CountryId' => 'required',
            'IsActive' => 'required',
        ], [
            'CountryId.required' => 'Please select country.',
        ]);

        if ($validator->fails()) {
            return redirect()->route('states.edit', ['id' => $id])
                ->withErrors($validator)
                ->withInput();
        } else {
            $user_id = Auth::id();
            $data->Name = ucwords($request->Name);
            $data->StateCode  = strtoupper($request->StateCode);
            $data->CountryId  = $request->CountryId;
            $data->IsActive = $request->IsActive;
            $data->updatedBy = $user_id;
            $data->save();
            return redirect()->route('states.listing')->with('success', 'State has been updated successfully.');
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function trash(State $state, $id)
    {
        $data = State::find($id);
        if (!$data) {
            abort(404);
        }
        if ($data->IsActive == 0) {
            $data->delete();
            return redirect()->route('states.listing')->with('success', 'State has been trashed successfully.');
        } else {
            return redirect()->route('states.listing')->with('error', 'Invalid status on deletion,Kindly do Status make Inactive.');
        }
    }

    /**
     * trashview the specified resource from storage.
     */
    public function trashview(State $state)
    {
        $data = State::onlyTrashed()->latest()->get();
        return view('backend.states.trash', compact('data'));
    }

    /**
     * restore the specified resource .
     */
    public function restore(State $state, $id)
    {
        // Restore a soft deleted 
        $data = State::withTrashed()->find($id);
        $data->restore();
        return redirect()->route('states.listing')->with('success', 'State has been restored successfully.');
    }
    /**
     * trash the specified resource database permanent.
     */
    public function destroy(State $state, $id)
    {
        // Permanently delete a soft deleted 
        $data = State::withTrashed()->find($id);
        $data->forceDelete();
        return redirect()->route('states.trashview')->with('success', 'State has been permanent delete successfully.');
    }
}
