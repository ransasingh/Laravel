<?php

namespace App\Http\Controllers\backend;

use App\Models\Callstatuses;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Validator;
use Yajra\DataTables\Facades\DataTables;

class CallstatusesController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Callstatuses $callstatuses)
    {
        $data=  Callstatuses::all();
        return view('backend.callstatuses.list',compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('backend.callstatuses.add');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request,Callstatuses $callstatuses)
    {
        $validator = Validator::make(request()->all(), [
            'Name' => 'required|max:50',
            'IsActive' => 'required',
           
        ]);
        if ($validator->fails()) {
            return redirect()->route('callstatuses.add')
                ->withErrors($validator)
                ->withInput();
        } else {
            $user_id = Auth::id();
           $callstatuses->Name =$request->Name;           
           $callstatuses->IsActive =$request->IsActive;
           $callstatuses->createdBy = $user_id;
           $callstatuses->save();
            return redirect()->route('callstatuses.listing')->with('success', 'Call status has been created successfully.');
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(Callstatuses $callstatuses)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Callstatuses $callstatuses,$id)
    {
        $data = Callstatuses::find($id);
        return view('backend.callstatuses.edit', compact('data'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Callstatuses $callstatuses,$id)
    {
        $data = Callstatuses::find($id);
        $validator = Validator::make(request()->all(), [
            'Name' => 'required|max:50',
            'IsActive' => 'required',
           
        ]);

        if ($validator->fails()) {
            return redirect()->route('callstatuses.edit', ['id' => $id])
                ->withErrors($validator)
                ->withInput();
        } else {
            $user_id = Auth::id();
            $data->Name =$request->Name;           
            $data->IsActive =$request->IsActive;
            $data->createdBy = $user_id;
            $data->save();
            return redirect()->route('callstatuses.listing')->with('success', 'call statuses has been updated successfully.');
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function trash(Callstatuses $callstatuses,$id)
    {
        $data = Callstatuses::find($id);
        if (!$data) {
            abort(404);
        }
        if ($data->IsActive == 0) {
            $data->delete();
            return redirect()->route('callstatuses.listing')->with('success', 'Call status has been trashed successfully.');
        } else {
            return redirect()->route('callstatuses.listing')->with('error', 'Invalid status on deletion,Kindly do Status make Inactive.');
        }
    }

    public function trashview(Callstatuses $callstatuses)
    {
        $data = Callstatuses::onlyTrashed()->latest()->get();
        return view('backend.callstatuses.trash', compact('data'));
    }

     public function restore(Callstatuses $callstatuses, $id)
    {
        // Restore a soft deleted 
        $data = Callstatuses::withTrashed()->find($id);
        $data->restore();
        return redirect()->route('callstatuses.listing')->with('success', 'callstatuses has been restored successfully.');
    }

     /**
     * trash the specified resource database permanent.
     */
    public function destroy(Callstatuses $callstatuses, $id)
    {
       // Permanently delete a soft deleted 
       $data = Callstatuses::withTrashed()->find($id);
       $data->forceDelete();
       return redirect()->route('callstatuses.trashview')->with('success', 'callstatuses has been permanent delete successfully.');
       
    }
}
