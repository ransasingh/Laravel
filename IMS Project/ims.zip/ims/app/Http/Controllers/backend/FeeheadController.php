<?php

namespace App\Http\Controllers\backend;

use App\Models\Feehead;
use App\Models\Institute;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Validator;


class FeeheadController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $data = Feehead::all();
        return view('backend.feehead.list', compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $institutes = Institute::where('IsActive', '1')->get();
        $institutesid = $institutes[0]['id'];

        return view('backend.feehead.add', compact('institutesid'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request, Feehead $feehead)
    {
        $validator = Validator::make(request()->all(), [
            'Name' => 'required|unique:feehead,Name',
            'Code' => 'unique:feehead,Code',
            'IsActive' => 'required',
        ], [
            'Name.required' => 'The feehead name is required.',
            'Name.unique' => 'The feehead name is already taken.',
            'Code.unique' => 'The feehead code is already taken.',
        ]);
        if ($validator->fails()) {
            return redirect()->route('feehead.add')
                ->withErrors($validator)
                ->withInput();
        } else {
            $user_id = Auth::id();
            $feehead->Name = ucwords($request->Name);
            $feehead->InstituteId = $request->InstituteId;
            $feehead->IsActive = $request->IsActive;
            $feehead->createdBy = $user_id;
            $feehead->save();
           
            Feehead::where('id', $feehead->id)->update([
                'Code' => 'FH' . $feehead->id,
            ]);

            return redirect()->route('feehead.listing')->with('success', 'FeeHead has been created successfully.');
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(Feehead $feehead)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Feehead $feehead,$id)
    {
        $data = Feehead::find($id);
        return view('backend.feehead.edit', compact('data'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Feehead $feehead,$id)
    {
        $data = Feehead::find($id);
        $validator = Validator::make(request()->all(), [
            'Name' => 'required|unique:feehead,Name,'.$id,
            'Code' => 'unique:feehead,Code,'.$id,
            'IsActive' => 'required',
        ], [
            'Name.required' => 'The feehead name is required.',
            'Name.unique' => 'The feehead name is already taken.',
            'Code.unique' => 'The feehead code is already taken.',
        ]);
        if ($validator->fails()) {
            return redirect()->route('feehead.edit',['id'=>$id])
                ->withErrors($validator)
                ->withInput();
        } else {
            $user_id = Auth::id();
            $data->Name = ucwords($request->Name);
            $data->InstituteId = $request->InstituteId;
            $data->IsActive = $request->IsActive;
            $data->updatedBy = $user_id;
            $data->save();
         
            Feehead::where('id', $data->id)->update([
                'Code' => 'FH' . $data->id,
            ]);

            return redirect()->route('feehead.listing')->with('success', 'FeeHead has been updated successfully.');
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function trash(Feehead $feehead, $id)
    {
        $data = Feehead::find($id);
        if (!$data) {
            abort(404);
        }
        if ($data->IsActive == 0) {
            $data->delete();
            return redirect()->route('feehead.listing')->with('success', 'FeeHead has been trashed successfully.');
        } else {
            return redirect()->route('feehead.listing')->with('error', 'Invalid status on deletion,Kindly do Status make Inactive.');
        }
    }

    /**
     * trashview the specified resource from storage.
     */
    public function trashview(Feehead $feehead)
    {
        $data = Feehead::onlyTrashed()->latest()->get();
        return view('backend.feehead.trash', compact('data'));
    }

    /**
     * restore the specified resource .
     */
    public function restore(Feehead $feehead, $id)
    {
        // Restore a soft deleted 
        $data = Feehead::withTrashed()->find($id);
        $data->restore();
        return redirect()->route('feehead.listing')->with('success', 'FeeHead has been restored successfully.');
    }
    /**
     * trash the specified resource database permanent.
     */
    public function destroy(Feehead $feehead, $id)
    {
        // Permanently delete a soft deleted 
        $data = Feehead::withTrashed()->find($id);
        $data->forceDelete();
       
        return redirect()->route('feehead.trashview')->with('success', 'FeeHead has been permanent delete successfully.');
    }
}
