<?php

namespace App\Http\Controllers\backend;

use App\Models\Country;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Validator;


class CountryController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $data = Country::all();
        return view('backend.countries.list', compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('backend.countries.add');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request, Country $countries)
    {
        $validator = Validator::make(request()->all(), [
            'Name' => 'required|max:50|unique:country,Name',
            'CountryCode' => 'required|max:50|unique:country,CountryCode',
            'IsActive' => 'required',
        ]);
        if ($validator->fails()) {
            return redirect()->route('countries.add')
                ->withErrors($validator)
                ->withInput();
        } else {
            $user_id = Auth::id();
            $countries->Name = ucwords($request->Name);
            $countries->CountryCode  = $request->CountryCode;
            $countries->IsActive = $request->IsActive;
            $countries->createdBy = $user_id;
            $countries->save();
            return redirect()->route('countries.listing')->with('success', 'Country has been created successfully.');
        }
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Country $countries, $id)
    {
        $data = Country::find($id);
        return view('backend.countries.edit', compact('data'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Country $countries, $id)
    {
        $data = Country::find($id);
       
        $validator = Validator::make(request()->all(), [
            'Name' => 'required|max:50|unique:country,Name,' . $id,
            'CountryCode' => 'required|max:50|unique:country,CountryCode,'. $id,
            'IsActive' => 'required',
        ]);

        if ($validator->fails()) {
            return redirect()->route('countries.edit', ['id' => $id])
                ->withErrors($validator)
                ->withInput();
        } else {
            $user_id = Auth::id();
            $data->Name = ucwords($request->Name);
            $data->CountryCode  = $request->CountryCode;
            $data->IsActive = $request->IsActive;
            $data->updatedBy = $user_id;
            $data->save();

            return redirect()->route('countries.listing')->with('success', 'Country has been updated successfully.');
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function trash(Country $countries, $id)
    {
        $data = Country::find($id);
        if (!$data) {
            abort(404);
        }
        if ($data->IsActive == 0) {
            $data->delete();
            return redirect()->route('countries.listing')->with('success', 'Country has been trashed successfully.');
        } else {
            return redirect()->route('countries.listing')->with('error', 'Invalid status on deletion,Kindly do Status make Inactive.');
        }
    }

    /**
     * trashview the specified resource from storage.
     */
    public function trashview(Country $countries)
    {
        $data = Country::onlyTrashed()->latest()->get();
        return view('backend.countries.trash',compact('data'));
    }

      /**
     * restore the specified resource .
     */
    public function restore(Country $countries,$id)
    {
        // Restore a soft deleted 
        $data = Country::withTrashed()->find($id);
        $data->restore();
        return redirect()->route('countries.listing')->with('success', 'Country has been restored successfully.');
    }
    /**
     * trash the specified resource database permanent.
     */
    public function destroy(Country $countries,$id)
    {
        // Permanently delete a soft deleted 
        $data = Country::withTrashed()->find($id);
        $data->forceDelete();
        return redirect()->route('countries.trashview')->with('success', 'Country has been permanent delete successfully.');
    }
}
