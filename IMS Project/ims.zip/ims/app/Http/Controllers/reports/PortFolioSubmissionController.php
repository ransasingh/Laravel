<?php

namespace App\Http\Controllers\reports;

use App\Http\Controllers\Controller;
use App\Models\Faculty;
use App\Models\Student;
use App\Models\subject;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class PortFolioSubmissionController extends Controller
{
    public function PortfolioSubmission(Request $request)
    {
        $subjects = subject::where('IsActive', '1')->get();
        $faculties = Faculty::where('IsActive', '1')
            ->where('BranchId', session('BranchId'))
            ->get();
        $students = Student::where('IsActive', 1)
            ->where('BranchId', session('BranchId'))
            ->get();

        return view('reports.portfoliosubmission.portfoliosubmissionreport', compact('subjects', 'faculties', 'students'));
    }
    public function PortfolioSubmissionReport(Request $request)
    {
        try {
            // Validate the request
            $validatedData = $request->validate([
                'FromDate' => 'required|date',
                'ToDate' => 'required|date|after_or_equal:FromDate',
            ]);

            $query = DB::table('portfoliosubmission')
                ->join('student', 'portfoliosubmission.StudentId', '=', 'student.id')
                ->join('faculty', 'portfoliosubmission.FacultyId', '=', 'faculty.id')
                ->join('course', 'student.CourseId', '=', 'course.id')
                ->join('subject', 'portfoliosubmission.SubjectId', '=', 'subject.id')
                ->join('sysuser', 'portfoliosubmission.ApprovedBy', '=', 'sysuser.id')
                ->select(
                    'portfoliosubmission.SubmissionDate',
                    'portfoliosubmission.PortfolioFile as remark',
                    'portfoliosubmission.IsApproved',
                    'portfoliosubmission.ApprovedAt',
                    'student.FirstName as StudentFirstName',
                    'student.LastName as StudentLastName',
                    DB::raw("CONCAT(faculty.FirstName, ' ', faculty.LastName) AS FacultyName"),
                    'subject.Name as subject_name',
                    'course.Name as course_name',
                    'sysuser.name as Approved_name'
                )
                ->whereDate('portfoliosubmission.SubmissionDate', '>=', $validatedData['FromDate'])
                ->whereDate('portfoliosubmission.SubmissionDate', '<=', $validatedData['ToDate'])
                ->where('student.BranchId', session('BranchId'));

            // Apply filters if provided
            if ($request->filled('StudentId') && $request->StudentId !== 'Select Student') {
                $query->where('portfoliosubmission.StudentId', $request->StudentId);
            }

            if ($request->filled('FacultyId') && $request->FacultyId !== 'Select Faculty') {
                $query->where('portfoliosubmission.FacultyId', $request->FacultyId);
            }

            if ($request->filled('SubjectId') && $request->SubjectId !== 'Select Subject') {
                $query->where('portfoliosubmission.SubjectId', $request->SubjectId);
            }
            $portfoliodata = $query->distinct()->get();
            return response()->json(['data' => $portfoliodata, 'message' => 'Portfolio submission data retrieved successfully'], 200);
        } catch (\Exception $e) {
            // Handle the exception
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }
}
