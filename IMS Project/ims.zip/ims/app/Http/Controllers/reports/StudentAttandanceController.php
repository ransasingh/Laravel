<?php

namespace App\Http\Controllers\reports;

use App\Http\Controllers\Controller;
use App\Models\Batch;
use App\Models\Faculty;
use App\Models\Student;
use App\Models\StudentAttendance;
use App\Models\subject;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class StudentAttandanceController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $subjects = subject::where('IsActive', '1')->get();
        $faculties = Faculty::where('IsActive', '1')
            ->where('BranchId', session('BranchId'))
            ->get();
        $students = Student::where('IsActive', 1)
            ->where('BranchId', session('BranchId'))
            ->get();
        // $batches = Batch::where('IsActive', '1')->get();
        $batches = Batch::where('batch.IsActive', 1)
            ->join('faculty', 'batch.FacultyId', '=', 'faculty.id')
            ->where('faculty.BranchId', '=', session('BranchId'))
            ->get();
        return view('reports.studentattandance.studentattandance', compact('subjects', 'faculties', 'students', 'batches'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        try {
            // Validate the request
            $validatedData = $request->validate([
                'FromDate' => 'required|date',
                'ToDate' => 'required|date|after_or_equal:FromDate',
            ]);

            // Initialize the base query
            $query = DB::table('studentattandance')
                ->join('batch', 'studentattandance.BatchDetailId', '=', 'batch.id')
                ->join('student', 'studentattandance.StudentId', '=', 'student.id')
                ->join('course', 'student.CourseId', '=', 'course.id')
                ->join('batchdetail', 'batch.id', '=', 'batchdetail.BatchId')
                ->join('subject', 'batchdetail.SubjectId', '=', 'subject.id')
                ->select(
                    'studentattandance.ForDate',
                    'studentattandance.DayAttandance',
                    'student.FirstName',
                    'student.LastName',
                    'batch.Name as batch_name',
                    'batch.FromDate',
                    'batch.ToDate',
                    'subject.Name as subject_name',
                    'course.Name as course_name',
                    'batch.StartTimeInMinutes',
                    'batch.EndTimeInMinutes'
                )
                ->whereDate('studentattandance.ForDate', '>=', $validatedData['FromDate'])
                ->whereDate('studentattandance.ForDate', '<=', $validatedData['ToDate'])
                ->where('student.BranchId', session('BranchId'));

            // Apply filters if provided
            if ($request->filled('StudentId') && $request->StudentId !== 'Select Student') {
                $query->where('student.id', $request->StudentId);
            }

            if ($request->filled('BatchId') && $request->BatchId !== 'Select Batch') {
                $query->where('batch.id', $request->BatchId);
            }

            if ($request->filled('FacultyId') && $request->FacultyId !== 'Select Faculty') {
                $query->where('student.FacultyId', $request->FacultyId);
            }

            if ($request->filled('SubjectId') && $request->SubjectId !== 'Select Subject') {
                $query->where('subject.id', $request->SubjectId);
            }

            // Fetch data
            $attendanceData = $query->distinct()->get();
            // Return success response with the data
            return response()->json(['success' => 'Report generated successfully.', 'attendanceData' => $attendanceData]);
        } catch (\Exception $e) {
            // Return error response if an exception occurs
            return response()->json(['error' => 'An error occurred while fetching data.'], 500);
        }
    }



    /**
     * Display the specified resource.
     */
    public function studentwithsubject(Request $request)
    {
        return view('reports.studentattandance.StudentWithSubjectReport');
    }
    /**
     * Display the specified resource.
     */

    public function StudentBatch(Request $request)
    {
        return view('reports.studentattandance.StudentBatchReport');
    }
    /**
     * Display the specified resource.
     */

    public function StudentDetail(Request $request)
    {
        return view('reports.studentattandance.StudentdetailReport');
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function studentwithsubjectreport(Request $request)
    {
        try {
            // Validate the request
            $validatedData = $request->validate([
                'AdmissionDate' => 'required|date',
                'ToDate' => 'required|date|after_or_equal:AdmissionDate',
            ]);

            // Fetch student data
            $students = DB::table('student')
                ->join('course', 'student.CourseId', '=', 'course.id')
                ->join('studentbatchassign', 'student.id', '=', 'studentbatchassign.StudentId')
                ->join('batch', 'studentbatchassign.BatchDetailId', '=', 'batch.id')
                ->join('batchdetail', 'batch.id', '=', 'batchdetail.BatchId')
                ->leftJoin('subject', 'batchdetail.SubjectId', '=', 'subject.id')
                ->leftJoin('studentbatchassign as sba', function ($join) {
                    $join->on('student.id', '=', 'sba.StudentId')
                        ->on('batch.id', '=', 'sba.BatchDetailId');
                })
                ->select(
                    'student.id',
                    'student.FirstName',
                    'student.LastName',
                    'student.MobileNumber',
                    'student.AdmissionDate',
                    'course.Name as course_name',
                    DB::raw('GROUP_CONCAT(subject.Name) as subjects'),
                    DB::raw('GROUP_CONCAT(IF(sba.IsCompleted = 1, "Finished", "In Progress")) as IsCompleted')
                )
                ->whereBetween('student.AdmissionDate', [$validatedData['AdmissionDate'], $validatedData['ToDate']])
                ->where('student.BranchId', session('BranchId'))
                ->groupBy('student.id', 'student.FirstName', 'student.LastName', 'student.MobileNumber', 'student.AdmissionDate', 'course.Name')
                ->get();
            if ($students->isEmpty()) {
                return response()->json(['success' => false, 'error' => 'No student data found.']);
            }

            // Fetch all subjects
            $subjects = DB::table('subject')->pluck('Name');

            // Create an array to hold dynamic subject columns
            $dynamicColumns = [];

            // Loop through subjects to create column definitions
            foreach ($subjects as $subject) {
                $dynamicColumns[] = ['data' => $subject];
            }

            // Return response with student data and dynamic subject columns
            return response()->json(['success' => true, 'students' => $students, 'dynamicColumns' => $dynamicColumns]);
        } catch (\Exception $e) {
            // Handle exceptions
            return response()->json(['error' => 'An error occurred while generating the report: ' . $e->getMessage()], 500);
        }
    }

    /**
     * StudentBatchReport the specified resource in storage.
     */
    public function StudentBatchReport(Request $request)
    {
        try {
            $batchFilter = $request->input('Batch');

            $query = DB::table('student')
                ->select(
                    'student.id',
                    DB::raw('MAX(student.FirstName) AS FirstName'),
                    DB::raw('MAX(student.LastName) AS LastName'),
                    DB::raw('MAX(student.BranchId) AS BranchId'),
                    DB::raw('MAX(student.CourseId) AS CourseId'),
                    DB::raw('MAX(batch.StartTimeInMinutes) AS StartTimeInMinutes'),
                    DB::raw('MAX(batch.EndTimeInMinutes) AS EndTimeInMinutes'),
                    DB::raw('MAX(batch.FromDate) AS FromDate'),
                    DB::raw('MAX(batch.ToDate) AS ToDate'),
                    DB::raw('MAX(batch.Name) AS batchName'),
                    DB::raw('(CASE WHEN COUNT(studentbatchassign.BatchDetailId) > 0 THEN "With Batch" ELSE "Without Batch" END) AS BatchStatus'), // Add batch status calculation
                    'batchdetail.SubjectId',
                    'subject.Name as subjectName',
                    'subject.NoOfSession as total_session',
                    'course.Name as courseName',
                    'institutebranch.Name as branchName',
                    DB::raw('(SELECT COUNT(DISTINCT studentattandance.id) FROM studentattandance WHERE studentattandance.StudentId = student.id) as attendanceCount')
                )
                ->leftJoin('studentbatchassign', 'student.id', '=', 'studentbatchassign.StudentId')
                ->leftJoin('studentattandance', 'student.id', '=', 'studentattandance.StudentId')
                ->join('batch', 'studentbatchassign.BatchDetailId', '=', 'batch.id')
                ->join('batchdetail', 'batch.id', '=', 'batchdetail.BatchId')
                ->join('subject', 'batchdetail.SubjectId', '=', 'subject.id')
                ->join('course', 'student.CourseId', '=', 'course.id')
                ->join('institutebranch', 'student.BranchId', '=', 'institutebranch.id')
                ->where('student.BranchId', session('BranchId'))
                ->groupBy('student.id', 'batchdetail.SubjectId', 'subject.Name', 'subject.NoOfSession', 'course.Name', 'institutebranch.Name');

            if ($batchFilter == 'WithBatch') {
                $query->havingRaw('COUNT(studentbatchassign.BatchDetailId) > 0');
            } elseif ($batchFilter == 'WithoutBatch') {
                $query->havingRaw('COUNT(studentbatchassign.BatchDetailId) = 0');
            }

            // Execute the query
            $studentDetails = $query->get();

            // Calculate remaining session count
            foreach ($studentDetails as $student) {
                $remainingSessions = $student->total_session - $student->attendanceCount;
                $student->remainingSessions = $remainingSessions < 0 ? 0 : $remainingSessions;
                $student->FilterName = $batchFilter; // Add the batch filter name to each student detail
                // Calculate batch progress percentage
                $batchProgress = ($student->attendanceCount / $student->total_session) * 100;
                $student->batchProgress = round($batchProgress, 2); // Round to two decimal places
            }

            return response()->json(['success' => true, 'students' => $studentDetails]);
        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    public function StudentDetailReport(Request $request)
    {
        try {
            // Retrieve the admission date range from the request
            $fromDate = $request->input('AdmissionDate');
            $toDate = $request->input('ToDate');

            // Fetch students based on the admission date range
            $students = DB::table('student')
                ->join('state', 'student.StateId', '=', 'state.id')
                ->join('state as state1', 'student.PrStateId', '=', 'state1.id')
                ->join('institute', 'student.InstituteId', '=', 'institute.id')
                ->join('institutebranch', 'student.BranchId', '=', 'institutebranch.id')
                ->whereBetween('student.AdmissionDate', [$fromDate, $toDate])
                ->where('student.BranchId', session('BranchId'))
                ->select('student.*', 'state.Name as state_name', 'state1.Name as PrState', 'institute.Name as institute_name', 'institutebranch.Name as branch_name')
                ->get();

            // Check if any students were found
            if ($students->isEmpty()) {
                return response()->json(['error' => 'No data found for the specified date range.'], 404);
            }

            return response()->json($students);
        } catch (\Exception $e) {
            // Handle exceptions
            return response()->json(['error' => 'Failed to fetch students.'], 500);
        }
    }
}
