<?php

namespace App\Http\Controllers\reports;

use App\Http\Controllers\Controller;
use App\Models\Feereceipt;
use App\Models\Firm;
use App\Models\InstituteBranch;
use App\Models\Student;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class RevenueReportController extends Controller
{
    public function RevenueReport(Request $request)
    {
        $branches = InstituteBranch::where('IsActive', 1)->get();
        $students = Student::where('IsActive', 1)
            ->where('BranchId', session('BranchId'))
            ->get();
        $firms = Firm::where('IsActive', 1)->get();

        return view('reports.revenuereport.revenuereport', compact('branches', 'students', 'firms'));
    }

    public function RevenueReportdetail(Request $request)
    {
        // Retrieve request parameters
        $branchId = $request->input('BranchId');
        $fromDate = $request->input('FromDate');
        $toDate = $request->input('ToDate');
        $studentId = $request->input('StudentId');
        $firmId = $request->input('Firmid');
        $paymentMode = $request->input('PaymentMode');
        $reportId = $request->input('reportid');

        // Start building the query
        $query = Feereceipt::query();

        // Join tables
        $query->join('student', 'student.id', '=', 'feereceipt.StudentId')
            ->join('bank', 'bank.id', '=', 'feereceipt.BankId')
            ->join('institutebranch', 'institutebranch.id', '=', 'student.BranchId')
            ->leftJoin('feereceiptdetail', 'feereceipt.id', '=', 'feereceiptdetail.FeeReceiptId');

        // Apply filters
        if ($studentId && $studentId != "Select Student") {
            $query->where('feereceipt.StudentId', $studentId);
        }
        if ($fromDate && $toDate) {
            $query->whereBetween('feereceipt.ReceiptDate', [$fromDate, $toDate]);
        }
        if ($paymentMode && $paymentMode != "Select Mode Payment") {
            $query->where('feereceipt.PaymentMode', $paymentMode);
        }
        if ($firmId && $firmId != "Select Firm") {
            $query->where('feereceipt.BankId', $firmId);
        }
        if ($branchId) {
            $query->where('student.BranchId', $branchId);
        }

        // Initialize variables for response data
        $data = [];
        $headers = [];
        $grandTotal = [
            'student_name' => 'Grand Total',
            'total_sum_of_fee' => 0,
            'total_received_sum_amount' => 0,
            'total_due_amount' => 0
        ];

        // Select clause based on the report type
        if ($reportId == 'BW') {
            // For Branch Wise report type
            $branchWiseData = $query->select(
                'institutebranch.Name as branch_name',
                DB::raw('(SELECT SUM(student.TotalFeeAmount) FROM student WHERE student.BranchId = institutebranch.id) as total_sum_of_fee'),
                DB::raw('COALESCE(SUM(feereceiptdetail.Amount), 0) as total_received_sum_amount'),
                DB::raw('((SELECT SUM(student.TotalFeeAmount) FROM student WHERE student.BranchId = institutebranch.id) - COALESCE(SUM(feereceiptdetail.Amount), 0)) as total_due_amount')
            )
                ->groupBy('institutebranch.Name', 'institutebranch.id') // Group by institutebranch.Name
                ->get();

            // Calculate grand total for all branches
            $grandTotal['total_sum_of_fee'] = $branchWiseData->sum('total_sum_of_fee');
            $grandTotal['total_received_sum_amount'] = $branchWiseData->sum('total_received_sum_amount');
            $grandTotal['total_due_amount'] = $grandTotal['total_sum_of_fee'] - $grandTotal['total_received_sum_amount'];

            // Define headers for the table
            $headers = [
                'branch_name' => 'Branch Name',
                'total_sum_of_fee' => 'Total Sum of Fee',
                'total_received_sum_amount' => 'Total Received Sum Amount',
                'total_due_amount' => 'Total Due Amount'
            ];

            // Append grand total row to the data array
            $branchWiseData->push($grandTotal);

            // Return JSON response with data, headers, grand total, and report type
            return response()->json([
                'data' => $branchWiseData,
                'headers' => $headers,
                'grandTotal' => $grandTotal,
                'reportType' => $reportId
            ]);
        } elseif ($reportId == 'SW') {
            // Fetch all students, including those with total fee amounts present but no receiving data
            $studentsData = DB::table('student')
                ->select(
                    DB::raw("CONCAT(student.FirstName, ' ', student.LastName) AS student_name"),
                    'student.TotalFeeAmount as total_sum_of_fee',
                    DB::raw('COALESCE(SUM(feereceiptdetail.Amount), 0) as total_received_sum_amount'),
                    DB::raw('(student.TotalFeeAmount - COALESCE(SUM(feereceiptdetail.Amount), 0)) as total_due_amount')
                )
                ->leftJoin('feereceipt AS fr', 'student.id', '=', 'fr.StudentId')
                ->leftJoin('feereceiptdetail', 'fr.id', '=', 'feereceiptdetail.FeeReceiptId')
                ->where('student.BranchId', $branchId); // Apply branch filter here

            // Additional filters
            if ($studentId && $studentId != "Select Student") {
                $studentsData->where('student.id', $studentId);
            }

            $studentsData = $studentsData->groupBy('student.id', 'student.FirstName', 'student.LastName', 'student.TotalFeeAmount')
                ->get();

            // Calculate grand total for displayed students
            $grandTotal = [
                'student_name' => 'Grand Total',
                'total_sum_of_fee' => $studentsData->sum('total_sum_of_fee'),
                'total_received_sum_amount' => $studentsData->sum('total_received_sum_amount'),
                'total_due_amount' => $studentsData->sum('total_due_amount')
            ];

            // Define headers for the table
            $headers = [
                'student_name' => 'Student Name',
                'total_sum_of_fee' => 'Total Sum of Fee',
                'total_received_sum_amount' => 'Total Received Sum Amount',
                'total_due_amount' => 'Total Due Amount'
            ];

            // Assign the modified data to $data
            $data = $studentsData->toArray();
        } elseif ($reportId == 'PW') {
            // For Payment Mode Wise Group report type
            // Select clause
            $query->select(
                'feereceipt.PaymentMode as payment_mode',
                DB::raw('(SELECT 
                            SUM(CASE WHEN feereceipt.PaymentMode = "Cash" THEN student.TotalFeeAmount ELSE 0 END) 
                            FROM student 
                            WHERE student.BranchId = institutebranch.id) as total_sum_of_fee'),
                DB::raw('COALESCE(SUM(feereceiptdetail.Amount), 0) as total_received_sum_amount'),
                DB::raw('(SELECT 
                            SUM(CASE WHEN feereceipt.PaymentMode = "Cash" THEN student.TotalFeeAmount ELSE 0 END) 
                            FROM student 
                            WHERE student.BranchId = institutebranch.id) - COALESCE(SUM(feereceiptdetail.Amount), 0) as total_due_amount')
            );

            // Group by payment mode and order by payment mode
            $query->groupBy('feereceipt.PaymentMode', 'institutebranch.id')
                ->orderBy('feereceipt.PaymentMode');

            // Get data
            $paymentModeWiseData = $query->get();

            // Define headers for the table
            $headers = [
                'payment_mode' => 'Payment Mode',
                'total_sum_of_fee' => 'Total Sum of Fee',
                'total_received_sum_amount' => 'Total Received Sum Amount',
                'total_due_amount' => 'Total Due Amount'
            ];

            // Calculate grand total for all payment modes
            $grandTotal['total_sum_of_fee'] = $paymentModeWiseData->sum('total_sum_of_fee');
            $grandTotal['total_received_sum_amount'] = $paymentModeWiseData->sum('total_received_sum_amount');
            $grandTotal['total_due_amount'] = $grandTotal['total_sum_of_fee'] - $grandTotal['total_received_sum_amount'];

            // Append grand total row to the data array
            $paymentModeWiseData->push($grandTotal);

            // Return the response
            return response()->json([
                'data' => $paymentModeWiseData,
                'headers' => $headers,
                'grandTotal' => $grandTotal,
                'reportType' => $reportId
            ]);
        } elseif($reportId == 'MW') {
            $monthWiseData = DB::table('feereceipt')
                ->select(
                    DB::raw('MONTHNAME(student.AdmissionDate) as month'),
                    DB::raw('COALESCE(SUM(DISTINCT student.TotalFeeAmount), 0) as total_sum_of_total_fee_monthwise'),
                )
                ->join('student', 'student.id', '=', 'feereceipt.StudentId')
                ->join('institutebranch', 'institutebranch.id', '=', 'student.BranchId')
                ->groupBy('month', 'institutebranch.id')
                ->get();

            $totalAmountReceived = DB::table('feereceipt')
                ->select(
                    DB::raw('MONTHNAME(feereceipt.ReceiptDate) as month'),
                    DB::raw('COALESCE(SUM(feereceiptdetail.Amount), 0) as total_sum_of_amount_received')
                )
                ->leftJoin('feereceiptdetail', 'feereceipt.id', '=', 'feereceiptdetail.FeeReceiptId')
                ->groupBy('month')
                ->get();

            // Create an associative array of total fees indexed by month
            $totalFeesByMonth = $monthWiseData->pluck('total_sum_of_total_fee_monthwise', 'month')->toArray();

            // Iterate over $totalAmountReceived and add missing months to $monthWiseData
            foreach ($totalAmountReceived as $receivedData) {
                if (!array_key_exists($receivedData->month, $totalFeesByMonth)) {
                    $monthWiseData->push((object)[
                        'month' => $receivedData->month,
                        'total_sum_of_total_fee_monthwise' => 0
                    ]);
                }
            }

            // Convert arrays to objects
            $monthWiseData = collect($monthWiseData)->map(function ($item) {
                if (is_array($item)) {
                    return (object) $item;
                }
                return $item;
            });

            // Sort $monthWiseData by month name
            $monthWiseData = $monthWiseData->sortBy('month');

            // Calculate due amount and append to $monthWiseData
            foreach ($monthWiseData as $monthData) {
                $receivedData = $totalAmountReceived->firstWhere('month', $monthData->month);
                $monthData->total_sum_of_amount_received = $receivedData ? $receivedData->total_sum_of_amount_received : 0;
                $monthData->total_sum_of_total_due_amount = $monthData->total_sum_of_total_fee_monthwise - $monthData->total_sum_of_amount_received;
            }

            // Define headers for the table
            $headers = [
                'month' => 'Receipt Date.Month',
                'total_sum_of_total_fee_monthwise' => 'Total Sum of Total Fee',
                'total_sum_of_amount_received' => 'Total Sum of Amount Received',
                'total_sum_of_total_due_amount' => 'Total Sum of Total Due Amount'
            ];

            // Calculate grand total for all months
            $grandTotal = [
                'month' => 'Grand Total',
                'total_sum_of_total_fee_monthwise' => $monthWiseData->sum('total_sum_of_total_fee_monthwise'),
                'total_sum_of_amount_received' => $totalAmountReceived->sum('total_sum_of_amount_received'),
                'total_sum_of_total_due_amount' => max($monthWiseData->sum('total_sum_of_total_due_amount'), 0)
            ];

            // Move Grand Total to the first position
            $monthWiseData->push((object) $grandTotal);

       
            // Return the response
            return response()->json([
                'data' => $monthWiseData, // Remove duplicates
                'headers' => $headers,
                'grandTotal' => $grandTotal,
                'reportType' => $reportId
            ]);
        } 
        
         else {
            $data = DB::table('feereceipt')
                ->selectRaw('
                CONCAT(s1.FirstName, " ", s1.LastName) as `STUDENT NAME`,
                feereceipt.ReceiptDate as `RECEIPT DATE`,
                MONTHNAME(feereceipt.ReceiptDate) as `RECEIPT MONTH`,
                feereceipt.ReceiptNo as `RECEIPT NO`,
                b1.BankName as `BANK NAME`,
                feereceipt.PaymentMode as `PAYMENT MODE`,
                feereceipt.FinancialYearId as `FINANCIAL YEAR`,
                student.TotalFeeAmount as `TOTAL FEE AMOUNT`,
                IFNULL(SUM(frd.Amount), 0) AS `RECEIVED AMOUNT`
            ')
                ->join('student', 'student.id', '=', 'feereceipt.StudentId')
                ->join('bank', 'bank.id', '=', 'feereceipt.BankId')
                ->join('student as s1', 's1.id', '=', 'feereceipt.StudentId')
                ->join('bank as b1', 'b1.id', '=', 'feereceipt.BankId')
                ->leftJoin('feereceiptdetail as frd', 'feereceipt.id', '=', 'frd.FeeReceiptId')
                ->where('student.BranchId', $branchId) // Apply branch filter here
                ->whereNull('feereceipt.deleted_at')
                ->groupBy(
                    's1.FirstName',
                    's1.LastName',
                    'feereceipt.ReceiptDate',
                    'feereceipt.ReceiptNo',
                    'b1.BankName',
                    'feereceipt.PaymentMode',
                    'feereceipt.FinancialYearId',
                    'student.TotalFeeAmount'
                )
                ->orderBy('s1.id', 'asc')
                ->get();

            // Calculate accumulated received amounts for each student
            $receivedAmounts = [];
            foreach ($data as $row) {
                $studentName = $row->{'STUDENT NAME'};
                if (!isset($receivedAmounts[$studentName])) {
                    $receivedAmounts[$studentName] = 0;
                }
                $receivedAmounts[$studentName] += $row->{'RECEIVED AMOUNT'};
            }

            // Calculate due amounts for each row
            foreach ($data as $row) {
                $studentName = $row->{'STUDENT NAME'};
                $totalFeeAmount = $row->{'TOTAL FEE AMOUNT'};
                $receivedAmount = $receivedAmounts[$studentName];
                // Check if total and received amounts match strictly and set due amount accordingly
                $row->{'DUE AMOUNT'} = $totalFeeAmount === $receivedAmount ? 0 : $totalFeeAmount - $receivedAmount;
            }

            // If there are no records, set an empty array for headers
            $headers = count($data) > 0 ? array_keys((array)$data[0]) : [];

            // Return JSON response with data and headers
            return response()->json([
                'data' => $data,
                'headers' => $headers,
                'grandTotal' => $grandTotal, // Assuming $grandTotal is defined earlier
                'reportType' => $reportId
            ]);
        }

        // Append grand total row only once to the data array
        $data[] = (object) $grandTotal;

        // Return JSON response with data, headers, grand total, and report type
        return response()->json([
            'data' => $data,
            'headers' => $headers,
            'grandTotal' => $grandTotal,
            'reportType' => $reportId
        ]);
    }
}
  // ->groupBy('feereceipt.ReceiptDate') // Group by receipt date
                // ->groupBy('institutebranch.id') // Group by institute branch id

                // if ($reportId == 'MW') {
                //     $month = $request->input('month');
                //     $monthNumber = date('m', strtotime($month)); // Get month number
                //     $year = date('Y'); // Assuming you want to fetch data for the current year
        
                //     // Fetch month-wise details from the feereceipt table based on receipt date
                //     $monthDetails = DB::table('feereceipt')
                //         ->select('*')
                //         ->whereMonth('ReceiptDate', $monthNumber)
                //         ->whereYear('ReceiptDate', $year)
                //         ->get();
        
                //     // Return JSON response with the month-wise details
                //     return response()->json([
                //         'monthDetails' => $monthDetails
                //     ]);
                // }






                
            //         $data = DB::table('feereceipt')
            //             ->selectRaw('
            //     CONCAT(s1.FirstName, " ", s1.LastName) as `STUDENT NAME`,
            //     feereceipt.ReceiptDate as `RECEIPT DATE`,
            //     MONTHNAME(feereceipt.ReceiptDate) as `RECEIPT MONTH`,
            //     feereceipt.ReceiptNo as `RECEIPT NO`,
            //     b1.BankName as `BANK NAME`,
            //     feereceipt.PaymentMode as `PAYMENT MODE`,
            //     feereceipt.FinancialYearId as `FINANCIAL YEAR`,
            //     student.TotalFeeAmount as `TOTAL FEE AMOUNT`,
            //     SUM(frd.Amount) AS `RECEIVED AMOUNT`,
            //     (student.TotalFeeAmount - 
            //         (SELECT SUM(frd1.Amount) 
            //          FROM feereceiptdetail frd1 
            //          WHERE frd1.FeeReceiptId = feereceipt.id)
            //     ) AS `DUE AMOUNT`
            // ')
            //             ->join('student', 'student.id', '=', 'feereceipt.StudentId')
            //             ->join('bank', 'bank.id', '=', 'feereceipt.BankId')
            //             ->join('institutebranch', 'institutebranch.id', '=', 'student.BranchId')
            //             ->join('student as s1', 's1.id', '=', 'feereceipt.StudentId')
            //             ->join('bank as b1', 'b1.id', '=', 'feereceipt.BankId')
            //             ->leftJoin('feereceiptdetail as frd', 'feereceipt.id', '=', 'frd.FeeReceiptId')
            //             ->where('student.BranchId', 1)
            //             ->whereNull('feereceipt.deleted_at')
            //             ->groupBy(
            //                 'feereceipt.id',
            //                 'feereceipt.ReceiptNo',
            //                 's1.id',
            //                 's1.FirstName',
            //                 's1.LastName',
            //                 'feereceipt.ReceiptDate',
            //                 'b1.BankName',
            //                 'feereceipt.PaymentMode',
            //                 'feereceipt.FinancialYearId',
            //                 'student.TotalFeeAmount'
            //             )


            //             ->orderBy('s1.id', 'asc')
            //             ->get();

            //         $data = $data->toArray();

            //         // If there are no records, set an empty array for headers
            //         $headers = count($data) > 0 ? array_keys((array)$data[0]) : [];

            //         // Return JSON response with data and headers
            //         return response()->json([
            //             'data' => $data,
            //             'headers' => $headers,
            //             'grandTotal' => $grandTotal, // Assuming $grandTotal is defined earlier
            //             'reportType' => $reportId
            //         ]);