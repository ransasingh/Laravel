<?php

namespace App\Http\Controllers\reports;

use App\Http\Controllers\Controller;
use App\Models\Batch;
use App\Models\Faculty;
use App\Models\subject;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class FacultyReportsController extends Controller
{
    public function FacultyDetail(Request $request)
    {
        return view('reports.facultyreport.FacultydetailReport');
    }
    public function FacultyDetailReport(Request $request)
    {
        try {
            // Retrieve the status from the request
            $status = $request->input('IsActive');

            // Map status values to database values
            $statusMap = [
                'All' => null, // Fetch all records
                'Active' => 1,
                'In-Active' => 0,
            ];

            // Fetch faculty based on the status
            $faculty = DB::table('faculty')
                ->join('state', 'faculty.StateId', '=', 'state.id')
                ->join('state as state1', 'faculty.PrStateId', '=', 'state1.id')
                ->join('institute', 'faculty.InstituteId', '=', 'institute.id')
                ->join('institutebranch', 'faculty.BranchId', '=', 'institutebranch.id')
                ->when($status !== 'All', function ($query) use ($status, $statusMap) {
                    // Filter based on the status
                    return $query->where('faculty.IsActive', $statusMap[$status]);
                })
                ->where('faculty.BranchId', session('BranchId'))
                ->select('faculty.*', 'state.Name as state_name', 'state1.Name as PrState', 'institute.Name as institute_name', 'institutebranch.Name as branch_name')
                ->get();

            // Check if any faculty were found
            if ($faculty->isEmpty()) {
                return response()->json(['error' => 'No data found for the specified status.'], 404);
            }

            return response()->json($faculty);
        } catch (\Exception $e) {
            // Handle exceptions
            return response()->json(['error' => 'Failed to fetch faculty.'], 500);
        }
    }
    public function FacultyBatch(Request $request)
    {
        return view('reports.facultyreport.FacultyBatchReport');
    }
    public function FacultyBatchReport(Request $request)
    {
        try {
            $batchFilter = $request->input('Batch');
            $facultyQuery = DB::table('faculty')
                ->join('institutebranch', 'faculty.BranchId', '=', 'institutebranch.id')
                ->leftJoin('batch', 'faculty.id', '=', 'batch.FacultyId')
                ->where('faculty.BranchId', session('BranchId'))
                ->select(
                    'faculty.id',
                    'faculty.FirstName',
                    'faculty.LastName',
                    'institutebranch.Name as branch_name',
                    'batch.*',
                    DB::raw("CASE WHEN batch.id IS NOT NULL THEN 'With Batch' ELSE 'Without Batch' END AS BatchStatus")
                );

            if ($batchFilter === 'WithBatch') {
                $facultyQuery->whereNotNull('batch.id');
            } elseif ($batchFilter === 'WithoutBatch') {
                $facultyQuery->whereNull('batch.id');
            }

            $faculty = $facultyQuery->get();

            return response()->json($faculty);
        } catch (\Exception $e) {
            return response()->json(['error' => 'Failed to fetch faculty batch report.'], 500);
        }
    }

    public function FacultyBatchTiming(Request $request)
    {
        $subjects = subject::where('IsActive', '1')->get();
        $faculties = Faculty::where('IsActive', '1')
            ->where('BranchId', session('BranchId'))
            ->get();

        $batches = Batch::where('batch.IsActive', 1)
            ->join('faculty', 'batch.FacultyId', '=', 'faculty.id')
            ->where('faculty.BranchId', session('BranchId'))
            ->select('batch.*') // Select only batch columns
            ->get();

        return view('reports.facultyreport.FacultyBatchtimingReport', compact('subjects', 'faculties', 'batches'));
    }

    public function FacultyBatchTimingReport(Request $request)
    {
        try {
            // Initialize the base query
            $query = DB::table('facultyattandance')
                ->join('batch', 'facultyattandance.BatchDetailId', '=', 'batch.id')
                ->join('faculty', 'batch.FacultyId', '=', 'faculty.id')
                ->join('batchdetail', 'batch.id', '=', 'batchdetail.BatchId')
                ->join('coursesubject', 'batchdetail.SubjectId', '=', 'coursesubject.SubjectId')
                ->join('subject', 'batchdetail.SubjectId', '=', 'subject.id')
                ->join('course', 'coursesubject.CourseId', '=', 'course.id')
                ->select(
                    'facultyattandance.ForDate',
                    'facultyattandance.StartTime',
                    'facultyattandance.EndTime',
                    DB::raw('MAX(faculty.FirstName) as FirstName'),
                    DB::raw('MAX(faculty.LastName) as LastName'),
                    DB::raw('MAX(batch.Name) as batch_name'),
                    'batch.FromDate',
                    'batch.ToDate',
                    'subject.Name as subject_name',
                    'course.Name as course_name',
                    'batch.StartTimeInMinutes',
                    'batch.EndTimeInMinutes'
                )
                ->whereDate('facultyattandance.ForDate', '>=', $request->FromDate)
                ->whereDate('facultyattandance.ForDate', '<=', $request->ToDate)
                ->where('faculty.BranchId', session('BranchId'))
                ->groupBy(
                    'facultyattandance.ForDate',
                    'facultyattandance.StartTime',
                    'facultyattandance.EndTime',
                    'batch.FromDate',
                    'batch.ToDate',
                    'subject.Name',
                    'course.Name',
                    'batch.StartTimeInMinutes',
                    'batch.EndTimeInMinutes'
                );

            if ($request->filled('BatchId') && $request->BatchId !== 'Select Batch') {
                $query->where('batch.id', $request->BatchId);
            }

            if ($request->filled('FacultyId') && $request->FacultyId !== 'Select Faculty') {
                $query->where('faculty.id', $request->FacultyId);
            }

            if ($request->filled('SubjectId') && $request->SubjectId !== 'Select Subject') {
                $query->where('subject.id', $request->SubjectId);
            }

            // Execute the query and get distinct results
            $results = $query->get();

            // Return JSON response with the results
            return response()->json(['success' => true, 'data' => $results]);
        } catch (\Exception $e) {
            // Return JSON response with error message
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    public function FacultyAttandanceCounter(Request $request)
    {
        return view('reports.facultyreport.FacultyAttandanceReport');
    }

    public function FacultyAttandanceCounterReport(Request $request)
    {
        try {
            // Get start and end dates from the request
            $startDate = $request->input('StartTime');
            $endDate = $request->input('EndTime');

            // Query with date filters
            $facultyAttendanceAndBatchCounts = DB::table('faculty')
                ->leftJoin('batch', 'faculty.id', '=', 'batch.FacultyId')
                ->leftJoin('facultyattandance', 'batch.id', '=', 'facultyattandance.BatchDetailId')
                ->whereBetween('facultyattandance.ForDate', [$startDate, $endDate]) // Filter by date range
                ->select(
                    DB::raw("CONCAT(faculty.FirstName, ' ', faculty.LastName) as facultyName"),
                    DB::raw("COUNT(DISTINCT batch.id) as totalBatchCount"),
                    DB::raw("COUNT(DISTINCT DATE(facultyattandance.ForDate)) as totalAttendanceCount")
                )
                ->groupBy('faculty.id', 'faculty.FirstName', 'faculty.LastName')
                ->get();

            return response()->json(['success' => true, 'facultyAttendanceAndBatchCounts' => $facultyAttendanceAndBatchCounts]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }
}
