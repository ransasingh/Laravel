<?php

namespace App\Http\Controllers\reports;

use App\Http\Controllers\Controller;
use App\Models\Batch;
use App\Models\Faculty;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BatchReportController extends Controller
{
    public function BatchExtension(Request $request)
    {
        $faculties = Faculty::where('IsActive', '1')
            ->where('BranchId', session('BranchId'))
            ->get();

        $batches = Batch::where('batch.IsActive', 1)
            ->join('faculty', 'batch.FacultyId', '=', 'faculty.id')
            ->where('faculty.BranchId', session('BranchId'))
            ->select('batch.*')
            ->get();
        return view('reports.batchreport.BatchtExtensionReport', compact('faculties', 'batches'));
    }


    public function BatchExtensionReport(Request $request)
    {
        try {
            // Initialize the base query
            $query = DB::table('batchextension')
                ->join('batch', 'batchextension.BatchId', '=', 'batch.id')
                ->join('faculty', 'batch.FacultyId', '=', 'faculty.id')
                ->leftJoin('sysuser', 'batchextension.VerifyBy', '=', 'sysuser.id')
                ->select(
                    'batchextension.id',
                    'batch.Name as batch_name',
                    DB::raw("CONCAT(faculty.FirstName, ' ', faculty.LastName) AS faculty_name"),
                    'batchextension.created_at as request_date',
                    'batch.FromDate as batch_start_date',
                    'batch.ToDate as batch_end_date',
                    'batchextension.Remarks',
                    'batchextension.IsApproved',
                    'batchextension.VerifyAt as approved_at',
                    'sysuser.name as approved_by'
                );

            // Apply additional conditions if provided in the request
            if ($request->filled('FacultyId') && $request->FacultyId !== 'Select Faculty') {
                $query->where('faculty.id', $request->FacultyId);
            }

            if ($request->filled('BatchId') && $request->BatchId !== 'Select Batch') {
                $query->where('batch.id', $request->BatchId);
            }

            if ($request->filled('Status')) {
                $status = $request->Status;
                if ($status === 'Approved') {
                    $query->where('batchextension.IsApproved', 1);
                } elseif ($status === 'Rejected') {
                    $query->where('batchextension.IsApproved', 0);
                }
            }

            // Execute the query and get the results
            $results = $query->get();

            // Return JSON response with the results
            return response()->json(['success' => true, 'data' => $results]);
        } catch (\Exception $e) {
            // Return JSON response with error message
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }
}
