<?php

namespace App\Http\Controllers;

use App\Models\Course;
use App\Models\Student;
use App\Models\State;
use App\Models\Institute;
use App\Models\CourseSubject;
use App\Models\StudentCourse;
use App\Models\Academicyear;
use App\Models\User;
use App\Models\Faculty;
use App\Models\UserBranchRight;
use App\Models\Usermoduleright;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Validator;

class Studentc extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $data = Student::join('state', 'student.StateId', '=', 'state.id')
            ->select('student.*', 'state.Name as state_name')
            ->where('BranchId', session('BranchId'))
            ->get();

        return view('student.list', compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $institutes = Institute::where('IsActive', '1')->get();
        $institutesid = $institutes[0]['id'];
        $states = State::where('IsActive', '1')->get();
        $courses = Course::where('IsActive', '1')->get();
        $faculties = Faculty::where('IsActive', '1')->get();

        return view('student.add', compact('institutesid', 'states', 'courses', 'faculties'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {

        $validator = Validator::make(request()->all(), [
            'FirstName' => 'required|string',
            'LastName' => 'required|string',
            'MobileNumber' => 'required|numeric|digits:10|unique:student,MobileNumber',
            // 'ParentMobile' => 'required|numeric|different:MobileNumber|digits:10',
            'EmailId' => 'required|email|max:255|unique:sysuser,email',
            // 'password' => [
            //     'required',
            //     'string',
            //     'min:8',
            //     'confirmed',
            //     'regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]/',
            // ],
            // 'password_confirmation' => 'required|string|min:8|same:password',

            'AddressLine1' => 'required',
            'StateId' => 'required|integer',
            'CityName' => 'required|string',
            'PostalCode' => 'required',
            'PrAddressLine1' => 'required',
            'PrStateId' => 'required|integer',
            'PrCityName' => 'required',
            'EmergencyContactNumber' => 'required|numeric|digits:10',
            'ModeOfCoaching' => 'required',
            'ModeofPayment' => 'required',
            // 'Status' => 'required',
            'DOB' => 'required|date',
            'AdmissionDate' => 'required|date',
            'CourseId' => 'required',
            'FacultyId' => 'required',
            'BatchFromMnt' => 'required|date_format:H:i',
            'BatchToMnt' => 'required|date_format:H:i|after_or_equal:BatchFromMnt',
            'ProfileImage' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
            'SignImage' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',

        ], [
            'EmailId.required' => 'Email is required',
            'EmailId.unique' => 'The provided email address is already in use',
            'FirstName.required' => 'First name is required',
            'LastName.required' => 'Last name is required',
            'MobileNumber.required' => 'Mobile number is required',
            'MobileNumber.numeric' => 'Mobile number must be numeric',
            'MobileNumber.digits' => 'Mobile number must be 10 digits',
            // 'password.regex' => 'The password must contain at least one lowercase letter, one uppercase letter, one digit, and one special character.',

            'AddressLine1.required' => 'Address is required',
            'PrAddressLine1.required' => 'Permanent address is required',
            'StateId.required' => 'Select state.',
            'PrStateId.required' => 'Select state.',
            'DOB.required' => 'Date of Birth is required.',
            'PrCityName.required' => 'Permanent city name is required.',

            'BatchToMnt.after_or_equal' => 'Batch end time must be equal to or after the start time',

            'ProfileImage.nullable' => 'Profile image must be an image',
            'ProfileImage.image' => 'Profile image must be a valid image file',
            'ProfileImage.mimes' => 'Profile image must be in one of the formats: jpeg, png, jpg, gif',
            'ProfileImage.max' => 'Profile image cannot exceed 2048 kilobytes',

            'SignImage.nullable' => 'Signature image must be an image',
            'SignImage.image' => 'Signature image must be a valid image file',
            'SignImage.mimes' => 'Signature image must be in one of the formats: jpeg, png, jpg, gif',
            'SignImage.max' => 'Signature image cannot exceed 2048 kilobytes',
        ]);

        if ($validator->fails()) {
            return redirect()->route('student.add.public')
                ->withErrors($validator)
                ->withInput();
        } else {
            DB::beginTransaction();
            try {
                $user_id = Auth::id();
                $user = new User;
                $user->name = $request->FirstName;
                $user->email   =  $request->EmailId;
                $user->password = bcrypt('Test@123');
                $user->IsActive = '1';
                $user->RoleId = '4';
                $user->InstituteId = $request->InstituteId;
                $user->createdBy = $user_id;
                $user->save();

                $userBranchRight = new UserBranchRight;
                $userBranchRight->UserId  = $user->id;
                $userBranchRight->BranchId = '1';
                $userBranchRight->createdBy = $user_id;
                $userBranchRight->save();

                $usermoduleright = new Usermoduleright;
                $usermoduleright->UserId  = $user->id;
                $usermoduleright->ModuleId  = '1';
                $usermoduleright->save();

                $student = new Student;
                if ($request->hasFile('ProfileImage')) {
                    $ProfileImage = time() . '.' . $request->ProfileImage->getClientOriginalExtension();
                    $request->ProfileImage->move(public_path('uploads/student/profile'), $ProfileImage);
                    $student->ProfileImage = $ProfileImage;
                } else {
                    $student->ProfileImage = 'default.jpg';
                }
                if ($request->hasFile('SignImage')) {
                    $SignImage = time() . '.' . $request->SignImage->getClientOriginalExtension();
                    $request->SignImage->move(public_path('uploads/student/signature'), $SignImage);
                    $student->SignImage = $SignImage;
                } else {
                    $student->SignImage = 'sign.jpg';
                }

                $student->FirstName = $request->FirstName;
                $student->LastName = $request->LastName;
                $student->MobileNumber = $request->MobileNumber;
                $student->EmailId = $request->EmailId;
                $student->AddressLine1 = $request->AddressLine1;
                $student->AddressLine2 = $request->AddressLine2;
                $student->StateId = $request->StateId;
                $student->CityName = $request->CityName;
                $student->PostalCode = $request->PostalCode;
                $student->InstituteId = $request->InstituteId;
                $student->UserId = $user->id;
                $student->createdBy = $user_id;
                $student->ParentMobile = $request->ParentMobile;
                $student->PrAddressLine1 = $request->PrAddressLine1;
                $student->PrAddressLine2 = $request->PrAddressLine2;
                $student->PrStateId = $request->PrStateId;
                $student->PrCityName = $request->PrCityName;
                $student->EmergencyContactNumber = $request->EmergencyContactNumber;
                $student->LastEducationQualification = $request->LastEducationQualification;
                $student->BloodGroup = $request->BloodGroup;
                $student->ModeOfCoaching = $request->ModeOfCoaching;
                $student->Status = null;
                $student->DOB = $request->DOB;
                $student->AdmissionDate = $request->AdmissionDate;
                $student->FacultyId = $request->FacultyId;
                $student->BatchFromMnt = $request->BatchFromMnt;
                $student->BatchToMnt = $request->BatchToMnt;
                $student->IsActive = $request->IsActive;
                // $student->ShowFee = $request->ShowFee;
                $student->PossibilityForUpgradation = $request->PossibilityForUpgradation;
                $student->CourseId = $request->CourseId;
                // $student->Description = $request->Description;
                $student->BranchId = '1';
                $student->ModeofPayment = $request->ModeofPayment;
                $student->save();
             
                $currentMonth = now()->format('M');
                $currentYear = now()->format('Y');
                // Update the business data
                Student::where('id', $student->id)->update([
                    'StudentCode' => 'Stu-' . $currentMonth . '-' . $currentYear . '-' . $student->id,
                ]);

                $courseSubjects = CourseSubject::where('CourseId', $student->CourseId)->get();
                $academicsName = Academicyear::where('IsCurrent', '1')->where('IsActive', '1')->latest()->value('Name');
                foreach ($courseSubjects as $courseSubject) {
                    $studentCourse = new StudentCourse;
                    $studentCourse->StudentId = $student->id;
                    $studentCourse->SubjectId = $courseSubject->SubjectId;
                    $studentCourse->AcademicYearId = $academicsName;
                    $studentCourse->IsExraSubject = '0';
                    $studentCourse->IsActive = '1';
                    $studentCourse->createdBy = $user_id;
                    $studentCourse->save();
                }

                DB::table('student')
                    ->join('feestructure', 'student.CourseId', '=', 'feestructure.CourseId')
                    ->join('feestructuremap', 'feestructure.id', '=', 'feestructuremap.FeeStructureId')
                    ->where('student.CourseId', $student->CourseId)
                    ->where('student.id', $student->id)
                    ->groupBy('student.id', 'feestructuremap.FeeStructureId')
                    ->update(['student.TotalFeeAmount' => DB::raw('(SELECT SUM(feestructuremap.Amount) FROM feestructuremap WHERE feestructuremap.FeeStructureId = feestructure.id)')]);

                DB::commit();
                return redirect()->back()->with('success', 'student has been created successfully.');
            } catch (\Exception $e) {
                DB::rollBack();
         
                return redirect()->back()->withInput()->withErrors(['error' => $e->getMessage()]);
            }
        }
    }


    /**
     * Display the specified resource.
     */
    public function show(Student $student)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Student $student)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Student $student)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Student $student)
    {
        //
    }
}
