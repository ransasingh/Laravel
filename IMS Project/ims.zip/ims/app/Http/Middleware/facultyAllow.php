<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class facultyAllow
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next)
    {
        // Check if the user is authenticated
        if (!auth()->check()) {
            return redirect()->route('login'); // Redirect unauthenticated users to login page
        }

        // Check if the authenticated user has the required role (Role ID 1 or 3)
        $userRole = auth()->user()->RoleId;
        if ($userRole != 1 && $userRole != 3) {
            abort(403); // Return forbidden error if user doesn't have required role
        }

        // If user has the required role, proceed with the request
        return $next($request);
    }
}
