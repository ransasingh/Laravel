<?php

namespace App\Http\Middleware;

use App\Models\Institute;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Facades\View;

class RetrieveInstituteLogoPath
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle($request, Closure $next)
    {
        // Retrieve the institute from the database (replace '1' with the actual ID or adjust the logic to retrieve it dynamically)
        $institute = Institute::find(1);
      
        $instituteLogoPath= $institute && $institute->InstituteLogo && file_exists(public_path('uploads/institute/' . $institute->InstituteLogo)) ? asset('uploads/institute/' . $institute->InstituteLogo) : url('assets/images/logo.jpg');
        // Share the institute logo path with all views
        View::share('instituteLogoPath', $instituteLogoPath);

        return $next($request);
    }
}
