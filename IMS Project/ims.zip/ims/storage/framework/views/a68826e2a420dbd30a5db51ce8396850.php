<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
    <meta http-equiv="Pragma" content="no-cache" />
    <meta http-equiv="Expires" content="0" />
    <link rel="shortcut icon" href="<?php echo e($instituteLogoPath); ?>" type="image/x-icon" />
    <title>IMS : <?php echo $__env->yieldContent('title'); ?></title>

    <!-- ========== All CSS files linkup ========= -->
    <link rel="stylesheet" href="<?php echo e(url('assets/css/bootstrap.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(url('assets/css/main.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(url('assets/css/font-awesome.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(url('assets/css/custome.login.css')); ?>" />



</head>

<body>
    <!-- ======== Preloader =========== -->
    <div id="preloader">
        <div class="spinner"></div>
    </div>
    <!-- ======== Preloader =========== -->


    <!-- ======== main-wrapper start =========== -->
    <main class="main-wrapper">


        <?php echo $__env->yieldContent('login'); ?>

    </main>
    <!-- ======== main-wrapper end =========== -->

    <!-- ========= All Javascript files linkup ======== -->
    <script src="<?php echo e(url('assets/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(url('assets/js/main.js')); ?>"></script>
    <script src="<?php echo e(url('assets/js/jquery-3.7.1.min.js')); ?>"></script>



    <?php echo $__env->yieldPushContent('script'); ?>
</body>

</html><?php /**PATH C:\xampp\htdocs\ims\resources\views/layout/admin_login_layout.blade.php ENDPATH**/ ?>