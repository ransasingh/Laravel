 <!-- ========== header start ========== -->
 <header class="header">
     <div class="container-fluid">
         <div class="row">
             <div class="col-lg-6 col-md-6 col-6">
                 <div class="header-left d-flex align-items-center">
                     <div class="menu-toggle-btn mr-15">
                         <button id="menu-toggle" class="main-btn light-btn rounded-full btn-hover">
                             <i class="lni lni-chevron-left me-2"></i>
                         </button>
                     </div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                     <?php if (! (Route::currentRouteNamed('student.add.public'))): ?>
                     <form id="changeBranchForm" action="<?php echo e(route('changeBranch')); ?>" method="post" class="row g-2 align-items-center">
                         <?php echo csrf_field(); ?>
                         <div class="col-auto">
                             <select class="form-select form-select-sm" style="display: none;" name="branch" id="branch" onchange="submitForm()">
                                 <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <?php
                                 $isLoggedIn = auth()->check();
                                 $hasRight = \DB::table('userbranchright')->where('UserId', auth()->id())->where('BranchId', $branch->id)->exists();
                                 $isSuperAdmin = auth()->user() && auth()->user()->RoleId == 1;
                                 ?>
                                 <option value="<?php echo e($branch->id); ?>" <?php if(session('BranchId')==$branch->id): ?> selected <?php endif; ?> <?php if(!$isSuperAdmin && !$hasRight): ?> disabled <?php endif; ?>><?php echo e($branch->Name); ?></option>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             </select>
                         </div>
                         <?php if($isLoggedIn && $isSuperAdmin): ?>
                         <div class="col-auto" style="display: none;">
                             <button type="submit" id="submitBtn" class="main-btn dark-btn rounded-full btn-hover  btn-xs">Change Branch</button>
                         </div>
                         <?php endif; ?>
                     </form>

                     <?php endif; ?>
                 </div>
             </div>
             <script>
                 <?php if (! (Route::currentRouteNamed('student.add.public'))): ?>

                 var isLoggedIn = "<?php echo e($isLoggedIn ? 'true' : 'false'); ?>";
                 var isAllowedToSeeBranchData = "<?php echo e($isSuperAdmin ? 'true' : 'false'); ?>"; // Super admin is always allowed to see branch data
                 var hasRight = "<?php echo e($hasRight ? 'true' : 'false'); ?>"; // Pass the PHP boolean directly to JavaScript

                 // Attach event listener to the "Change Branch" button to submit the form
                 document.getElementById('submitBtn').addEventListener('click', function(event) {
                     event.preventDefault(); // Prevent the default form submission
                     submitForm(); // Submit the form
                 });

                 // Automatically submit the form if allowed
                 if ((isLoggedIn === 'true' && isAllowedToSeeBranchData === 'true' && hasRight) || (isLoggedIn === 'true' && "<?php echo e(session('BranchId')); ?>" === '1')) {
                     // Check if the form has already been submitted
                     if (!sessionStorage.getItem('formSubmitted')) {
                         submitForm();
                     }
                 }

                 function submitForm() {
                     sessionStorage.setItem('formSubmitted', 'true'); // Store in sessionStorage to prevent repeated submissions
                     document.getElementById('changeBranchForm').submit();
                 }
                 <?php endif; ?>
             </script>



             <div class="col-lg-6 col-md-6 col-6">
                 <div class="header-right">
                     <!-- profile start -->
                     <div class="profile-box ml-15">
                         <button class="dropdown-toggle bg-transparent border-0" type="button" id="profile" data-bs-toggle="dropdown" aria-expanded="false">
                             <div class="profile-info">
                                 <div class="info">
                                     <div class="image">
                                         <img src="<?php echo e($userimage); ?>" alt="Profile Image">
                                     </div>
                                     <div>
                                         <?php if(auth()->guard()->check()): ?>
                                         <?php
                                         $userRoleId = auth()->user()->RoleId;
                                         $changepasswordRoute = ($userRoleId == 3) ? route('faculty.changepassword') : (($userRoleId == 4) ? route('student.changepassword') : route('superadmin.changepassword'));
                                         $role = DB::table('userrole')->find($userRoleId);
                                         $roleName = $role ? $role->RoleName : '';
                                         ?>
                                         <h6 class="fw-500"><?php echo e(auth()->user()->name); ?></h6>
                                         <p><?php echo e($roleName); ?></p>
                                         <?php endif; ?>
                                     </div>
                                 </div>
                             </div>
                         </button>
                         <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="profile">

                             <!-- <li>
                                 <a href="#0">
                                     <i class="lni lni-user"></i> View Profile
                                 </a>
                             </li>-->
                             <li>
                                 <a href="<?php echo e($changepasswordRoute); ?>"> <i class="lni lni-key"></i> Change Password </a>
                             </li>
                             <li class="divider"></li>
                             <li>
                                 <a href="<?php echo e(route('adminlogout')); ?>"  class="logout-link"> <i class="lni lni-exit"></i> Sign Out </a>
                             </li>
                         </ul>
                     </div>
                     <!-- profile end -->
                 </div>
             </div>
         </div>
     </div>
 </header>
 <!-- ========== header end ========== --><?php /**PATH C:\xampp\htdocs\ims\resources\views/layout/admin_header.blade.php ENDPATH**/ ?>