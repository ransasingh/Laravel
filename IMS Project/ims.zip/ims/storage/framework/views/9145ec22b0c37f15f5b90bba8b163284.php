
<?php $__env->startSection('title', 'Login'); ?>
<?php $__env->startSection('login'); ?>
<div class="loginbox"><img src="<?php echo e($instituteLogoPath); ?>" alt="Institute Logo" class="avatar">
    <h1>Sign In </h1>
    <?php if($errors->any()): ?>
    <div class="alert alert-danger alert-dismissible mt-20 fade show alert-sm" role="alert">
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
    <div class="alert alert-danger alert-dismissible mt-20 fade show alert-sm" role="alert">
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        <?php echo e(session('error')); ?>

    </div>
    <?php endif; ?>

    <?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible mt-20 fade show alert-sm" role="alert">
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        <?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>

    <form method="post" action="<?php echo e(route('user.admin')); ?>">
        <?php echo csrf_field(); ?>
        <label class="login" for="email">Username</label>
        <input type="text" name="email" id="email" placeholder="Enter Username" value="<?php echo e(old('email')); ?>" autofocus>
        <label class="login" for="password">Password</label><span toggle="#password" class="eye-icon toggle-password"></span>
        <input type="password" name="password" id="password" placeholder="Enter Password" autofocus>  
      

        <label for="remember">Remember Me <span><input type="checkbox" name="remember" id="remember"></span></label>


        <input type="submit" value="Login">
        <a href="#">Forgot password?</a><br>
    </form>
</div>

<?php $__env->startPush('script'); ?>
<script>
    $(document).ready(function() {
        setTimeout(function() {
            $(".alert").alert("close");
        }, 5000);
    });
    document.addEventListener("DOMContentLoaded", function() {
        var passwordInput = document.getElementById("password");
        var eyeIcon = document.querySelector(".eye-icon");

        eyeIcon.addEventListener("click", function() {
            eyeIcon.classList.toggle("visible");

            if (passwordInput.type === "password") {
                passwordInput.type = "text";
            } else {
                passwordInput.type = "password";
            }
        });

        // Check if password field is visible and adjust eye icon
        if (passwordInput.type === "text") {
            eyeIcon.classList.add("visible");
        }
    });
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin_login_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ims\resources\views/backend/login/login.blade.php ENDPATH**/ ?>