
<?php $__env->startSection('title', 'Institute Branch Listing'); ?>
<?php $__env->startSection('dashboard'); ?>

<!-- ========== table components start ========== -->
<section class="table-components">
    <div class="container-fluid">

    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            <?php echo e(session('error')); ?>

        </div>
        <?php endif; ?>

        <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            <?php echo e(session('success')); ?>

        </div>
        <?php endif; ?>

        <!-- ========== title-wrapper start ========== -->
        <div class="title-wrapper pt-30">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <div class="title">
                        <h2>Institute Branch Listing</h2>
                    </div>
                </div>
                <!-- <div class="col-md-6">
                    <div class="breadcrumb-wrapper">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a href="" class="main-btn active-btn-light rounded-full btn-hover btn-sm">
                                        <i class="lni lni-plus"></i>
                                        Add Institute Branch
                                    </a>
                                </li>
                            </ol>
                        </nav>
                    </div>
                </div> -->

            </div>
            <!-- end row -->
        </div>
        <!-- ========== title-wrapper end ========== -->

        <!-- ========== tables-wrapper start ========== -->
        <div class="tables-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card-style mb-30">
                        <!-- <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                            <a href="" class="main-btn danger-btn-light rounded-full btn-hover btn-sm mb-2">Show Trash</a>
                        </div> -->
                        <div class="table-wrapper table-responsive">
                            <table class="table" id="data-table">
                                <thead>
                                <tr class="text-sm">
                                        <th class="text-uppercase">#</th>
                                        <th class="text-uppercase">Name</th>
                                        <th class="text-uppercase">Branch Code </th>
                                        <th class="text-uppercase">Institute </th>
                                        <th class="text-uppercase">Mobile Number</th>
                                        <th class="text-uppercase">EmailId</th>
                                        <th class="text-uppercase">Status</th>
                                        <th class="text-uppercase print-hidden">Action</th>
                                    </tr>
                                    <!-- end table row-->
                                </thead>
                                <tbody>
                                    <?php if(isset($data)): ?>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row" class="text-sm"><?php echo e($loop->index + 1); ?></th>
                                        <td class="min-width text-sm"><?php echo e($record->Name); ?></td>
                                        <td class="min-width text-sm"><?php echo e($record->BranchCode); ?></td>
                                        <td class="min-width text-sm"><?php echo e($record->institute_name); ?></td>
                                        <td class="min-width text-sm"><?php echo e($record->MobileNumber); ?></td>
                                        <td class="min-width text-sm"><?php echo e($record->EmailId); ?></td>
                                        <td class="min-width text-sm">
                                            <?php if($record->IsActive == 1): ?>
                                            <span class="status-btn active-btn" title="Active">Active</span>
                                            <?php else: ?>
                                            <span class="status-btn close-btn" title="Inactive">Inactive</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <div class="action">
                                                <a href="<?php echo e(route('institutebranch.edit',['id'=>$record->id ])); ?>" class="text-primary" title="Edit"><i class="lni lni-pencil-alt"></i></a>
                                                <!-- <a href="" class="text-danger" onclick="return confirm('Are you sure?')" title="Trash"><i class="lni lni-trash-can"></i></a> -->
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                            <!-- end table -->
                        </div>
                    </div>
                    <!-- end card -->
                </div>
                <!-- end col -->
            </div>
            <!-- end row -->
        </div>
        <!-- ========== tables-wrapper end ========== -->
    </div>
    <!-- end container -->
</section>
<!-- ========== table components end ========== -->



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ims\resources\views/backend/institutebranch/list.blade.php ENDPATH**/ ?>