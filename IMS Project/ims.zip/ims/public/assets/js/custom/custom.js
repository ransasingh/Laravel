function previewImage(inputId, previewId) {
    var input = document.getElementById(inputId);
    var preview = document.getElementById(previewId);

    // Check if a file is selected
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        // Set up the FileReader to read the file
        reader.onload = function (e) {
            // Check if the file is an image (you may want to enhance this check)
            if (/^image/.test(input.files[0].type)) {
                preview.src = e.target.result;
                preview.style.display = "block"; // Show the preview
            } else {
                preview.style.display = "none"; // Show the preview
            }
        };

        // Read the file as a data URL
        reader.readAsDataURL(input.files[0]);
    }
}

document.addEventListener("DOMContentLoaded", function () {
    var passwordInput = document.getElementById("password");
    var eyeIcon = document.querySelector(".eye-icon");

    eyeIcon.addEventListener("click", function () {
        eyeIcon.classList.toggle("visible");

        if (passwordInput.type === "password") {
            passwordInput.type = "text";
        } else {
            passwordInput.type = "password";
        }
    });

    // Check if password field is visible and adjust eye icon
    if (passwordInput.type === "text") {
        eyeIcon.classList.add("visible");
    }
});

function calculateAndAddRows() {
    // Get values from input fields
    var remainingAmount = parseFloat(
        document.getElementById("RemainingAmount").value
    );

    var noOfEmi = parseInt(document.getElementById("NoOfEmi").value);
    var fromDate = document.getElementById("FromDate").value;

    // Check if values are valid for calculation
    if (isNaN(remainingAmount) || isNaN(noOfEmi) || fromDate === "") {
        // alert("Please enter valid values for calculation.");
        displayMessage("Please enter valid values for Emi Creation.", "red");
    } else {
        // Perform calculation and add rows
        addRows(remainingAmount, noOfEmi, fromDate);
        // alert("Calculation successful. Rows added.");
        displayMessage("Emi Create Successfully.", "green");
    }
}

function addRows(remainingAmount, noOfEmi, fromDate) {
    var tableBody = document.getElementById("emiTableBody");

    // Convert fromDate to Date object
    var startDate = new Date(fromDate);

    // Loop to add rows
    for (var i = 0; i < noOfEmi; i++) {
        // Calculate due date as the last day of the month
        var dueDate = new Date(
            startDate.getFullYear(),
            startDate.getMonth() + i + 1,
            0
        );

        // Format due date as YYYY-MM-DD
        var formattedDueDate = dueDate.toISOString().split("T")[0];

        // Calculate installment amount for each row
        var installmentAmountForRow = remainingAmount / noOfEmi;

        addRow(installmentAmountForRow.toString(), formattedDueDate, false);
    }
}

function addRow(installmentAmount, dueDate, isPaid) {
    var tableBody = document.getElementById("emiTableBody");

    var newRow = tableBody.insertRow();
    var cell1 = newRow.insertCell(0);
    var cell2 = newRow.insertCell(1);
    var cell3 = newRow.insertCell(2);
    var cell4 = newRow.insertCell(3);

    var input1 = document.createElement("input");
    input1.type = "text";
    input1.value = (
        installmentAmount !== undefined ? parseFloat(installmentAmount) : 0
    ).toFixed(2);
    input1.classList.add("form-control", "input-space");
    input1.addEventListener("input", function () {
        updateTotal();
    });
    cell1.appendChild(input1);

    var input2 = document.createElement("input");
    input2.type = "date";
    input2.value = dueDate !== undefined ? dueDate : getCurrentDate();
    input2.classList.add("form-control", "input-space");
    cell2.appendChild(input2);

    var input3 = document.createElement("input");
    input3.type = "text";
    input3.value = isPaid ? "Yes" : "No";
    input3.classList.add("form-control", "input-space");

    // Enable or disable the input field based on some condition
    var shouldDisable = true; // Set to true or false based on your condition
    input3.disabled = shouldDisable;

    cell3.appendChild(input3);

    var deleteButton = document.createElement("button");
    deleteButton.classList.add("text-danger");
    deleteButton.title = "Delete";

    var deleteIcon = document.createElement("i");
    deleteIcon.classList.add("lni", "lni-trash-can");
    deleteButton.appendChild(deleteIcon);

    deleteButton.onclick = function (event) {
        // Check if the clicked element is the delete icon
        if (event.target.classList.contains("lni-trash-can")) {
            if (confirm("Are you sure?")) {
                deleteRow(this);
                updateTotal(); // Update total after deleting a row
            }
            return false;
        }
    };

    cell4.appendChild(deleteButton);

    // Update total after adding a row
    updateTotal();
}

function updateTotal() {
    var sum = 0;
    var table = document.getElementById("installmentTable");
    var rows = table.querySelectorAll("tbody tr");

    rows.forEach(function (row) {
        var amountCell = row.cells[0];
        var amountValue =
            parseFloat(amountCell.querySelector("input").value) || 0;
        sum += amountValue;
    });

    var roundedSum = sum.toFixed(2);

    document.getElementById("SumOfFee").textContent = roundedSum;
}

function deleteRow(button) {
    var row = button.parentNode.parentNode;
    row.parentNode.removeChild(row);
}

function getCurrentDate() {
    var today = new Date();
    var dd = String(today.getDate()).padStart(2, "0");
    var mm = String(today.getMonth() + 1).padStart(2, "0"); // January is 0!
    var yyyy = today.getFullYear();
    return yyyy + "-" + mm + "-" + dd;
}

// Rest of your code...

function displayMessage(message, color) {
    var messageContainer = document.getElementById("messageContainer");

    // Set message and style
    messageContainer.innerHTML = message;
    messageContainer.style.color = color;

    // Auto-hide after 5 seconds
    setTimeout(function () {
        messageContainer.innerHTML = "";
    }, 5000);
}




$(document).ready(function () {
    $("#copyCheckbox, #StateId1, #PrStateId1").on("change", function () {
        if ($("#copyCheckbox").prop("checked")) {
            // Copy values from Address fields to Permanent Address fields
            $("#PrAddressLine1").val($("#AddressLine1").val());
            $("#PrAddressLine2").val($("#AddressLine2").val());
            $("#PrStateId").val($("#StateId").val()).change(); // Trigger change event for select dropdown
            $("#PrCityName").val($("#CityName").val());
            $("#PrPostalCode").val($("#PostalCode").val());
        } else {
            // Optionally clear Permanent Address fields when checkbox is unchecked
            $("#PrAddressLine1").val("");
            $("#PrAddressLine2").val("");
            $("#PrStateId").val("").change(); // Trigger change event for select dropdown
            $("#PrCityName").val("");
            $("#PrPostalCode").val("");
        }
    
        // If StateId checkbox is checked, enable corresponding Permanent StateId checkbox
        if ($("#StateId1").prop("checked")) {
            $("#PrStateId1").prop("checked", true);
        } else {
            $("#PrStateId1").prop("checked", false);
        }
    });
    
    // Initial check on page load
    if ($("#PossibilityForUpgradation").is(":checked")) {
        $("#descriptionField").show();
    } else {
        $("#descriptionField").hide();
    }

    // Bind change event to the checkbox
    $("#PossibilityForUpgradation").change(function () {
        // Toggle the visibility of the description field
        if (this.checked) {
            $("#descriptionField").show();
        } else {
            $("#descriptionField").hide();
        }
    });

    $(".fee-input").on("input", function () {
        updateTotal();
    });

    // Function to update the total sum
    function updateTotal() {
        let total = 0;

        // Loop through each fee input and add its value to the total
        $(".fee-input").each(function () {
            total += parseFloat($(this).val()) || 0;
        });

        // Update the total in the HTML
        $("#SumOfFee").text(total.toFixed(2));
    }


    $('#FromDate').change(function () {
        var fromDate = new Date($(this).val());
        var toDate = new Date(fromDate.setMonth(fromDate.getMonth() + 6));
        var toDateFormatted = toDate.toISOString().split('T')[0];
        $('#ToDate').val(toDateFormatted);
    });
});
