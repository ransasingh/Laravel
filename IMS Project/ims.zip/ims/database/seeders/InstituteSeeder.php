<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Institute;

class InstituteSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Institute::create([
            'name' => 'test',
            'MobileNumber' => '0000000000',
            'EmailId' => 'test@gmail.com',
            'AddressLine1' => 'test',
            'StateId' => '1',
            'CityName' => 'ahmedabad',
            'PostalCode' => '380000',
            'IsActive' => '1',
        ]);
    }
}
