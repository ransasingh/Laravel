<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('userrole', function (Blueprint $table) {
            $table->id()->comment('RoleId');
            $table->string('RoleName', 50)->unique();
            $table->string('Code', 50)->unique();
            $table->tinyInteger('CanCreate')->default(0)->nullable();
            $table->tinyInteger('CanUpdate')->default(0)->nullable();
            $table->tinyInteger('CanDelete')->default(0)->nullable();
            $table->tinyInteger('CanView')->default(0)->nullable();
            $table->tinyInteger('IsActive')->default(1);
            $table->integer('createdBy')->nullable();
            $table->integer('updatedBy')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('userrole');
    }
};
