<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('studentcourse', function (Blueprint $table) {
            $table->id()->comment('StudentCourseId');
            $table->bigInteger('SubjectId')->nullable();
            $table->bigInteger('AcademicYearId')->nullable();
            $table->tinyInteger('IsExraSubject')->default(0)->nullable();
            $table->tinyInteger('IsActive')->default(1);
            $table->integer('createdBy')->nullable();
            $table->integer('updatedBy')->nullable();
            $table->timestamps();
            $table->softDeletes();
            $table->bigInteger('StudentId')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('studentcourse');
    }
};
