<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('notificationrole', function (Blueprint $table) {
            $table->id()->comment('NotificationRoleId');
            $table->bigInteger('RoleId');
            $table->bigInteger('NotificationId');
            $table->timestamps();
            // Define the composite primary key
            $table->unique(['RoleId', 'NotificationId']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('notificationrole');
    }
};
