<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('coursesubject', function (Blueprint $table) {
            $table->id()->comment('CourseSubjectId');
            $table->bigInteger('SubjectId');
            $table->bigInteger('CourseId');
            $table->tinyInteger('IsActive')->default(1);
            $table->integer('createdBy')->nullable();
            $table->integer('updatedBy')->nullable();
            $table->timestamps();
            $table->softDeletes();
            // Define the composite primary key
            $table->unique(['SubjectId', 'CourseId']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('coursesubject');
    }
};
