<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('studentfeeemi', function (Blueprint $table) {
            $table->id()->comment('EmiId');
            $table->decimal('InstallmentAmount', 10, 0);
            $table->date('InstallmentDueDate');
            $table->bigInteger('FeeStructureId');
            $table->bigInteger('StudentId');
            $table->tinyInteger('IsActive')->default(1)->nullable();
            $table->integer('createdBy')->nullable();
            $table->integer('updatedBy')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('studentfeeemi');
    }
};
