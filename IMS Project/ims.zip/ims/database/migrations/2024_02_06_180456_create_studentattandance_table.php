<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('studentattandance', function (Blueprint $table) {
            $table->id()->comment('AttandanceId');
            $table->bigInteger('BatchDetailId');
            $table->date('ForDate');
            $table->bigInteger('StudentId');
            $table->tinyInteger('IsActive')->default(1)->nullable();
            $table->integer('createdBy')->nullable();
            $table->integer('updatedBy')->nullable();
            $table->timestamps();
            $table->tinyInteger('DayAttandance')->default(0)->nullable();
            $table->tinyInteger('IsOnline')->default(0)->nullable();
            $table->dateTime('StartTime')->nullable();
            $table->dateTime('EndTime')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('studentattandance');
    }
};
