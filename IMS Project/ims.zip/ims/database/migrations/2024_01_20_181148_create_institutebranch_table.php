<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('institutebranch', function (Blueprint $table) {
            $table->id()->comment('BranchId');
            $table->string('Name', 255);
            $table->string('BranchCode', 255)->unique();
            $table->bigInteger('InstituteId');
            $table->string('MobileNumber', 15);
            $table->string('EmailId', 50);
            $table->string('Website', 255)->nullable();
            $table->text('AddressLine1');
            $table->text('AddressLine2')->nullable();
            $table->string('StateId');
            $table->string('CityName', 50);
            $table->string('PostalCode', 10);
            $table->tinyInteger('IsActive')->default(1);
            $table->integer('createdBy')->nullable();
            $table->integer('updatedBy')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('institutebranch');
    }
};
