<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('batchextension', function (Blueprint $table) {
            $table->id()->comment('ExtensionId');
            $table->bigInteger('BatchId');
            $table->date('NewDate');
            $table->text('Remarks')->nullable();
            $table->bigInteger('IsApproved')->default(0)->nullable();
            $table->bigInteger('VerifyBy')->nullable();
            $table->dateTime('VerifyAt')->nullable();
            $table->tinyInteger('IsActive')->default(1)->nullable();
            $table->integer('createdBy')->nullable();
            $table->integer('updatedBy')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('batchextension');
    }
};
