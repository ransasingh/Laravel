<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('portfoliosubmission', function (Blueprint $table) {
            $table->id()->comment('PortfolioID');
            $table->string('PortfolioFile');
            $table->bigInteger('StudentId');
            $table->bigInteger('FacultyId');
            $table->bigInteger('SubjectId');
            $table->integer('createdBy')->nullable();
            $table->integer('updatedBy')->nullable();
            $table->timestamps();
            $table->dateTime('ApprovedAt')->nullable();
            $table->bigInteger('ApprovedBy')->nullable();
            $table->bigInteger('IsApproved')->default(0)->nullable();
            $table->date('SubmissionDate')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('portfoliosubmission');
    }
};
