<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('student', function (Blueprint $table) {
            $table->id()->comment('StudentId');
            $table->string('FirstName');
            $table->string('LastName');
            $table->string('MobileNumber', 15);
            $table->string('EmailId');
            $table->text('AddressLine1');
            $table->text('AddressLine2')->nullable();
            $table->string('StateId');
            $table->string('CityName', 50);
            $table->string('PostalCode', 10)->nullable();
            $table->string('StudentCode', 50)->unique()->nullable();
            $table->string('ProfileImage')->nullable();
            $table->string('SignImage')->nullable();
            $table->bigInteger('InstituteId')->nullable();
            $table->bigInteger('UserId')->nullable();
            $table->tinyInteger('IsActive')->default(1)->nullable();
            $table->integer('createdBy')->nullable();
            $table->integer('updatedBy')->nullable();
            $table->timestamps();
            $table->bigInteger('IsFullPaid')->nullable();
            $table->string('ParentMobile', 15);
            $table->text('PrAddressLine1');
            $table->text('PrAddressLine2')->nullable();
            $table->string('PrStateId');
            $table->string('PrCityName', 50);
            $table->bigInteger('PossibilityForUpgradation')->nullable()->default(0);
            $table->string('EmergencyContactNumber', 15);
            $table->string('Description')->nullable();
            $table->string('BloodGroup');
            $table->string('LastEducationQualification')->nullable();
            $table->string('ModeOfCoaching');
            $table->date('DOB');
            $table->date('AdmissionDate');
            $table->bigInteger('CourseId');
            $table->string('BatchPriority')->nullable();
            $table->string('BatchFromMnt')->nullable();
            $table->string('BatchToMnt')->nullable();
            $table->bigInteger('FacultyId')->nullable();
            $table->bigInteger('ShowFee')->nullable()->default(0);
            $table->bigInteger('BranchId')->nullable();
            $table->decimal('TotalFeeAmount', 10, 0)->nullable();
            $table->tinyInteger('Status')->default(1)->nullable();
            $table->tinyInteger('HighlightedStudentId')->default(0)->nullable();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('student');
    }
};
