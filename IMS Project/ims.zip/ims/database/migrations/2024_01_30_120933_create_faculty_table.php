<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('faculty', function (Blueprint $table) {
            $table->id()->comment('FacultyId');
            $table->string('FirstName', 255);
            $table->string('LastName', 255);
            $table->string('MobileNumber', 15);
            $table->string('EmailId', 50);
            $table->text('AddressLine1');
            $table->text('AddressLine2')->nullable();           
            $table->string('StateId');
            $table->string('CityName', 50);
            $table->string('PostalCode', 10);
            $table->string('EmployeeCode', 50)->unique()->nullable();           
            $table->tinyInteger('IsActive')->default(1);
            $table->string('ProfileImage')->nullable();
            $table->string('SignImage')->nullable();
            $table->text('PrAddressLine1');
            $table->text('PrAddressLine2')->nullable();
            $table->string('PrStateId');
            $table->string('PrCityName', 50);
            $table->string('EmergencyContactNumber', 15);
            $table->string('BloodGroup');
            $table->bigInteger('InstituteId')->nullable();
            $table->bigInteger('UserId')->nullable();
            $table->bigInteger('BranchId')->nullable();
            $table->string('BatchPriority')->nullable();
            $table->integer('createdBy')->nullable();
            $table->integer('updatedBy')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('faculty');
    }
};
