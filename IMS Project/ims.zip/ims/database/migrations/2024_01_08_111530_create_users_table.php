<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('sysuser', function (Blueprint $table) {
            $table->id()->comment('UserId');
            $table->string('name');
            $table->string('email')->unique()->comment('LoginId');
            $table->timestamp('email_verified_at')->nullable();
            $table->string('password')->comment('UserPassword');
            $table->tinyInteger('IsActive')->default(1);
            $table->integer('RoleId');
            $table->integer('InstituteId');
            $table->rememberToken();
            $table->integer('createdBy')->nullable();
            $table->integer('updatedBy')->nullable();
            $table->timestamps();
            $table->tinyInteger('IsPolicyAgreed')->default(0);
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('users');
    }
};
