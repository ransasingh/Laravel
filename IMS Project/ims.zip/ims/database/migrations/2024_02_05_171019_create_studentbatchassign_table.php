<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('studentbatchassign', function (Blueprint $table) {
            $table->id()->comment('BatchAssingId');
            $table->bigInteger('BatchDetailId');
            $table->bigInteger('StudentId');
            $table->tinyInteger('IsActive')->default(1)->nullable();
            $table->integer('createdBy')->nullable();
            $table->integer('updatedBy')->nullable();
            $table->timestamps();
            $table->softDeletes();
            $table->bigInteger('IsCompleted')->default(0)->nullable();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('studentbatchassign');
    }
};
