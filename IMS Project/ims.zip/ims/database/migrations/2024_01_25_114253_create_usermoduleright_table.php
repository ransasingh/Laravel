<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('usermoduleright', function (Blueprint $table) {
            $table->id()->comment('UserModualRightId');
            $table->bigInteger('UserId');
            $table->bigInteger('ModuleId');
            $table->timestamps();
            // Define the composite primary key
            $table->unique(['UserId', 'ModuleId']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('usermoduleright');
    }
};
