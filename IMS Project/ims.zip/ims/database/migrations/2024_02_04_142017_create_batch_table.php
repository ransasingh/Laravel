<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('batch', function (Blueprint $table) {
            $table->id()->comment('BatchId');
            $table->bigInteger('FacultyId');
            $table->string('StartTimeInMinutes');
            $table->string('EndTimeInMinutes');
            $table->date('FromDate');
            $table->date('ToDate');
            $table->bigInteger('StudentCapacity');
            $table->string('Name');
            $table->bigInteger('IsCompleted')->default(0)->nullable();
            $table->tinyInteger('IsActive')->default(1)->nullable();
            $table->integer('createdBy')->nullable();
            $table->integer('updatedBy')->nullable();
            $table->timestamps();
            $table->bigInteger('IsApproved')->default(0)->nullable();
            $table->bigInteger('VerifyBy')->nullable();
            $table->dateTime('VerifyAt')->nullable();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('batch');
    }
};
