<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('feereceipt', function (Blueprint $table) {
            $table->id()->comment('FeeReceiptId');
            $table->bigInteger('StudentId');
            $table->bigInteger('FeeStructureId');
            $table->bigInteger('ReceiptSrNo')->nullable();
            $table->string('ReceiptNo')->nullable();
            $table->bigInteger('FinancialYearId');
            $table->date('ReceiptDate');
            $table->tinyInteger('IsActive')->default(1)->nullable();
            $table->integer('createdBy')->nullable();
            $table->integer('updatedBy')->nullable();
            $table->timestamps();
            $table->softDeletes();
            $table->string('FilePath',500)->nullable();
            $table->string('PaymentMode');
            $table->string('ChequeNoOrUtr')->nullable();
            $table->date('ChequeDate')->nullable();
            $table->bigInteger('BankId')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('feereceipt');
    }
};
