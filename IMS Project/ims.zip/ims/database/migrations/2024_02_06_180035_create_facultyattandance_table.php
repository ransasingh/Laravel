<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('facultyattandance', function (Blueprint $table) {
            $table->id()->comment('AttendanceId');
            $table->dateTime('StartTime');
            $table->dateTime('EndTime')->nullable();
            $table->bigInteger('BatchDetailId');
            $table->date('ForDate');
            $table->tinyInteger('IsActive')->default(1)->nullable();
            $table->integer('createdBy')->nullable();
            $table->integer('updatedBy')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('facultyattandance');
    }
};
