@extends('layout.admin_layout')
@section('title', 'Batch Extension Report')
@section('dashboard')
<!-- ========== section start ========== -->
<section class="section">
    <div class="container-fluid">

        @if(session('error'))
        <div class="alert alert-danger alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('error') }}
        </div>
        @endif

        @if(session('success'))
        <div class="alert alert-success alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('success') }}
        </div>
        @endif

        <!-- ========== title-wrapper start ========== -->
        <div class="title-wrapper pt-30">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <div class="title">
                        <h2>Batch Extension Report</h2>
                    </div>
                </div>
            </div>
            <!-- end row -->
        </div>

        <div class="col-md-12">
            <div class="signup-wrapper">
                <div class="form-wrapper">
                    <form id="BatchExtensionReportform" method="post">
                        @csrf
                        <div class="row">
                            <div class="col-md-6 col-xs-12">
                                <div class="select-style-1">
                                    <label for="FacultyId">Faculty</label>
                                    <div class="select-position">
                                        <select name="FacultyId" id="FacultyId">
                                            <option selected>Select Faculty</option>
                                            @if (isset($faculties))
                                            @foreach ($faculties as $faculty)
                                            <option value="{{$faculty->id}}" {{old('FacultyId') == $faculty->id ? 'selected' : '' }}>{{$faculty->FirstName ." ".$faculty->LastName}}</option>
                                            @endforeach
                                            @endif
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-xs-12">
                                <div class="select-style-1">
                                    <label for="BatchId">Batch</label>
                                    <div class="select-position">
                                        <select name="BatchId" id="BatchId">
                                            <option selected>Select Batch</option>
                                            @if (isset($batches))
                                            @foreach ($batches as $batch)
                                            <option value="{{$batch->id}}" {{old('BatchId') == $batch->id ? 'selected' : '' }}>{{$batch->Name}}</option>
                                            @endforeach
                                            @endif
                                        </select>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class="row">
                            <div class="col-md-6 col-xs-12">
                                <div class="select-style-1">
                                    <label for="Status" class="compulsory">All/Approved/Rejected</label>
                                    <div class="select-position">
                                        <select name="Status" id="Status">
                                            <option value="All" {{old('Status') == 'All' ? 'selected' : ''}}>All</option>
                                            <option value="Approved" {{old('Status') == 'Approved' ? 'selected' : ''}}>Approved Only</option>
                                            <option value="Rejected" {{old('Status') == 'Rejected' ? 'selected' : ''}}>Rejected Only</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- end col -->
                        <div class="row">
                            <div class="col-12 mt-10">
                                <button class="main-btn dark-btn rounded-full btn-hover btn-sm">
                                    Submit
                                </button>
                            </div>
                        </div>
                        <!-- end row -->
                    </form>

                </div>
            </div>
        </div>
        <span class="divider">
            <hr />
        </span>
        <div class="tables-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card-style mb-30">
                        <div id="responseMessage"></div>
                        <h4 class="mb-10">Batch Extension Report</h4>
                        <div class="table-wrapper table-responsive">
                            <table class="table" id="BatchExtensionReporttable">
                                <thead>
                                    <tr class="text-sm">
                                        <th class="text-uppercase">Batch</th>
                                        <th class="text-uppercase">Faculty</th>
                                        <th class="text-uppercase">Batch Start Date</th>
                                        <th class="text-uppercase">Batch End Date</th>
                                        <th class="text-uppercase">Request Date</th>
                                        <th class="text-uppercase">Remarks</th>
                                        <th class="text-uppercase">Is Approved</th>
                                        <th class="text-uppercase">Approved At</th>
                                        <th class="text-uppercase">Approved By</th>
                                    </tr>
                                </thead>

                                <tbody class="text-center">

                                </tbody>

                            </table>
                            <!-- end table -->
                        </div>
                    </div>
                    <!-- end card -->
                </div>
                <!-- end col -->
            </div>
            <!-- end row -->
        </div>
    </div>
    <!-- end container -->
</section>
<!-- ========== section end ========== -->
@push('script')
<script>
    $(document).ready(function() {
        var isDataTableInitialized = false; // Initialize the flag
        var dataTableOptions = { // DataTable options with buttons
            dom: 'Bfrtip',
            buttons: [
                'csv', 'pdf', 'print'
            ]
        };

        $('#BatchExtensionReportform').submit(function(e) {
            e.preventDefault();
            var formData = $(this).serialize();
            $.ajax({
                type: 'POST',
                url: '{{ route("BatchExtensionReport") }}',
                data: formData,
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        $('#responseMessage').html('<div class="alert alert-info alert-dismissible fade show">Data loaded successfully!</div>');
                        if (isDataTableInitialized) {
                            $('#BatchExtensionReporttable').DataTable().clear().destroy(); // Destroy existing DataTable
                            displayData(response.data);
                            $('#BatchExtensionReporttable').DataTable(dataTableOptions); // Reinitialize DataTable with buttons
                        } else {
                            displayData(response.data);
                            $('#BatchExtensionReporttable').DataTable(dataTableOptions); // Initialize DataTable with buttons
                            isDataTableInitialized = true; // Set the flag to true after initialization
                        }
                    } else {
                        $('#responseMessage').html('<div class="alert alert-danger alert-dismissible fade show">Error: ' + response.message + '</div>');
                        if (isDataTableInitialized) {
                            $('#BatchExtensionReporttable').DataTable().clear().destroy(); // Destroy existing DataTable
                        }
                    }
                },
                error: function(xhr, status, error) {
                    $('#responseMessage').html('<div class="alert alert-danger alert-dismissible fade show">Error: ' + error + '</div>');
                }
            });
        });

        function displayData(data) {
            $('#BatchExtensionReporttable tbody').empty();
            data.forEach(function(item) {
                var approvedBy = item.approved_by ? item.approved_by : "Not Approved";

                function formatTime(dateString) {
                    var date = new Date(dateString);
                    var hours = date.getHours().toString().padStart(2, '0');
                    var minutes = date.getMinutes().toString().padStart(2, '0');
                    var seconds = date.getSeconds().toString().padStart(2, '0');
                    return hours + ":" + minutes + ":" + seconds;
                }

                // Format the date
                function formatDate(dateString) {
                    var date = new Date(dateString);
                    var day = date.getDate();
                    var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                    var monthIndex = date.getMonth();
                    var year = date.getFullYear() % 100;
                    return day + "-" + monthNames[monthIndex] + "-" + year;
                }

                var formattedBatchStartDate = formatDate(item.batch_start_date);
                var formattedBatchStartDate = formatDate(item.batch_end_date);
                var formattedBatchrequest_date = formatDate(item.request_date);
                var formattedapproved_at = formatDate(item.approved_at) + " " + formatTime(item.approved_at);


                var row = '<tr>' +
                    '<td>' + item.batch_name + '</td>' +
                    '<td>' + item.faculty_name + '</td>' +
                    '<td>' + formattedBatchStartDate + '</td>' +
                    '<td>' + formattedBatchStartDate + '</td>' +
                    '<td>' + formattedBatchrequest_date + '</td>' +
                    '<td>' + item.Remarks + '</td>' +
                    '<td>' + (item.IsApproved ? "Yes" : "No") + '</td>' +
                    '<td>' + (formattedapproved_at ? formattedapproved_at : "Not Approved") + '</td>' +
                    '<td>' + approvedBy + '</td>' +
                    '</tr>';
                $('#BatchExtensionReporttable tbody').append(row);
            });
        }
    });
</script>


@endpush

@endsection