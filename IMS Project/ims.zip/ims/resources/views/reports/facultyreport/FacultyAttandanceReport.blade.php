@extends('layout.admin_layout')
@section('title', 'Faculty Batch Attandance')
@section('dashboard')
<!-- ========== section start ========== -->
<section class="section">
    <div class="container-fluid">

        @if(session('error'))
        <div class="alert alert-danger alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('error') }}
        </div>
        @endif

        @if(session('success'))
        <div class="alert alert-success alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('success') }}
        </div>
        @endif

        <!-- ========== title-wrapper start ========== -->
        <div class="title-wrapper pt-30">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <div class="title">
                        <h2>Faculty Batch Attandance</h2>
                    </div>
                </div>

            </div>
            <!-- end row -->
        </div>

        <div class="col-md-12">
            <div class="signup-wrapper">
                <div class="form-wrapper">
                    <form id="FacultyBatchAttandanceform" method="post">
                        @csrf
                        <div class="row">
                            <div class="col-md-6 col-xs-12">
                                <div class="input-style-1">
                                    <label for="StartTime" class="compulsory">From Date</label>
                                    <input type="date" name="StartTime" id="StartTime" value="{{ date('Y-m-d') }}" />
                                    @error('StartTime')
                                    <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-6 col-xs-12">
                                <div class="input-style-1">
                                    <label for="EndTime" class="compulsory">To Date</label>
                                    <input type="date" name="EndTime" id="EndTime" value="{{ date('Y-m-d') }}" />
                                    @error('EndTime')
                                    <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                        </div>

                        <!-- end col -->
                        <div class="row">
                            <div class="col-12 mt-10">
                                <button class="main-btn dark-btn rounded-full btn-hover btn-sm">
                                    Submit
                                </button>
                            </div>
                        </div>
                        <!-- end row -->
                    </form>

                </div>
            </div>
        </div>
        <span class="divider">
            <hr />
        </span>
        <div class="tables-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card-style mb-30">
                        <div id="responseMessage"></div>
                        <h4 class="mb-10">Faculty Batch Attandance</h4>
                        <div class="table-wrapper table-responsive">
                            <table class="table" id="FacultyBatchAttandanceReport">
                                <thead>
                                    <tr class="text-sm">
                                        <th class="text-uppercase">Faculty Name</th>
                                        <th class="text-uppercase">Total Batch</th>
                                        <th class="text-uppercase">Total Attandance</th>
                                    </tr>
                                </thead>

                                <tbody >

                                </tbody>

                            </table>
                            <!-- end table -->
                        </div>
                    </div>
                    <!-- end card -->
                </div>
                <!-- end col -->
            </div>
            <!-- end row -->
        </div>
    </div>
    <!-- end container -->
</section>
<!-- ========== section end ========== -->
@push('script')
<script>
$(document).ready(function() {
    var dataTable = $('#FacultyBatchAttandanceReport').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'csv', 'pdf', 'print'
        ]
    });

    $('#FacultyBatchAttandanceform').submit(function(event) {
        event.preventDefault(); 

        var formData = $(this).serialize();

        $.ajax({
            url: "{{ route('FacultyAttandanceCounterReport') }}",
            method: "POST",
            data: formData,
            success: function(response) {
                if (response.success) {
                    dataTable.clear().draw();
                    $.each(response.facultyAttendanceAndBatchCounts, function(index, record) {
                        console.log(record);
                        dataTable.row.add([
                            record.facultyName,
                            record.totalBatchCount,
                            record.totalAttendanceCount
                        ]).draw();
                    });
                } else {
                    $('#responseMessage').html('<div class="alert alert-danger">' + response.message + '</div>');
                }
            },
            error: function(xhr, status, error) {
                console.error(xhr.responseText);
                $('#responseMessage').html('<div class="alert alert-danger">An error occurred while fetching data.</div>');
            }
        });
    });
});


</script>
@endpush

@endsection