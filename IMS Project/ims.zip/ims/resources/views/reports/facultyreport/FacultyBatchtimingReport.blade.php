@extends('layout.admin_layout')
@section('title', 'Faculty Batch StartTime-EndTime Report')
@section('dashboard')
<!-- ========== section start ========== -->
<section class="section">
    <div class="container-fluid">

        @if(session('error'))
        <div class="alert alert-danger alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('error') }}
        </div>
        @endif

        @if(session('success'))
        <div class="alert alert-success alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('success') }}
        </div>
        @endif

        <!-- ========== title-wrapper start ========== -->
        <div class="title-wrapper pt-30">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <div class="title">
                        <h2>Faculty Batch StartTime-EndTime Report</h2>
                    </div>
                </div>
            </div>
            <!-- end row -->
        </div>

        <div class="col-md-12">
            <div class="signup-wrapper">
                <div class="form-wrapper">
                    <form id="FacultyBatchTimingform" method="post">
                        @csrf
                        <div class="row">
                            <div class="col-md-6 col-xs-12">
                                <div class="input-style-1">
                                    <label for="FromDate" class="compulsory">From Date </label>
                                    <input type="date" name="FromDate" id="FromDate" value="{{ date('Y-m-d') }}" />
                                    @error('FromDate')
                                    <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-6 col-xs-12">
                                <div class="input-style-1">
                                    <label for="ToDate" class="compulsory">To Date </label>
                                    <input type="date" name="ToDate" id="ToDate" value="{{ date('Y-m-d') }}" />
                                    @error('ToDate')
                                    <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 col-xs-12">
                                <div class="select-style-1">
                                    <label for="FacultyId">Faculty</label>
                                    <div class="select-position">
                                        <select name="FacultyId" id="FacultyId">
                                            <option selected>Select Faculty</option>
                                            @if (isset($faculties))
                                            @foreach ($faculties as $faculty)
                                            <option value="{{$faculty->id}}" {{old('FacultyId') == $faculty->id ? 'selected' : '' }}>{{$faculty->FirstName ." ".$faculty->LastName}}</option>
                                            @endforeach
                                            @endif
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-xs-12">
                                <div class="select-style-1">
                                    <label for="SubjectId">Subject</label>
                                    <div class="select-position">
                                        <select name="SubjectId" id="SubjectId">
                                            <option selected>Select Subject</option>
                                            @if (isset($subjects))
                                            @foreach ($subjects as $subject)
                                            <option value="{{$subject->id}}" {{old('SubjectId') == $subject->id ? 'selected' : '' }}>{{$subject->Name}}</option>
                                            @endforeach
                                            @endif
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 col-xs-12">
                                <div class="select-style-1">
                                    <label for="BatchId">Batch</label>
                                    <div class="select-position">
                                        <select name="BatchId" id="BatchId">
                                            <option selected>Select Batch</option>
                                            @if (isset($batches))
                                            @foreach ($batches as $batch)
                                            <option value="{{$batch->id}}" {{old('BatchId') == $batch->id ? 'selected' : '' }}>{{$batch->Name}}</option>
                                            @endforeach
                                            @endif
                                        </select>
                                    </div>
                                </div>
                            </div>

                        </div>

                        <!-- end col -->
                        <div class="row">
                            <div class="col-12 mt-10">
                                <button class="main-btn dark-btn rounded-full btn-hover btn-sm">
                                    Submit
                                </button>
                            </div>
                        </div>
                        <!-- end row -->
                    </form>

                </div>
            </div>
        </div>
        <span class="divider">
            <hr />
        </span>
        <div class="tables-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card-style mb-30">
                        <div id="responseMessage"></div>
                        <h4 class="mb-10">Faculty Batch StartTime-EndTime Report</h4>
                        <div class="table-wrapper table-responsive">
                            <table class="table" id="FacultyBatchTimingReporttable">
                                <thead>
                                    <tr class="text-sm">
                                        <th class="text-uppercase">For Date</th>
                                        <th class="text-uppercase">Start Time</th>
                                        <th class="text-uppercase">End Time</th>
                                        <th class="text-uppercase">First Name</th>
                                        <th class="text-uppercase">Last Name</th>
                                        <th class="text-uppercase">Batch</th>
                                        <th class="text-uppercase">Batch Start Date</th>
                                        <th class="text-uppercase">Batch End Date</th>
                                        <th class="text-uppercase">Subject</th>
                                        <th class="text-uppercase">Course</th>
                                        <th class="text-uppercase">Batch From Time</th>
                                        <th class="text-uppercase">Batch To Time</th>
                                        <th class="text-uppercase">Late OR Early</th>
                                    </tr>

                                </thead>

                                <tbody class="text-center">

                                </tbody>

                            </table>
                            <!-- end table -->
                        </div>
                    </div>
                    <!-- end card -->
                </div>
                <!-- end col -->
            </div>
            <!-- end row -->
        </div>
    </div>
    <!-- end container -->
</section>
<!-- ========== section end ========== -->
@push('script')
<script>
    $(document).ready(function() {
        var isDataTableInitialized = false; // Initialize the flag
        var dataTableOptions = { // DataTable options with buttons
            dom: 'Bfrtip',
            buttons: [
                'csv', 'pdf', 'print'
            ]
        };

        $('#FacultyBatchTimingform').submit(function(e) {
            e.preventDefault();
            var formData = $(this).serialize();
            $.ajax({
                type: 'POST',
                url: '{{ route("FacultyBatchTimingReport") }}',
                data: formData,
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        $('#responseMessage').html('<div class="alert alert-info alert-dismissible fade show" >Data loaded successfully!</div>');
                        if (isDataTableInitialized) {
                            $('#FacultyBatchTimingReporttable').DataTable().clear().destroy(); // Destroy existing DataTable
                            displayData(response.data);
                            $('#FacultyBatchTimingReporttable').DataTable(dataTableOptions); // Reinitialize DataTable with buttons
                        } else {
                            displayData(response.data);
                            $('#FacultyBatchTimingReporttable').DataTable(dataTableOptions); // Initialize DataTable with buttons
                            isDataTableInitialized = true; // Set the flag to true after initialization
                        }
                    } else {
                        $('#responseMessage').html('<div class="alert alert-danger alert-dismissible fade show" >Error: ' + response.message + '</div>');
                        if (isDataTableInitialized) {
                            $('#FacultyBatchTimingReporttable').DataTable().clear().destroy(); // Destroy existing DataTable
                        }
                    }
                },
                error: function(xhr, status, error) {
                    $('#responseMessage').html('<div class="alert alert-danger alert-dismissible fade show" >Error: ' + error + '</div>');
                }
            });
        });

        function displayData(data) {
            $('#FacultyBatchTimingReporttable tbody').empty();
            data.forEach(function(item) {
                var lateOrEarly = calculateLateOrEarly(item.StartTime, item.EndTime, item.StartTimeInMinutes, item.EndTimeInMinutes);
                // Format the time
                function formatTime(dateString) {
                    var date = new Date(dateString);
                    var hours = date.getHours().toString().padStart(2, '0');
                    var minutes = date.getMinutes().toString().padStart(2, '0');
                    var seconds = date.getSeconds().toString().padStart(2, '0');
                    return hours + ":" + minutes + ":" + seconds;
                }

                // Format the date
                function formatDate(dateString) {
                    var date = new Date(dateString);
                    var day = date.getDate();
                    var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                    var monthIndex = date.getMonth();
                    var year = date.getFullYear() % 100;
                    return day + "-" + monthNames[monthIndex] + "-" + year;
                }

                var formattedfordate = formatDate(item.ForDate);
                var formattedStartTime = formatDate(item.StartTime) + " " + formatTime(item.StartTime);
                var formattedEndTime = formatDate(item.EndTime) + " " + formatTime(item.EndTime);
                var formattedBatchStartDate = formatDate(item.FromDate);
                var formattedBatchEndDate = formatDate(item.ToDate);

                var row = '<tr>' +
                    '<td>' + formattedfordate + '</td>' +
                    '<td>' + formattedStartTime + '</td>' +
                    '<td>' + formattedEndTime + '</td>' +
                    '<td>' + item.FirstName + '</td>' +
                    '<td>' + item.LastName + '</td>' +
                    '<td>' + item.batch_name + '</td>' +
                    '<td>' + formattedBatchStartDate + '</td>' +
                    '<td>' + formattedBatchEndDate + '</td>' +
                    '<td>' + item.subject_name + '</td>' +
                    '<td>' + item.course_name + '</td>' +
                    '<td>' + item.StartTimeInMinutes + '</td>' +
                    '<td>' + item.EndTimeInMinutes + '</td>' +
                    '<td>' + lateOrEarly + '</td>' +
                    '</tr>';
                $('#FacultyBatchTimingReporttable tbody').append(row);
            });
        }


        function calculateLateOrEarly(startTime, endTime, scheduledStartTime, scheduledEndTime) {
            var actualStartTime = convertTimeStringToMinutes(startTime);
            var actualEndTime = convertTimeStringToMinutes(endTime);
            var lateThreshold = scheduledStartTime + 5; // 5 minutes threshold for being late
            var earlyThreshold = scheduledEndTime - 5; // 5 minutes threshold for leaving early

            if (actualStartTime > lateThreshold || actualEndTime < earlyThreshold) {
                var delayMinutes = 0;
                if (actualStartTime > lateThreshold) {
                    delayMinutes = actualStartTime - lateThreshold;
                }
                if (actualEndTime < earlyThreshold) {
                    delayMinutes = actualEndTime - earlyThreshold;
                }
                var days = Math.floor(delayMinutes / (60 * 24)); // Calculate days
                var hours = Math.floor((delayMinutes % (60 * 24)) / 60); // Calculate hours
                var minutes = delayMinutes % 60; // Calculate remaining minutes

                var delayString = "";
                if (days > 0) {
                    delayString += days + " days ";
                }
                if (hours > 0) {
                    delayString += hours + " hours ";
                }
                if (minutes > 0) {
                    delayString += minutes + " minutes";
                }

                return delayString.trim(); // Trim any extra spaces
            } else {
                return 'On Time';
            }
        }


        function convertTimeStringToMinutes(timeString) {
            var parts = timeString.split(':');
            return parseInt(parts[0]) * 60 + parseInt(parts[1]);
        }
    });
</script>


@endpush

@endsection