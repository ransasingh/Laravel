@extends('layout.admin_layout')
@section('title', 'Faculty Batch Report')
@section('dashboard')
<!-- ========== section start ========== -->
<section class="section">
    <div class="container-fluid">

        @if(session('error'))
        <div class="alert alert-danger alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('error') }}
        </div>
        @endif

        @if(session('success'))
        <div class="alert alert-success alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('success') }}
        </div>
        @endif

        <!-- ========== title-wrapper start ========== -->
        <div class="title-wrapper pt-30">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <div class="title">
                        <h2>Faculty Batch Report</h2>
                    </div>
                </div>

            </div>
            <!-- end row -->
        </div>

        <div class="col-md-12">
            <div class="signup-wrapper">
                <div class="form-wrapper">
                    <form id="facultyBatchForm" method="POST">
                        @csrf
                        <div class="row">
                            <div class="col-md-6 col-xs-12">
                                <div class="select-style-1">
                                    <label for="Batch" class="compulsory">All/With Batch/Without Batch</label>
                                    <div class="select-position">
                                        <select name="Batch" id="Batch">
                                            <option value="All" {{ old('Batch') == "All" ? 'selected' : '' }}>All</option>
                                            <option value="WithBatch" {{ old('Batch') == "WithBatch" ? 'selected' : '' }}>With Batch</option>
                                            <option value="WithoutBatch" {{ old('Batch') == "WithoutBatch" ? 'selected' : '' }}>Without Batch</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- end col -->
                        <div class="row">
                            <div class="col-12 mt-10">
                                <button class="main-btn dark-btn rounded-full btn-hover btn-sm">
                                    Submit
                                </button>
                            </div>
                        </div>
                        <!-- end row -->
                    </form>

                </div>
            </div>
        </div>
        <span class="divider">
            <hr />
        </span>
        <div class="tables-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card-style mb-30">
                        <div id="responseMessage"></div>
                        <h4 class="mb-10">Faculty Batch Report</h4>
                        <div class="table-wrapper table-responsive">
                            <table class="table" id="facultyBatchreports">
                                <thead>
                                    <tr class="text-sm">
                                        <th class="text-uppercase">First Name</th>
                                        <th class="text-uppercase">Last Name</th>
                                        <th class="text-uppercase">Batch</th>
                                        <th class="text-uppercase">Batch Start Date</th>
                                        <th class="text-uppercase">Batch End Date</th>
                                        <th class="text-uppercase">Batch From Time</th>
                                        <th class="text-uppercase">Batch To Time</th>
                                        <th class="text-uppercase">Batch Status</th>
                                        <th class="text-uppercase">Branch</th>
                                        <th class="text-uppercase">Batch Completed</th>
                                    </tr>

                                </thead>

                                <tbody class="text-center">

                                </tbody>

                            </table>
                            <!-- end table -->
                        </div>
                    </div>
                    <!-- end card -->
                </div>
                <!-- end col -->
            </div>
            <!-- end row -->
        </div>
    </div>
    <!-- end container -->
</section>
<!-- ========== section end ========== -->
@push('script')
<script>
    $(document).ready(function() {
        var dataTable = $('#facultyBatchreports').DataTable({
            dom: 'Blfrtip',
            buttons: ['csv', 'excel', 'pdf', 'print'],
            lengthMenu: [
                [10, 25, 50, -1],
                [10, 25, 50, "All"]
            ],
            ajax: {
                url: "{{ route('FacultyBatchReport') }}",
                type: "POST",
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                data: function(d) {
                    d.Batch = $('#Batch').val();
                },
                dataSrc: ''
            },
            columns: [{
                    data: 'FirstName'
                },
                {
                    data: 'LastName'
                },
                {
                    data: 'Name' // Batch Name
                },
                {
                    data: 'FromDate'
                },
                {
                    data: 'ToDate'
                },
                {
                    data: 'StartTimeInMinutes'
                },
                {
                    data: 'EndTimeInMinutes'
                },
                {
                    data: 'BatchStatus',
                    render: function(data) {
                        var color = data === 'Active' ? 'green' : 'red';
                        return '<div style="color: ' + color + ';">' + data + '</div>';
                    }
                },
                {
                    data: 'branch_name' // Branch Name
                },
                {
                    data: 'IsCompleted',
                    render: function(data) {
                        var color = data === 1 ? 'green' : 'red';
                        return '<div style="color: ' + color + ';">' + (data === 1 ? 'Yes' : 'No') + '</div>';
                    }
                }

            ]
        });

        // Submit form handler
        $('#facultyBatchForm').on('submit', function(e) {
            e.preventDefault();
            dataTable.ajax.reload();
        });
    });
</script>
@endpush

@endsection