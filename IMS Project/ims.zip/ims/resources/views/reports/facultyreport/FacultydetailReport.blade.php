    @extends('layout.admin_layout')
    @section('title', 'Faculty Detail Report')
    @section('dashboard')
    <!-- ========== section start ========== -->
    <section class="section">
        <div class="container-fluid">

            @if(session('error'))
            <div class="alert alert-danger alert-dismissible mt-20 fade show alert-sm" role="alert">
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                {{ session('error') }}
            </div>
            @endif

            @if(session('success'))
            <div class="alert alert-success alert-dismissible mt-20 fade show alert-sm" role="alert">
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                {{ session('success') }}
            </div>
            @endif

            <!-- ========== title-wrapper start ========== -->
            <div class="title-wrapper pt-30">
                <div class="row align-items-center">
                    <div class="col-md-6">
                        <div class="title">
                            <h2>Faculty Detail Report</h2>
                        </div>
                    </div>

                </div>
                <!-- end row -->
            </div>

            <div class="col-md-12">
                <div class="signup-wrapper">
                    <div class="form-wrapper">
                        <form id="facultyDetailReport" method="post">
                            @csrf
                            <div class="row">
                                <div class="col-md-6 col-xs-12">
                                    <div class="select-style-1">
                                        <label for="IsActive" class="compulsory">All/Active/In-Active</label>
                                        <div class="select-position">
                                            <select name="IsActive" id="IsActive">
                                                <option value="All" {{old('IsActive') == "All" ? 'selected' : '' }}>All</option>
                                                <option value="Active" {{old('IsActive') == "Active" ? 'selected' : '' }}>Active</option>
                                                <option value="In-Active" {{old('IsActive') == "In-Active" ? 'selected' : '' }}>In-Active</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- end col -->
                            <div class="row">
                                <div class="col-12 mt-10">
                                    <button class="main-btn dark-btn rounded-full btn-hover btn-sm">
                                        Submit
                                    </button>
                                </div>
                            </div>
                            <!-- end row -->
                        </form>

                    </div>
                </div>
            </div>
            <span class="divider">
                <hr />
            </span>
            <div class="tables-wrapper">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card-style mb-30">
                            <div id="responseMessage"></div>
                            <h4 class="mb-10">Faculty Detail Report</h4>
                            <div class="table-wrapper table-responsive">
                                <table class="table" id="FacultyDetailReport">
                                    <thead>
                                        <tr class="text-sm">
                                            <th class="text-uppercase">First Name</th>
                                            <th class="text-uppercase">Last Name</th>
                                            <th class="text-uppercase">Mobile Number</th>
                                            <th class="text-uppercase">Email ID</th>
                                            <th class="text-uppercase">State Name</th>
                                            <th class="text-uppercase">City Name</th>
                                            <th class="text-uppercase">Address Line1</th>
                                            <th class="text-uppercase">Address Line2</th>
                                            <th class="text-uppercase">Postal Code</th>
                                            <th class="text-uppercase">Employee Code</th>
                                            <th class="text-uppercase">Institute Name</th>
                                            <th class="text-uppercase">Is Active</th>
                                            <th class="text-uppercase">Permanent Address Line1</th>
                                            <th class="text-uppercase">Permanent Address Line2</th>
                                            <th class="text-uppercase">Permanent State</th>
                                            <th class="text-uppercase">Permanent City</th>
                                            <th class="text-uppercase">Emergency Contact Number</th>
                                            <th class="text-uppercase">Blood Group</th>
                                            <th class="text-uppercase">Branch</th>
                                        </tr>
                                    </thead>

                                    <tbody class="text-center">

                                    </tbody>

                                </table>
                                <!-- end table -->
                            </div>
                        </div>
                        <!-- end card -->
                    </div>
                    <!-- end col -->
                </div>
                <!-- end row -->
            </div>
        </div>
        <!-- end container -->
    </section>
    <!-- ========== section end ========== -->
    @push('script')
    <script>
        $(document).ready(function() {
            // Initialize DataTable with specified options
            var dataTable = $('#FacultyDetailReport').DataTable({
                dom: 'Blfrtip',
                buttons: [{
                        extend: 'csv',
                        text: 'CSV'
                    },
                    {
                        extend: 'excel',
                        text: 'Excel'
                    },
                    {
                        extend: 'pdf',
                        text: 'PDF',
                        customize: function(doc) {
                            doc.defaultStyle.fontSize = 10;
                            doc.pageOrientation = 'landscape';
                            doc.pageSize = 'A3';
                        },
                        pageFit: 'auto'
                    },
                    {
                        extend: 'print',
                        text: 'Print',
                        customize: function(win) {
                            $(win.document.body)
                                .css('font-size', '10pt');

                        },
                        autoPrint: true,
                        pageFit: 'landscape'
                    },
                    'colvis'
                ],
                lengthMenu: [
                    [10, 25, 50, -1],
                    [10, 25, 50, "All"]
                ],
                columnDefs: [{
                    targets: 'no-sort',
                    orderable: false
                }],
                language: {
                    emptyTable: "No records found"
                }
            });

            // Handle form submission
            $('#facultyDetailReport').submit(function(event) {
                event.preventDefault(); // Prevent the form from submitting normally

                // Fetch form data
                var formData = $(this).serialize();

                // Send AJAX request
                $.ajax({
                    url: "{{ route('FacultyDetailReport') }}",
                    method: "POST",
                    data: formData,
                    success: function(response) {
                        // Clear table before populating with new data
                        dataTable.clear().draw();
                        if (response.error) {
                            // If an error is returned, display it in the responseMessage div
                            $('#responseMessage').html('<div class="alert alert-danger">' + response.error + '</div>');
                        } else {
                            // Populate DataTable with fetched data
                            $.each(response, function(index, faculty) {
                                // Convert IsActive to Yes or No
                                var isActive = faculty.IsActive == 1 ? 'Yes' : 'No';
                                // Add data to the table
                                dataTable.row.add([
                                    faculty.FirstName,
                                    faculty.LastName,
                                    faculty.MobileNumber,
                                    faculty.EmailId,
                                    faculty.state_name,
                                    faculty.CityName,
                                    faculty.AddressLine1,
                                    faculty.AddressLine2,
                                    faculty.PostalCode,
                                    faculty.EmployeeCode,
                                    faculty.institute_name,
                                    isActive,
                                    faculty.PrAddressLine1,
                                    faculty.PrAddressLine2,
                                    faculty.PrState,
                                    faculty.PrCityName,
                                    faculty.EmergencyContactNumber,
                                    faculty.BloodGroup,
                                    faculty.branch_name,
                                ]).draw(false);
                            });
                        }
                    },
                    error: function(xhr, status, error) {
                        // Handle error
                        console.error(xhr.responseText);
                    }
                });
            });
        });
    </script>


    @endpush

    @endsection