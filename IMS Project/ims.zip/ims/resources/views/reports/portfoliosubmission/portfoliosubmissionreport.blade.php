@extends('layout.admin_layout')
@section('title', 'Portfolio Submission Report')
@section('dashboard')
<!-- ========== section start ========== -->
<section class="section">
    <div class="container-fluid">

        @if(session('error'))
        <div class="alert alert-danger alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('error') }}
        </div>
        @endif

        @if(session('success'))
        <div class="alert alert-success alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('success') }}
        </div>
        @endif

        <!-- ========== title-wrapper start ========== -->
        <div class="title-wrapper pt-30">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <div class="title">
                        <h2>Portfolio Submission Report</h2>
                    </div>
                </div>

            </div>
            <!-- end row -->
        </div>

        <div class="col-md-12">
            <div class="signup-wrapper">
                <div class="form-wrapper">
                    <form id="PortfolioSubmissionForm" method="post">
                        @csrf
                        <div class="row">
                            <div class="col-md-6 col-xs-12">
                                <div class="input-style-1">
                                    <label for="FromDate" class="compulsory">From Date </label>
                                    <input type="date" name="FromDate" id="FromDate" value="{{ date('Y-m-d') }}" />
                                    @error('FromDate')
                                    <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-6 col-xs-12">
                                <div class="input-style-1">
                                    <label for="ToDate" class="compulsory">To Date </label>
                                    <input type="date" name="ToDate" id="ToDate" value="{{ date('Y-m-d') }}" />
                                    @error('ToDate')
                                    <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 col-xs-12">
                                <div class="select-style-1">
                                    <label for="FacultyId">Faculty</label>
                                    <div class="select-position">
                                        <select name="FacultyId" id="FacultyId">
                                            <option selected>Select Faculty</option>
                                            @if (isset($faculties))
                                            @foreach ($faculties as $faculty)
                                            <option value="{{$faculty->id}}" {{old('FacultyId') == $faculty->id ? 'selected' : '' }}>{{$faculty->FirstName ." ".$faculty->LastName}}</option>
                                            @endforeach
                                            @endif
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-xs-12">
                                <div class="select-style-1">
                                    <label for="SubjectId">Subject</label>
                                    <div class="select-position">
                                        <select name="SubjectId" id="SubjectId">
                                            <option selected>Select Subject</option>
                                            @if (isset($subjects))
                                            @foreach ($subjects as $subject)
                                            <option value="{{$subject->id}}" {{old('SubjectId') == $subject->id ? 'selected' : '' }}>{{$subject->Name}}</option>
                                            @endforeach
                                            @endif
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 col-xs-12">
                                <div class="select-style-1">
                                    <label for="StudentId">Student</label>
                                    <div class="select-position">
                                        <select name="StudentId" id="StudentId">
                                            <option selected>Select Student</option>
                                            @if (isset($students))
                                            @foreach ($students as $student)
                                            <option value="{{$student->id}}" {{old('StudentId') == $student->id ? 'selected' : '' }}>{{$student->FirstName ." ".$student->LastName}}</option>
                                            @endforeach
                                            @endif
                                        </select>
                                    </div>

                                </div>
                            </div>

                        </div>

                        <!-- end col -->
                        <div class="row">
                            <div class="col-12 mt-10">
                                <button class="main-btn dark-btn rounded-full btn-hover btn-sm">
                                    Submit
                                </button>
                            </div>
                        </div>
                        <!-- end row -->
                    </form>

                </div>
            </div>
        </div>
        <span class="divider">
            <hr />
        </span>
        <div class="tables-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card-style mb-30">
                        <div id="responseMessage"></div>
                        <h4 class="mb-10">Portfolio Submission Report</h4>
                        <div class="table-wrapper table-responsive">
                            <table class="table" id="data-table1">
                                <thead>
                                    <tr class="text-sm">
                                        <th class="text-uppercase">Submission Date</th>
                                        <th class="text-uppercase">First Name</th>
                                        <th class="text-uppercase">Last Name</th>
                                        <th class="text-uppercase">Approved At</th>
                                        <th class="text-uppercase">Is Approved</th>
                                        <th class="text-uppercase">Remark</th>
                                        <th class="text-uppercase">Subject Name</th>
                                        <th class="text-uppercase">Course Name</th>
                                        <th class="text-uppercase">Faculty Name</th>
                                        <th class="text-uppercase">Approved By Name</th>

                                    </tr>

                                </thead>

                                <tbody class="text-center">

                                </tbody>

                            </table>
                            <!-- end table -->
                        </div>
                    </div>
                    <!-- end card -->
                </div>
                <!-- end col -->
            </div>
            <!-- end row -->
        </div>
    </div>
    <!-- end container -->
</section>
<!-- ========== section end ========== -->
@push('script')

<!-- Add this script to your view file -->
<script>
    $(document).ready(function() {
        var dataTableInitialized = false; // Flag to track DataTable initialization

        $('#PortfolioSubmissionForm').submit(function(event) {
            event.preventDefault(); // Prevent default form submission

            var formData = $(this).serialize(); // Serialize form data
            $.ajax({
                url: "{{ route('PortfolioSubmissionReport') }}",
                type: "POST",
                data: formData,
                success: function(response) {
                    if (response.data.length === 0) {
                        $('#data-table1 tbody').html('<tr><td colspan="10" class="text-center">No data found</td></tr>');
                    } else {
                        var html = '';
                        $.each(response.data, function(index, item) {
                            // Format dates
                            var submissionDate = formatDate(new Date(item.SubmissionDate));
                            var approvedAt = formatDate(new Date(item.ApprovedAt));
                            // Format IsApproved
                            var isApproved = item.IsApproved == 1 ? 'Yes' : 'No';

                            html += '<tr>' +
                                '<td>' + submissionDate + '</td>' +
                                '<td>' + item.StudentFirstName + '</td>' +
                                '<td>' + item.StudentLastName + '</td>' +
                                '<td>' + approvedAt + '</td>' +
                                '<td>' + isApproved + '</td>' +
                                '<td>' + item.remark + '</td>' +
                                '<td>' + item.subject_name + '</td>' +
                                '<td>' + item.course_name + '</td>' +
                                '<td>' + item.FacultyName + '</td>' +
                                '<td>' + item.Approved_name + '</td>' +
                                '</tr>';
                        });
                        $('#data-table1 tbody').html(html);

                        // Initialize DataTable only if it's not already initialized
                        if (!dataTableInitialized) {
                            $('#data-table1').DataTable({
                                responsive: true,
                                dom: 'Bfrtip',
                                buttons: [
                                    'csv', 'print', 'pdf'
                                ]
                            });
                            dataTableInitialized = true; // Set flag to true after initialization
                        } else {
                            $('#data-table1').DataTable().destroy(); // Destroy existing DataTable
                            $('#data-table1').DataTable({
                                responsive: true,
                                dom: 'Bfrtip',
                                buttons: [
                                    'csv', 'print', 'pdf'
                                ]
                            });
                        }
                    }
                },
                error: function(xhr) {
                    console.log(xhr.responseText);
                }
            });
        });

        function formatDate(date) {
            var day = ('0' + date.getDate()).slice(-2);
            var month = ('0' + (date.getMonth() + 1)).slice(-2);
            var year = date.getFullYear();
            var monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
            var monthName = monthNames[date.getMonth()];
            return day + '-' + monthName + '-' + year;
        }
    });
</script>


@endpush

@endsection