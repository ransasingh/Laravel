@extends('layout.admin_layout')
@section('title', 'Student Attandance Report')
@section('dashboard')
<!-- ========== section start ========== -->
<section class="section">
    <div class="container-fluid">

        @if(session('error'))
        <div class="alert alert-danger alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('error') }}
        </div>
        @endif

        @if(session('success'))
        <div class="alert alert-success alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('success') }}
        </div>
        @endif

        <!-- ========== title-wrapper start ========== -->
        <div class="title-wrapper pt-30">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <div class="title">
                        <h2>Student Attandance Report</h2>
                    </div>
                </div>
               
            </div>
            <!-- end row -->
        </div>

        <div class="col-md-12">
            <div class="signup-wrapper">
                <div class="form-wrapper">
                    <form id="attendanceForm" method="post">
                        @csrf
                        <div class="row">
                            <div class="col-md-6 col-xs-12">
                                <div class="input-style-1">
                                    <label for="FromDate" class="compulsory">From Date </label>
                                    <input type="date" name="FromDate" id="FromDate" value="{{ date('Y-m-d') }}" />
                                    @error('FromDate')
                                    <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-6 col-xs-12">
                                <div class="input-style-1">
                                    <label for="ToDate" class="compulsory">To Date </label>
                                    <input type="date" name="ToDate" id="ToDate" value="{{ date('Y-m-d') }}" />
                                    @error('ToDate')
                                    <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 col-xs-12">
                                <div class="select-style-1">
                                    <label for="FacultyId">Faculty</label>
                                    <div class="select-position">
                                        <select name="FacultyId" id="FacultyId">
                                            <option selected>Select Faculty</option>
                                            @if (isset($faculties))
                                            @foreach ($faculties as $faculty)
                                            <option value="{{$faculty->id}}" {{old('FacultyId') == $faculty->id ? 'selected' : '' }}>{{$faculty->FirstName ." ".$faculty->LastName}}</option>
                                            @endforeach
                                            @endif
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-xs-12">
                                <div class="select-style-1">
                                    <label for="SubjectId">Subject</label>
                                    <div class="select-position">
                                        <select name="SubjectId" id="SubjectId">
                                            <option selected>Select Subject</option>
                                            @if (isset($subjects))
                                            @foreach ($subjects as $subject)
                                            <option value="{{$subject->id}}" {{old('SubjectId') == $subject->id ? 'selected' : '' }}>{{$subject->Name}}</option>
                                            @endforeach
                                            @endif
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 col-xs-12">
                                <div class="select-style-1">
                                    <label for="BatchId">Batch</label>
                                    <div class="select-position">
                                        <select name="BatchId" id="BatchId">
                                            <option selected>Select Batch</option>
                                            @if (isset($batches))
                                            @foreach ($batches as $batch)
                                            <option value="{{$batch->id}}" {{old('BatchId') == $batch->id ? 'selected' : '' }}>{{$batch->Name}}</option>
                                            @endforeach
                                            @endif
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-xs-12">
                                <div class="select-style-1">
                                    <label for="StudentId">Student</label>
                                    <div class="select-position">
                                        <select name="StudentId" id="StudentId">
                                            <option selected>Select Student</option>
                                            @if (isset($students))
                                            @foreach ($students as $student)
                                            <option value="{{$student->id}}" {{old('StudentId') == $student->id ? 'selected' : '' }}>{{$student->FirstName ." ".$student->LastName}}</option>
                                            @endforeach
                                            @endif
                                        </select>
                                    </div>

                                </div>
                            </div>

                        </div>

                        <!-- end col -->
                        <div class="row">
                            <div class="col-12 mt-10">
                                <button class="main-btn dark-btn rounded-full btn-hover btn-sm">
                                    Submit
                                </button>
                            </div>
                        </div>
                        <!-- end row -->
                    </form>

                </div>
            </div>
        </div>
        <span class="divider">
            <hr />
        </span>
        <div class="tables-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card-style mb-30">
                        <div id="responseMessage"></div>
                        <h4 class="mb-10">Student Attandance Report</h4>
                        <div class="table-wrapper table-responsive">
                            <table class="table" id="data-table1">
                                <thead>
                                    <tr class="text-sm">
                                        <th class="text-uppercase">For Date</th>
                                        <th class="text-uppercase">Attandance</th>
                                        <th class="text-uppercase">First Name</th>
                                        <th class="text-uppercase">Last Name</th>
                                        <th class="text-uppercase">Batch</th>
                                        <th class="text-uppercase">Batch Start Date</th>
                                        <th class="text-uppercase">Batch End Date</th>
                                        <th class="text-uppercase">Subject</th>
                                        <th class="text-uppercase">Course</th>
                                        <th class="text-uppercase">Batch From Time</th>
                                        <th class="text-uppercase">Batch To Time</th>
                                    </tr>

                                </thead>

                                <tbody class="text-center">

                                </tbody>

                            </table>
                            <!-- end table -->
                        </div>
                    </div>
                    <!-- end card -->
                </div>
                <!-- end col -->
            </div>
            <!-- end row -->
        </div>
    </div>
    <!-- end container -->
</section>
<!-- ========== section end ========== -->
@push('script')
<script>
   $(document).ready(function() {
    var table; // Initialize DataTable instance

    $('#attendanceForm').submit(function(event) {
        event.preventDefault(); // Prevent default form submission

        var formData = $(this).serialize(); // Serialize form data
        $.ajax({
            url: "{{ route('studentattandancereport') }}",
            type: "POST",
            data: formData,
            success: function(response) {
                if (response.attendanceData.length === 0) {
                    $('#data-table1 tbody').html('<tr><td colspan="11" class="text-center">No data found</td></tr>');
                } else {
                    var html = '';
                    $.each(response.attendanceData, function(index, item) {
                        // Format dates
                        var forDate = formatDate(new Date(item.ForDate));
                        var fromDate = formatDate(new Date(item.FromDate));
                        var toDate = formatDate(new Date(item.ToDate));
                        // Determine attendance status
                        var attendance;
                        if (item.DayAttandance == 1) {
                            attendance = 'Present';
                        } else if (item.DayAttandance == 2) {
                            attendance = 'Late';
                        } else {
                            attendance = 'Absent';
                        }

                        html += '<tr>' +
                            '<td>' + forDate + '</td>' +
                            '<td>' + attendance + '</td>' +
                            '<td>' + item.FirstName + '</td>' +
                            '<td>' + item.LastName + '</td>' +
                            '<td>' + item.batch_name + '</td>' +
                            '<td>' + fromDate + '</td>' +
                            '<td>' + toDate + '</td>' +
                            '<td>' + item.subject_name + '</td>' +
                            '<td>' + item.course_name + '</td>' +
                            '<td>' + item.StartTimeInMinutes + '</td>' +
                            '<td>' + item.EndTimeInMinutes + '</td>' +
                            '</tr>';
                    });
                    $('#data-table1 tbody').html(html);

                    // Destroy existing DataTable instance if initialized
                    if ($.fn.DataTable.isDataTable('#data-table1')) {
                        $('#data-table1').DataTable().destroy();
                    }

                    // Initialize DataTable
                    table = $('#data-table1').DataTable({
                        responsive: true,
                        dom: 'Bfrtip',
                        buttons: [
                            'csv', 'print', 'pdf'
                        ]
                    });
                }
            },
            error: function(xhr) {
                console.log(xhr.responseText);
            }
        });
    });

    function formatDate(date) {
        var day = ('0' + date.getDate()).slice(-2);
        var month = ('0' + (date.getMonth() + 1)).slice(-2);
        var year = date.getFullYear();
        var monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        var monthName = monthNames[date.getMonth()];
        return day + '-' + monthName + '-' + year;
    }
});

</script>

@endpush

@endsection
