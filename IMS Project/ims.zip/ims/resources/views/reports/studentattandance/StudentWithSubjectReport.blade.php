@extends('layout.admin_layout')
@section('title', 'Student With Subject Report')
@section('dashboard')
<!-- ========== section start ========== -->
<section class="section">
    <div class="container-fluid">

        @if(session('error'))
        <div class="alert alert-danger alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('error') }}
        </div>
        @endif

        @if(session('success'))
        <div class="alert alert-success alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('success') }}
        </div>
        @endif

        <!-- ========== title-wrapper start ========== -->
        <div class="title-wrapper pt-30">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <div class="title">
                        <h2>Student With Subject Report</h2>
                    </div>
                </div>
                <!-- <div class="col-md-6">
                    <div class="breadcrumb-wrapper">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a href="{{--route('feestructure.listing')--}}" class="main-btn active-btn-light rounded-full btn-hover btn-sm">
                                        <i class="lni lni-arrow-left"></i>
                                        All FeeStructure
                                    </a>
                                </li>
                            </ol>
                        </nav>
                    </div>
                </div> -->
            </div>
            <!-- end row -->
        </div>

        <div class="col-md-12">
            <div class="signup-wrapper">
                <div class="form-wrapper">
                    <form id="studentwithsubjectreport" method="post">
                        @csrf
                        <div class="row">
                            <div class="col-md-6 col-xs-12">
                                <div class="input-style-1">
                                    <label for="AdmissionDate" class="compulsory">Admission From Date</label>
                                    <input type="date" name="AdmissionDate" id="AdmissionDate" value="{{ date('Y-m-d') }}" />
                                    @error('AdmissionDate')
                                    <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-6 col-xs-12">
                                <div class="input-style-1">
                                    <label for="ToDate" class="compulsory">Admission To Date</label>
                                    <input type="date" name="ToDate" id="ToDate" value="{{ date('Y-m-d') }}" />
                                    @error('ToDate')
                                    <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                        </div>
                        <!-- end col -->
                        <div class="row">
                            <div class="col-12 mt-10">
                                <button class="main-btn dark-btn rounded-full btn-hover btn-sm">
                                    Submit
                                </button>
                            </div>
                        </div>
                        <!-- end row -->
                    </form>

                </div>
            </div>
        </div>
        <span class="divider">
            <hr />
        </span>
        <div class="tables-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card-style mb-30">
                        <div id="responseMessage"></div>
                        <h4 class="mb-10">Student With Subject Report</h4>
                        <div class="table-wrapper table-responsive">
                            <table class="table" id="studentReportTable">
                                <thead>
                                    <tr class="text-sm">
                                        <th class="text-uppercase">First Name</th>
                                        <th class="text-uppercase">Last Name</th>
                                        <th class="text-uppercase">Course</th>
                                        <th class="text-uppercase">Mobile Number</th>
                                        <th class="text-uppercase">Admission Date</th>

                                    </tr>

                                </thead>

                                <tbody class="text-center">

                                </tbody>

                            </table>
                            <!-- end table -->
                        </div>
                    </div>
                    <!-- end card -->
                </div>
                <!-- end col -->
            </div>
            <!-- end row -->
        </div>
    </div>
    <!-- end container -->
</section>
<!-- ========== section end ========== -->
@push('script')
<script>
    $(document).ready(function() {
        $('#studentwithsubjectreport').on('submit', function(e) {
            e.preventDefault(); // Prevent default form submission
            var formData = $(this).serialize(); // Serialize form data

            // Clear previous response messages
            $('#responseMessage').html('');

            // Fetch student report data using Ajax
            $.ajax({
                url: "{{ route('StudentWithSubjectReport') }}",
                type: "POST",
                data: formData,
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        var students = response.students;
                        var dynamicColumns = response.dynamicColumns;

                        // Add dynamic subject columns to table header
                        var tableHead = $('#studentReportTable thead tr');
                        tableHead.empty(); // Clear existing table header
                        tableHead.append('<th>First Name</th>'); // Add static columns
                        tableHead.append('<th>Last Name</th>');
                        tableHead.append('<th>Course</th>');
                        tableHead.append('<th>Mobile Number</th>');
                        tableHead.append('<th>Admission Date</th>');
                        dynamicColumns.forEach(function(column) {
                            tableHead.append('<th>' + column.data + '</th>');
                        });

                        // Populate data into DataTable
                        var dataTable = $('#studentReportTable').DataTable({
                            destroy: true, // Destroy existing DataTable instance
                            data: students,
                            columns: [{
                                    data: 'FirstName'
                                },
                                {
                                    data: 'LastName'
                                },
                                {
                                    data: 'course_name'
                                },
                                {
                                    data: 'MobileNumber'
                                },
                                {
                                    data: 'AdmissionDate',
                                    render: function(data, type, row) {
                                        // Format the date string to 'dd-MMM-yy' format
                                        var date = new Date(data);
                                        var formattedDate = date.toLocaleDateString('en-GB', {
                                            day: 'numeric',
                                            month: 'short',
                                            year: '2-digit'
                                        }).replace(/ /g, '-');
                                        return formattedDate;
                                    }
                                },
                                // Add dynamic subject columns
                                ...dynamicColumns.map(col => ({
                                    data: col.data,
                                    render: function(data, type, row) {
                                        var subjects = row.subjects.split(',');
                                        var isCompleted = row.IsCompleted.split(',');
                                        for (var i = 0; i < subjects.length; i++) {
                                            if (subjects[i] === col.data) {
                                                return isCompleted[i];
                                            }
                                        }
                                        return 'Not Assigned';
                                    }
                                }))
                            ],
                            dom: 'Blfrtip', // Add buttons and length menu to the DataTable
                            buttons: [
                                'csv', 'excel', 'pdf', 'print'
                            ],
                            lengthMenu: [
                                [10, 25, 50, -1],
                                [10, 25, 50, "All"]
                            ] // Define the options for the length menu
                        });
                    } else {
                        // Display error message
                        $('#responseMessage').html('<div class="alert alert-danger">' + response.error + '</div>');
                    }
                },
                error: function(xhr, status, error) {
                    // Display Ajax error message
                    $('#responseMessage').html('<div class="alert alert-danger">An error occurred: ' + error + '</div>');
                }
            });
        });
    });
</script>


@endpush



@endsection