@extends('layout.admin_layout')
@section('title', 'Revenue Report')
@section('dashboard')
<!-- ========== section start ========== -->
<section class="section">
    <div class="container-fluid">

        @if(session('error'))
        <div class="alert alert-danger alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('error') }}
        </div>
        @endif

        @if(session('success'))
        <div class="alert alert-success alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('success') }}
        </div>
        @endif

        <!-- ========== title-wrapper start ========== -->
        <div class="title-wrapper pt-30">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <div class="title">
                        <h2>Revenue Report</h2>
                    </div>
                </div>

            </div>
            <!-- end row -->
        </div>

        <div class="col-md-12">
            <div class="signup-wrapper">
                <div class="form-wrapper">
                    <form id="revenue-report-form" method="post">
                        @csrf
                        <div class="row">
                            <div class="col-md-6 col-xs-12">
                                <div class="select-style-1">
                                    <label for="BranchId">Branch</label>
                                    <div class="select-position">
                                        <select name="BranchId" id="BranchId">
                                            @if (isset($branches))
                                            @foreach ($branches as $branch)
                                            <option value="{{$branch->id}}" {{old('BranchId') == $branch->id ? 'selected' : '' }}>{{$branch->Name}}</option>
                                            @endforeach
                                            @endif
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 col-xs-12">
                                <div class="input-style-1">
                                    <label for="FromDate">From Date </label>
                                    <input type="date" name="FromDate" id="FromDate" />
                                    @error('FromDate')
                                    <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-6 col-xs-12">
                                <div class="input-style-1">
                                    <label for="ToDate">To Date </label>
                                    <input type="date" name="ToDate" id="ToDate" />
                                    @error('ToDate')
                                    <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 col-xs-12">
                                <div class="select-style-1">
                                    <label for="StudentId">Student</label>
                                    <div class="select-position">
                                        <select name="StudentId" id="StudentId">
                                            <option selected>Select Student</option>
                                            @if (isset($students))
                                            @foreach ($students as $student)
                                            <option value="{{$student->id}}" {{old('StudentId') == $student->id ? 'selected' : '' }}>{{$student->FirstName ." ".$student->LastName}}</option>
                                            @endforeach
                                            @endif
                                        </select>
                                    </div>

                                </div>
                            </div>
                            <div class="col-md-6 col-xs-12">
                                <div class="select-style-1">
                                    <label for="Firmid">Firm</label>
                                    <div class="select-position">
                                        <select name="Firmid" id="Firmid">
                                            <option selected>Select Firm</option>
                                            @if (isset($firms))
                                            @foreach ($firms as $firm)
                                            <option value="{{$firm->id}}" {{old('Firmid') == $firm->id ? 'selected' : '' }}>{{$firm->Name}}</option>
                                            @endforeach
                                            @endif
                                        </select>
                                    </div>
                                </div>
                            </div>


                        </div>
                        <div class="row">
                            <div class="col-md-6 col-xs-12">
                                <div class="select-style-1">
                                    <label for="PaymentMode">Payment Mode </label>
                                    <div class="select-position">
                                        <select name="PaymentMode" id="PaymentMode">
                                            <option selected>Select Mode Payment</option>
                                            <option value="Cash" {{old('PaymentMode') == 'Cash' ? 'selected' : ''}}>Cash</option>
                                            <option value="Cheque" {{old('PaymentMode') == 'Cheque' ? 'selected' : ''}}>Cheque</option>
                                            <option value="Online" {{old('PaymentMode') == 'Online' ? 'selected' : ''}}>Online</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-xs-12">
                                <div class="select-style-1">
                                    <label for="reportid" class="compulsory">Report Type</label>
                                    <div class="select-position">
                                        <select name="reportid" id="reportid">
                                            <option value="BW" {{old('reportid') == 'BW' ? 'selected' : ''}}>Branch Wise Group</option>
                                            <option value="SW" {{old('reportid') == 'SW' ? 'selected' : ''}}>Student Wise Group</option>
                                            <option value="PW" {{old('reportid') == 'PW' ? 'selected' : ''}}>Payment Mode Wise Group</option>
                                            <option value="MW" {{old('reportid') == 'MW' ? 'selected' : ''}}>Month Wise Group</option>
                                            <option value="WG" {{old('reportid') == 'WG' ? 'selected' : ''}}>Without Group</option>

                                        </select>
                                    </div>
                                </div>
                            </div>


                        </div>

                        <!-- end col -->
                        <div class="row">
                            <div class="col-12 mt-10">
                                <button class="main-btn dark-btn rounded-full btn-hover btn-sm">
                                    Submit
                                </button>
                            </div>
                        </div>
                        <!-- end row -->
                    </form>

                </div>
            </div>
        </div>
        <span class="divider">
            <hr />
        </span>
        <div class="tables-wrapper" style="display:none;">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card-style mb-30">
                        <div id="responseMessage"></div>
                        <h4 class="mb-10">Revenue Report</h4>
                        <div class="table-wrapper table-responsive">
                            <table class="table" id="revenue-table">
                                <thead>
                                 
                                </thead>

                                <tbody class="text-center">

                                </tbody>


                            </table>
                            <!-- end table -->
                        </div>
                    </div>
                    <!-- end card -->
                </div>
                <!-- end col -->
            </div>
            <!-- end row -->
        </div>
    </div>
    <!-- end container -->
</section>
<!-- ========== section end ========== -->
@push('script')

<script>
    $(document).ready(function() {
        // Initialize the flag to false
        var isDataTableInitialized = false;

        $('#revenue-report-form').submit(function(e) {
            e.preventDefault();
            var formData = $(this).serialize();
            $.ajax({
                url: "{{ route('RevenueReportdetail') }}",
                type: "POST",
                data: formData,
                dataType: "json",
                success: function(response) {
                    // Clear previous data
                    $('#revenue-table tbody').empty();
                    // Append headers
                    var headersHtml = '';
                    $.each(response.headers, function(index, header) {
                        headersHtml += '<th class="text-uppercase text-center">' + header + '</th>';
                    });
                    $('#revenue-table thead').html('<tr>' + headersHtml + '</tr>');
                    // Append data based on report type
                    $.each(response.data, function(index, row) {
                        var rowHtml = '<tr>';
                        $.each(row, function(key, value) {
                            rowHtml += '<td>' + (value || '') + '</td>'; // Display empty string if value is undefined
                        });
                        rowHtml += '</tr>';
                        $('#revenue-table tbody').append(rowHtml);
                    });
                    // Show the table
                    $('.tables-wrapper').show();

                    // Initialize DataTable only if it's not already initialized
                    if (!isDataTableInitialized) {
                        $('#revenue-table').DataTable({
                            dom: 'Bfrtip',
                            buttons: ['csv', 'pdf', 'print']
                        });
                        // Set the flag to true after initialization
                        isDataTableInitialized = true;
                    }
                },
                error: function(xhr, status, error) {
                    console.error(xhr.responseText);
                }
            });
        });
    });
</script>





@endpush


<!-- <script>
    $(document).ready(function() {
        $('#revenue-report-form').submit(function(e) {
            e.preventDefault();
            var formData = $(this).serialize();
            $.ajax({
                url: "{{ route('RevenueReportdetail') }}",
                type: "POST",
                data: formData,
                dataType: "json",
                success: function(response) {
                    // Clear previous data
                    $('#revenue-table tbody').empty();
                    // Append headers
                    var headersHtml = '';
                    $.each(response.headers, function(index, header) {
                        headersHtml += '<th class="text-uppercase text-center">' + header + '</th>';
                    });
                    $('#revenue-table thead').html('<tr>' + headersHtml + '</tr>');
                    // Append data based on report type
                    $.each(response.data, function(index, row) {
                        var rowHtml = '<tr>';
                        $.each(row, function(key, value) {
                            rowHtml += '<td>' + (value || '') + '</td>'; // Display empty string if value is undefined
                        });
                        rowHtml += '</tr>';
                        $('#revenue-table tbody').append(rowHtml);
                    });
                    // Show the table
                    $('.tables-wrapper').show();
                },
                error: function(xhr, status, error) {
                    console.error(xhr.responseText);
                }
            });
        });
    });
</script> -->



@endsection