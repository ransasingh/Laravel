  <!-- ======== sidebar-nav start =========== -->
  <aside class="sidebar-nav-wrapper">
    <div class="navbar-logo">
      @if(auth()->check())
      @php
      $userRole = auth()->user()->RoleId;
      $dashboardRoute = ($userRole == 3) ? route('faculty.dashboard') : (($userRole == 4) ? route('student.dashboard') : route('dashboard'));
      @endphp
      <a href="{{ $dashboardRoute }}" class="dashboard-link">
        <img src="{{ $instituteLogoPath }}" alt="Institute Logo" width="60px">
      </a>
      @endif
    </div>


    <nav class="sidebar-nav">
      <ul id="sidebar-menu">
        @if(auth()->check())
        @php
        $userRole = auth()->user()->RoleId;
        @endphp
        <li class="nav-item">
          <a href="{{ $dashboardRoute }}" class="dashboard-link">
            <span class="icon">
              <i class="lni lni-dashboard"></i>
            </span>
            <span class="text">Dashboard</span>
          </a>
        </li>
        @if($userRole != 3 && $userRole != 4)
        <li class="nav-item nav-item-has-children">
          <a href="#0" class="collapsed" data-bs-toggle="collapse" data-bs-target="#ddmenu_2" aria-controls="ddmenu_2" aria-expanded="false" aria-label="Toggle navigation">
            <span class="icon">
              <i class=" lni lni-list"></i>
            </span>
            <span class="text">Masters</span>
          </a>
          <ul id="ddmenu_2" class="collapse dropdown-nav" style="list-style-type:circle;">
            <li class="nav-item">
              <a href="{{ route('institute.listing') }}"><span class="text">Institute</span></a>
            </li>

            <li class="nav-item">
              <a href="{{ route('institutebranch.listing') }}">
                <span class="text">Branch </span>
              </a>
            </li>
            <li class="nav-item">
              <a href="{{ route('academicyear.listing') }}">
                <span class="text">Academic Year</span>
              </a>
            </li>
            <li class="nav-item">
              <a href="{{ route('finacialyear.listing') }}">
                <span class="text">Financial Year</span>
              </a>
            </li>
            <li class="nav-item">
              <a href="{{ route('firm.listing') }}">
                <span class="text">Firm</span>
              </a>
            </li>
            <li class="nav-item">
              <a href="{{ route('feehead.listing') }}">
                <span class="text">Fee Head</span>
              </a>
            </li>
            <li class="nav-item">
              <a href="{{route('notifications.listing')}}">
                <span class="text">Notifications</span>
              </a>
            </li>
            <li class="nav-item">
              <a href="{{ route('users.listing') }}">
                <span class="text">Users</span>
              </a>
            </li>

            <li class="nav-item">
              <a href="{{ route('course.listing') }}">
                <span class="text">Course </span>
              </a>
            </li>
            <li class="nav-item">
              <a href="{{route('subject.listing')}}">
                <span class="text">Subject</span>
              </a>
            </li>
            <li class="nav-item">
              <a href="{{route('countries.listing')}}">
                <span class="text">Country Master</span>
              </a>
            </li>
            <li class="nav-item">
              <a href="{{route('states.listing')}}">
                <span class="text">State Master</span>
              </a>
            </li>
          </ul>
        </li>
        @endif
        <li class="nav-item nav-item-has-children">
          <a href="#0" class="collapsed" data-bs-toggle="collapse" data-bs-target="#ddmenu_3" aria-controls="ddmenu_3" aria-expanded="false" aria-label="Toggle navigation">
            <span class="icon">
              <i class=" lni lni-list"></i>
            </span>
            <span class="text">Transaction</span>
          </a>
          <ul id="ddmenu_3" class="collapse dropdown-nav" style="list-style-type:circle;">
            @if($userRole != 3 && $userRole != 4)
            <li class="nav-item">
              <a href="{{route('feestructure.listing')}}">
                <span class="text">FeeStructure</span>
              </a>
            </li>
            @endif
            @if($userRole != 3)
            <li class="nav-item">
              <a href="{{ $userRole == 4 ? route('student.show') : route('student.listing') }}">
                <span class="text">Student</span>
              </a>
            </li>
            @endif
            @if($userRole != 4)
            <li class="nav-item">
              <a href="{{ $userRole == 3 ? route('faculty.show') : route('faculty.listing') }}">
                <span class="text">Faculty</span>
              </a>
            </li>

            <li class="nav-item">
              <a href="{{route('batchextension.listing')}}">
                <span class="text">Batch Extension</span>
              </a>
            </li>

            <li class="nav-item">
              <a href="{{route('batchecompletion.listing')}}">
                <span class="text">Batch Completion</span>
              </a>
            </li>
            @endif
            @if($userRole != 3 && $userRole != 4)
            <li class="nav-item">
              <a href="{{route('batch.listing')}}">
                <span class="text">Batch Creation</span>
              </a>
            </li>
            <li class="nav-item">
              <a href="{{route('batchextensionapproval.listing')}}">
                <span class="text">Batch Extension Approval</span>
              </a>
            </li>
            <li class="nav-item">
              <a href="{{route('batchecompletionapproval.listing')}}">
                <span class="text">Batch Completed Approval</span>
              </a>
            </li>
            @endif
          </ul>
        </li>




        <!-- <li class="nav-item">
          <a href="{{ route('coursesubject.listing') }}">
            <span class="icon">
              <i class="lni lni-users"></i>
            </span>
            <span class="text">CourseSubject Master</span>
          </a>
        </li> -->



        <!-- <li class="nav-item">
          <a href="{{route('inquiry.listing')}}">
            <span class="icon">
              <i class="lni lni-map"></i>
            </span>
            <span class="text">Inquiry</span>
          </a>
        </li> -->

        <!-- <li class="nav-item">
          <a href="{{route('callstatuses.listing')}}">
            <span class="icon">
              <i class="lni lni-map"></i>
            </span>
            <span class="text">Callstatuses</span>
          </a>
        </li> -->
        <!-- <li class="nav-item">
          <a href="{{route('leadstatuses.listing')}}">
            <span class="icon">
              <i class="lni lni-map"></i>
            </span>
            <span class="text">Leadstatuses</span>
          </a>
        </li> -->

        @if($userRole != 3 && $userRole != 4)
        <li class="nav-item nav-item-has-children">
          <a href="#0" class="collapsed" data-bs-toggle="collapse" data-bs-target="#ddmenu_4" aria-controls="ddmenu_4" aria-expanded="false" aria-label="Toggle navigation">
            <span class="icon">
              <i class=" lni lni-list"></i>
            </span>
            <span class="text">Reports</span>
          </a>
          <ul id="ddmenu_4" class="collapse dropdown-nav" style="list-style-type:circle;">
            <li class="nav-item">
              <a href="{{route('studentattandancereport.listing')}}">
                <span class="text">Student Attandance Report</span>
              </a>
            </li>
            <li class="nav-item">
              <a href="{{route('StudentWithSubjectReport.listing')}}">
                <span class="text">Student With Subject Report</span>
              </a>
            </li>
            <li class="nav-item">
              <a href="{{route('StudentBatchReport.listing')}}">
                <span class="text">Student Batch Report</span>
              </a>
            </li>
            <li class="nav-item">
              <a href="{{route('StudentDetailReport.listing')}}">
                <span class="text">Student Detail Report</span>
              </a>
            </li>
            <li class="nav-item">
              <a href="{{route('FacultyDetailReport.listing')}}">
                <span class="text">Faculty Detail Report</span>
              </a>
            </li>
            <li class="nav-item">
              <a href="{{route('FacultyBatchReport.listing')}}">
                <span class="text">Faculty Batch Report</span>
              </a>
            </li>
            <li class="nav-item">
              <a href="{{route('RevenueReport.listing')}}">
                <span class="text">Revenue Report</span>
              </a>
            </li>
            <li class="nav-item">
              <a href="{{route('FacultyBatchTiming.listing')}}">
                <span class="text">Faculty Batch StartTime-EndTime</span>
              </a>
            </li>
            <li class="nav-item">
              <a href="{{route('BatchExtension.listing')}}">
                <span class="text">Batch Extension Report</span>
              </a>
            </li>
            <li class="nav-item">
              <a href="{{route('PortfolioSubmission.listing')}}">
                <span class="text">Portfolio Submission Report</span>
              </a>
            </li>
            <li class="nav-item">
              <a href="{{route('FacultyAttandanceCounter.listing')}}">
                <span class="text">Faculty Attandance Counter Report</span>
              </a>
            </li>
          </ul>
        </li>
        @endif
        @endif
      </ul>
    </nav>
  </aside>
  <div class="overlay"></div>

  <!-- ======== sidebar-nav end =========== -->

  @push('script')
  <script>
    $(document).ready(function() {
      // Function to clear stored active submenu
      function clearActiveSubMenu() {
        localStorage.removeItem('activeSubMenu');
      }

      // Check if any submenu was previously open and keep it open
      var activeSubMenu = localStorage.getItem('activeSubMenu');
      if (activeSubMenu) {
        $('#' + activeSubMenu).addClass('show');
      }

      // Save the state of the submenu in localStorage when a submenu is shown
      $('.sidebar-nav .collapse').on('show.bs.collapse', function() {
        var submenuId = $(this).attr('id');
        localStorage.setItem('activeSubMenu', submenuId);
      });

      // Event handler for navigating to dashboard or logging out
      $('.dashboard-link,.logout-link').on('click', function() {
        clearActiveSubMenu(); // Clear stored active submenu
      });

      // Event handler for collapsing "Masters" submenu and opening "Transaction" submenu
      $('.sidebar-nav .nav-item-has-children').on('click', function(e) {
        var $submenu = $(this).children('.collapse');
        if ($submenu.hasClass('show')) {
          $submenu.removeClass('show');
        }
      });
    });
  </script>
  @endpush