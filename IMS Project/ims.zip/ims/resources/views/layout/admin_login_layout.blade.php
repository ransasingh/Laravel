<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
    <meta http-equiv="Pragma" content="no-cache" />
    <meta http-equiv="Expires" content="0" />
    <link rel="shortcut icon" href="{{ $instituteLogoPath }}" type="image/x-icon" />
    <title>IMS : @yield('title')</title>

    <!-- ========== All CSS files linkup ========= -->
    <link rel="stylesheet" href="{{ url('assets/css/bootstrap.min.css')}}" />
    <link rel="stylesheet" href="{{ url('assets/css/main.css')}}" />
    <link rel="stylesheet" href="{{ url('assets/css/font-awesome.min.css')}}" />
    <link rel="stylesheet" href="{{ url('assets/css/custome.login.css')}}" />



</head>

<body>
    <!-- ======== Preloader =========== -->
    <div id="preloader">
        <div class="spinner"></div>
    </div>
    <!-- ======== Preloader =========== -->


    <!-- ======== main-wrapper start =========== -->
    <main class="main-wrapper">


        @yield('login')

    </main>
    <!-- ======== main-wrapper end =========== -->

    <!-- ========= All Javascript files linkup ======== -->
    <script src="{{ url('assets/js/bootstrap.bundle.min.js')}}"></script>
    <script src="{{ url('assets/js/main.js')}}"></script>
    <script src="{{ url('assets/js/jquery-3.7.1.min.js')}}"></script>



    @stack('script')
</body>

</html>