 <!-- ========== header start ========== -->
 <header class="header">
     <div class="container-fluid">
         <div class="row">
             <div class="col-lg-6 col-md-6 col-6">
                 <div class="header-left d-flex align-items-center">
                     <div class="menu-toggle-btn mr-15">
                         <button id="menu-toggle" class="main-btn light-btn rounded-full btn-hover">
                             <i class="lni lni-chevron-left me-2"></i>
                         </button>
                     </div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                     @unless(Route::currentRouteNamed('student.add.public'))
                     <form id="changeBranchForm" action="{{ route('changeBranch') }}" method="post" class="row g-2 align-items-center">
                         @csrf
                         <div class="col-auto">
                             <select class="form-select form-select-sm" style="display: none;" name="branch" id="branch" onchange="submitForm()">
                                 @foreach ($branches as $branch)
                                 @php
                                 $isLoggedIn = auth()->check();
                                 $hasRight = \DB::table('userbranchright')->where('UserId', auth()->id())->where('BranchId', $branch->id)->exists();
                                 $isSuperAdmin = auth()->user() && auth()->user()->RoleId == 1;
                                 @endphp
                                 <option value="{{ $branch->id }}" @if(session('BranchId')==$branch->id) selected @endif @if(!$isSuperAdmin && !$hasRight) disabled @endif>{{ $branch->Name }}</option>
                                 @endforeach
                             </select>
                         </div>
                         @if($isLoggedIn && $isSuperAdmin)
                         <div class="col-auto" style="display: none;">
                             <button type="submit" id="submitBtn" class="main-btn dark-btn rounded-full btn-hover  btn-xs">Change Branch</button>
                         </div>
                         @endif
                     </form>

                     @endunless
                 </div>
             </div>
             <script>
                 @unless(Route::currentRouteNamed('student.add.public'))

                 var isLoggedIn = "{{ $isLoggedIn ? 'true' : 'false' }}";
                 var isAllowedToSeeBranchData = "{{ $isSuperAdmin ? 'true' : 'false' }}"; // Super admin is always allowed to see branch data
                 var hasRight = "{{ $hasRight ? 'true' : 'false' }}"; // Pass the PHP boolean directly to JavaScript

                 // Attach event listener to the "Change Branch" button to submit the form
                 document.getElementById('submitBtn').addEventListener('click', function(event) {
                     event.preventDefault(); // Prevent the default form submission
                     submitForm(); // Submit the form
                 });

                 // Automatically submit the form if allowed
                 if ((isLoggedIn === 'true' && isAllowedToSeeBranchData === 'true' && hasRight) || (isLoggedIn === 'true' && "{{ session('BranchId') }}" === '1')) {
                     // Check if the form has already been submitted
                     if (!sessionStorage.getItem('formSubmitted')) {
                         submitForm();
                     }
                 }

                 function submitForm() {
                     sessionStorage.setItem('formSubmitted', 'true'); // Store in sessionStorage to prevent repeated submissions
                     document.getElementById('changeBranchForm').submit();
                 }
                 @endunless
             </script>



             <div class="col-lg-6 col-md-6 col-6">
                 <div class="header-right">
                     <!-- profile start -->
                     <div class="profile-box ml-15">
                         <button class="dropdown-toggle bg-transparent border-0" type="button" id="profile" data-bs-toggle="dropdown" aria-expanded="false">
                             <div class="profile-info">
                                 <div class="info">
                                     <div class="image">
                                         <img src="{{ $userimage }}" alt="Profile Image">
                                     </div>
                                     <div>
                                         @auth
                                         @php
                                         $userRoleId = auth()->user()->RoleId;
                                         $changepasswordRoute = ($userRoleId == 3) ? route('faculty.changepassword') : (($userRoleId == 4) ? route('student.changepassword') : route('superadmin.changepassword'));
                                         $role = DB::table('userrole')->find($userRoleId);
                                         $roleName = $role ? $role->RoleName : '';
                                         @endphp
                                         <h6 class="fw-500">{{ auth()->user()->name }}</h6>
                                         <p>{{ $roleName }}</p>
                                         @endauth
                                     </div>
                                 </div>
                             </div>
                         </button>
                         <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="profile">

                             <!-- <li>
                                 <a href="#0">
                                     <i class="lni lni-user"></i> View Profile
                                 </a>
                             </li>-->
                             <li>
                                 <a href="{{$changepasswordRoute}}"> <i class="lni lni-key"></i> Change Password </a>
                             </li>
                             <li class="divider"></li>
                             <li>
                                 <a href="{{route('adminlogout')}}"  class="logout-link"> <i class="lni lni-exit"></i> Sign Out </a>
                             </li>
                         </ul>
                     </div>
                     <!-- profile end -->
                 </div>
             </div>
         </div>
     </div>
 </header>
 <!-- ========== header end ========== -->