<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
    <meta http-equiv="Pragma" content="no-cache" />
    <meta http-equiv="Expires" content="0" />
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <!-- <link rel="shortcut icon" href="{{ url('assets/images/favicon.jpg')}}" type="image/x-icon" /> -->
    <link rel="shortcut icon" href="{{ $instituteLogoPath }}" type="image/x-icon" />

    <title>IMS : @yield('title')</title>
    <!-- ========== All CSS files linkup ========= -->
    <link rel="stylesheet" href="{{ url('assets/css/bootstrap.min.css')}}" />
    <link rel="stylesheet" href="{{ url('assets/css/main.css')}}" />
    <link rel="stylesheet" href="{{ url('assets/css/lineicons.css')}}" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="{{ url('assets/css/materialdesignicons.min.css')}}" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="{{ url('assets/css/font-awesome.min.css')}}" />
    <link rel="stylesheet" href="{{ url('assets/css/select2.min.css')}}" />
    <link rel="stylesheet" href="{{ url('assets/css/fullcalendar.css')}}" />
    @yield('css')
</head>

<body>
    <!-- ======== Preloader =========== -->
    <div id="preloader">
        <img src="{{ url('assets/images/loader.gif')}}" width="200px" alt="Loader Image">
        <!-- <div class="spinner"></div> -->
    </div>
    <!-- ======== Preloader =========== -->

    @include('layout.admin_sidebar')

    <!-- ======== main-wrapper start =========== -->
    <main class="main-wrapper">
        @include('layout.admin_header')

        @yield('dashboard')
        <!-- ========== footer start =========== -->
        <footer class="footer">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-6 order-last order-md-first">
                        <div class="copyright text-center text-md-start">
                            <p class="text-sm">
                                © Copyright 2024 by <a href="https://k2afuturetech.com" target="_blank" class="text-primary">K2A FutureTech Pvt Ltd. India</a>
                                <!-- <a href="https://plainadmin.com" rel="nofollow" target="_blank">
                                    PlainAdmin
                                </a> -->
                            </p>
                        </div>
                    </div>
                    <!-- end col-->
                    <!-- <div class="col-md-6">
                        <div class="terms d-flex justify-content-center justify-content-md-end">
                            <a href="#0" class="text-sm">Term & Conditions</a>
                            <a href="#0" class="text-sm ml-15">Privacy & Policy</a>
                        </div>
                    </div> -->
                </div>
                <!-- end row -->
            </div>
            <!-- end container -->
        </footer>
        <!-- ========== footer end =========== -->
    </main>
    <!-- ======== main-wrapper end =========== -->

    <!-- ========= All Javascript files linkup ======== -->
    <script src="{{ url('assets/js/jquery-3.7.1.min.js')}}"></script>
    <script src="{{ url('assets/js/bootstrap.bundle.min.js')}}"></script>
    <script src="{{ url('assets/js/select2.min.js')}}"></script>
    <script src="{{ url('assets/js/notify.min.js')}}"></script>
    <script src="{{ url('assets/js/main.js')}}"></script>
    <script src="{{ url('assets/js/fullcalendar.js')}}"></script>

    <script src="{{ url('assets/js/Chart.min.js')}}"></script>
    <script src="{{ url('assets/js/dynamic-pie-chart.js')}}"></script>
    <script src="{{ url('assets/js/moment.min.js')}}"></script>

    <!-- CKEditor in your HTML layout -->
    <script src="{{ url('assets/js/ckeditor.js')}}"></script>

    <!-- Include DataTables Buttons CSS and JS -->
    <link rel="stylesheet" href="{{ url('assets/css/dataTables.bootstrap5.min.css')}}" />
    <script src="{{ url('assets/js/jquery.dataTables.min.js')}}"></script>
    <script src="{{ url('assets/js/dataTables.bootstrap5.min.js')}}"></script>

    <!-- DataTables Buttons CSS and JS -->
    <link rel="stylesheet" href="{{ url('assets/css/buttons.dataTables.min.css')}}" />
    <script src="{{ url('assets/js/dataTables.buttons.min.js')}}"></script>
    <script src="{{ url('assets/js/buttons.html5.min.js')}}"></script>
    <script src="{{ url('assets/js/buttons.print.min.js')}}"></script>
    <script src="{{ url('assets/js/pdfmake.min.js')}}"></script>
    <script src="{{ url('assets/js/vfs_fonts.js')}}"></script>
    <script src="{{ url('assets/js/buttons.colVis.min.js')}}"></script>



    <script>
        $(function() {
            $("#data-table").DataTable({
                "responsive": true,
                dom: 'Bfrtip',
                lengthMenu: [
                    [10, 25, 50, -1],
                    ['10 rows', '25 rows', '50 rows', 'Show all']
                ],
                "autoWidth": true,
                "paging": true,
                buttons: [
                    'pageLength',
                    {
                        extend: 'csv',
                        exportOptions: {
                            columns: ':not(.print-hidden)'

                        }
                    },
                    {
                        extend: 'print',
                        exportOptions: {
                            columns: ':not(.print-hidden)'
                        },
                        customize: function(win) {
                            // Set page size and margins
                            $(win.document.body).css('font-size', '10pt');
                            $(win.document.body).find('table').addClass('compact').css('font-size', 'inherit');
                            $(win.document.body).find('h1').css('font-size', '15pt');

                            // Adjust page margins
                            win.document.title = 'Print';
                            $(win.document.body).css('margin', '0');
                            $(win.document.body).find('table').css('margin', '0');
                        }
                    },
                    {
                        extend: 'pdf',
                        exportOptions: {
                            columns: ':not(.print-hidden)'
                        },
                        customize: function(doc) {
                            // Set margins
                            doc.pageMargins = [10, 10, 10, 10]; // [left, top, right, bottom]
                            doc.defaultStyle.fontSize = 8;
                        }
                    }
                ],
                responsive: {
                    details: {
                        type: 'column',
                        target: 'tr'
                    }
                },
                columnDefs: [{
                    className: 'mgcontrol',
                    orderable: true,
                    targets: 0
                }],
            }).buttons().container().appendTo('#data-table_wrapper .col-md-6:eq(0)');
        });
    </script>


    @stack('script')
</body>

</html>