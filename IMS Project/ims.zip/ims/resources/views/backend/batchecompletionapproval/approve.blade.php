@extends('layout.admin_layout')
@section('title', 'Batch Completion Details')
@section('dashboard')

<!-- ========== table components start ========== -->
<section class="table-components">
    <div class="container-fluid">

    @if(session('error'))
        <div class="alert alert-danger alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('error') }}
        </div>
        @endif

        @if(session('success'))
        <div class="alert alert-success alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('success') }}
        </div>
        @endif


        <!-- ========== title-wrapper start ========== -->
        <div class="title-wrapper pt-30">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <div class="title">
                        <h2>Batch Completion Details</h2>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="breadcrumb-wrapper">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a href="{{URL::previous();}}" class="main-btn active-btn-light rounded-full btn-hover btn-sm">
                                        <i class="lni lni-arrow-left"></i>
                                        Back
                                    </a>
                                </li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
            <!-- end row -->
        </div>
        <!-- ========== title-wrapper end ========== -->

        <!-- ========== tables-wrapper start ========== -->
        <div class="tables-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card-style mb-30">
                        <div class="table-wrapper table-responsive">
                            <form action="{{ route('batchecompletionapproval.editnew',['id' =>$data->id]) }}" method="POST" id="data-form">
                                @csrf
                                <table class="table custom-table " id="data-table">
                                    <thead>
                                        <tr class="text-sm">
                                            <th class="text-uppercase">#</th>
                                            <th class="text-uppercase">Student Name</th>
                                            <th class="text-uppercase">Subject</th>
                                            <th class="text-uppercase">Course</th>
                                            <th class="text-uppercase">Attendance</th>
                                            <th class="text-uppercase">Total Sessions</th>
                                        </tr>
                                        <!-- end table row-->
                                    </thead>
                                    <tbody>
                                        @if (isset($students))
                                        @foreach ($students as $student)
                                        <tr>
                                            <th scope="row" class="text-sm">{{ $loop->index + 1 }}</th>
                                            <td class="min-width text-sm">{{ $student->FirstName }} {{ $student->LastName }}</td>
                                            <td class="min-width text-sm">
                                                @if (isset($batchDetails))
                                                @foreach($batchDetails as $batchDetail)
                                                @if($batchDetail->BatchId == $student->BatchDetailId)
                                                {{ $batchDetail->subject_name }}
                                                @endif
                                                @endforeach
                                                @endif
                                            </td>
                                            <td class="min-width text-sm">{{ $student->course_name }}</td>
                                            <td class="min-width text-sm">
                                                @if (isset($attendanceCounts))
                                                @foreach($attendanceCounts as $attendanceCount)
                                                @if($attendanceCount->StudentId == $student->id)
                                                {{ $attendanceCount->attendance_count }}
                                                @endif
                                                @endforeach
                                                @endif
                                            </td>
                                            <td class="min-width text-sm">
                                                @if (isset($batchDetails))
                                                @foreach($batchDetails as $batchDetail)
                                                @if($batchDetail->BatchId == $student->BatchDetailId)
                                                {{ $batchDetail->NoOfSession }}
                                                @endif
                                                @endforeach
                                                @endif
                                            </td>
                                            <input type="hidden" name="selectedStudents[]" value="{{ $student->id }}">
                                        </tr>
                                        @endforeach
                                        @endif
                                    </tbody>
                                </table>
                                <button type="submit" name="action" value="approve" class="main-btn dark-btn rounded-full btn-hover btn-sm">
                                    Approve
                                </button>
                                <button type="submit" name="action" value="reject" onclick="return confirm('Are you sure reject?')" class="main-btn danger-btn rounded-full btn-hover btn-sm">
                                    Reject
                                </button>
                            </form> <!-- end table -->
                        </div>
                    </div>
                    <!-- end card -->
                </div>
                <!-- end col -->
            </div>
            <!-- end row -->
        </div>
        <!-- ========== tables-wrapper end ========== -->
    </div>
    <!-- end container -->
</section>
<!-- ========== table components end ========== -->

@endsection