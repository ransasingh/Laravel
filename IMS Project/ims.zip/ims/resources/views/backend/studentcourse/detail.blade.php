@extends('layout.admin_layout')
@section('title', 'Student')
@section('dashboard')
<!-- ========== section start ========== -->
<section class="section">
    <div class="container-fluid">

    @if(session('error'))
    <div class="alert alert-danger alert-dismissible mt-20 fade show alert-sm" role="alert">
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        {{ session('error') }}
    </div>
    @endif

    @if(session('success'))
    <div class="alert alert-success alert-dismissible mt-20 fade show alert-sm" role="alert">
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        {{ session('success') }}
    </div>
    @endif


        <!-- ========== title-wrapper start ========== -->
        <div class="title-wrapper pt-30">
            <div class="row align-items-center">
                <div class="col-md-9">
                    <div class="title">
                        <h2>Update Student</h2>
                    </div>
                    <ul class="nav nav-tabs" id="myTabs">
                        <li class="nav-item">
                            <a class="nav-link{{ request()->is('student/show*') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('student.show',['id' => request('id')]) }}">Student Info</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link{{ request()->is('studentcourse/detail*') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('studentcourse.detail',['id' => request('id')]) }}">Course Details</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link{{ request()->is('feereceipt/detail*') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('feereceipt.detail',['id' => request('id')]) }}">Fee Details</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link{{ request()->is('student/calender*') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('student.calender',['id' => request('id')]) }}">Calender</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link{{ request()->routeIs('student.PortfolioSubmission') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('student.PortfolioSubmission',['id' => request('id')]) }}">Portfolio Submission</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link{{ request()->routeIs('student.batchcompletion') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('student.batchcompletion',['id' => request('id')]) }}">Batch Completion</a>
                        </li>
                    </ul>
                </div>

            </div>
            <!-- end row -->
        </div>
        <div class="row g-0 auth-row">
            <div class="tables-wrapper">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card-style mb-30">
                            <div class="table-wrapper table-responsive">
                                <table class="table" id="data-table">
                                    <thead>
                                    <tr class="text-sm">
                                            <th class="text-uppercase">#</th>
                                            <th class="text-uppercase">Subject</th>
                                            <th class="text-uppercase">Academic Year</th>
                                            <th class="text-uppercase">Is Extra Subject</th>
                                            <th class="text-uppercase">Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @if (isset($data))
                                        @foreach ($data as $record)
                                        <tr>
                                            <th scope="row" class="text-sm">{{ $loop->index + 1 }}</th>
                                            <td class="min-width text-sm">{{$record->subject_name }}</td>
                                            <td class="min-width text-sm">{{$record->AcademicYearId }}</td>
                                            <td class="min-width text-sm">
                                                @if($record->IsExraSubject == 1)
                                                <span class="status-btn active-btn" title="Active">Yes</span>
                                                @else
                                                <span class="status-btn close-btn" title="Inactive">No</span>
                                                @endif
                                            </td>
                                            <td class="min-width text-sm">
                                                @if($record->IsActive == 1)
                                                <span class="status-btn active-btn" title="Active">Active</span>
                                                @else
                                                <span class="status-btn close-btn" title="Inactive">Inactive</span>
                                                @endif
                                            </td>
                                        </tr>
                                        @endforeach
                                        @endif
                                    </tbody>
                                </table>
                                <!-- end table -->
                            </div>
                        </div>
                        <!-- end card -->
                    </div>
                    <!-- end col -->
                </div>
                <!-- end row -->
            </div>
        </div>

    </div>
    <!-- end container -->
</section>
<!-- ========== section end ========== -->

@endsection