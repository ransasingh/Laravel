@extends('layout.admin_layout')
@section('title', 'Institute Branch Add')
@section('dashboard')
<!-- ========== section start ========== -->
<section class="section">
    <div class="container-fluid">

    @if(session('error'))
        <div class="alert alert-danger alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('error') }}
        </div>
        @endif

        @if(session('success'))
        <div class="alert alert-success alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('success') }}
        </div>
        @endif


        <!-- ========== title-wrapper start ========== -->
        <div class="title-wrapper pt-30">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <div class="title">
                        <h2>Add Institute Branch</h2>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="breadcrumb-wrapper">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a href="{{route('institutebranch.listing')}}" class="main-btn active-btn-light rounded-full btn-hover btn-sm">
                                        <i class="lni lni-arrow-left"></i>
                                        All Institute Branch
                                    </a>
                                </li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
            <!-- end row -->
        </div>
        <div class="row g-0 auth-row">
            <!-- end col -->
            <div class="col-md-12">
                <div class="signup-wrapper">
                    <div class="form-wrapper">
                        <form action="{{ route('institutebranch.addnew') }}" method="post">
                            @csrf
                            <div class="row">
                                <div class="col-md-4 col-xs-12">
                                    <div class="input-style-1">
                                        <label for="Name" class="compulsory">Name </label>
                                        <input type="text" name="Name" id="Name" value="{{ old('Name') }}" />
                                        @error('Name')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                                <div class="col-md-4 col-xs-12">
                                    <div class="input-style-1">
                                        <label for="BranchCode" class="compulsory">Branch Code </label>
                                        <input type="tel" name="BranchCode" id="BranchCode" value="{{ old('BranchCode') }}" />
                                        @error('BranchCode')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                                <div class="col-md-4 col-xs-12">
                                    <div class="select-style-1">
                                        <label for="InstituteId" class="compulsory">Institute</label>
                                        <div class="select-position">
                                            <select name="InstituteId" id="InstituteId">
                                                <option selected disabled>Please select Institute</option>
                                                @if (isset($institutes))
                                                @foreach ($institutes as $institute)
                                                <option value="{{$institute->id}}" {{old('InstituteId') == $institute->id ? 'selected' : '' }}>{{$institute->Name}}</option>
                                                @endforeach
                                                @endif
                                            </select>
                                        </div>
                                        @error('InstituteId')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4 col-xs-12">
                                    <div class="input-style-1">
                                        <label for="MobileNumber" class="compulsory">Mobile Number</label>
                                        <input type="tel" name="MobileNumber" id="MobileNumber" minlength="10" maxlength="10" value="{{ old('MobileNumber') }}" />
                                        @error('MobileNumber')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                                <div class="col-md-4 col-xs-12">
                                    <div class="input-style-1">
                                        <label for="EmailId" class="compulsory">Email</label>
                                        <input type="email" name="EmailId" id="EmailId" value="{{ old('EmailId') }}" />
                                        @error('EmailId')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                                <div class="col-md-4 col-xs-12">
                                    <div class="input-style-1">
                                        <label for="Website">Website</label>
                                        <input type="text" name="Website" id="Website" value="{{ old('Website') }}" />
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4 col-xs-12">
                                    <div class="input-style-1">
                                        <label for="AddressLine1" class="compulsory">Address Line1</label>
                                        <textarea name="AddressLine1" id="AddressLine1" cols="30" rows="1">{{ old('AddressLine1') }}</textarea>
                                        @error('AddressLine1')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                                <div class="col-md-4 col-xs-12">
                                    <div class="input-style-1">
                                        <label for="AddressLine2">Address Line2</label>
                                        <textarea name="AddressLine2" id="AddressLine2" cols="30" rows="1">{{ old('AddressLine2') }}</textarea>
                                    </div>
                                </div>
                                <div class="col-md-4 col-xs-12">
                                    <div class="select-style-1">
                                        <label for="StateId" class="compulsory">State</label>
                                        <div class="select-position">
                                            <select name="StateId" id="StateId">
                                                <option selected disabled>Please select State</option>
                                                @if (isset($states))
                                                @foreach ($states as $state)
                                                <option value="{{$state->id}}" {{old('StateId') == $state->id ? 'selected' : '' }}>{{$state->Name}}</option>
                                                @endforeach
                                                @endif
                                            </select>
                                        </div>
                                        @error('StateId')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4 col-xs-12">
                                    <div class="input-style-1">
                                        <label for="CityName" class="compulsory">City Name</label>
                                        <input type="text" name="CityName" id="CityName" value="{{ old('CityName') }}" />
                                        @error('CityName')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                                <div class="col-md-4 col-xs-12">
                                    <div class="input-style-1">
                                        <label for="PostalCode" class="compulsory">Postal Code</label>
                                        <input type="text" name="PostalCode" id="PostalCode" value="{{ old('PostalCode') }}" />
                                        @error('PostalCode')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                                <div class="col-md-4 col-xs-12">
                                    <div class="select-style-1">
                                        <label for="IsActive" class="compulsory">Status</label>
                                        <div class="select-position">
                                            <select name="IsActive" id="IsActive">
                                                <option value="1" selected>Active</option>
                                                <option value="0">Inactive</option>
                                            </select>
                                        </div>
                                        @error('IsActive')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <!-- end col -->

                                <div class="col-12">
                                    <button class="main-btn dark-btn rounded-full btn-hover btn-sm">
                                        Submit
                                    </button>
                                </div>
                            </div>
                            <!-- end row -->
                        </form>

                    </div>
                </div>
            </div>
            <!-- end col -->
        </div>

    </div>
    <!-- end container -->
</section>
<!-- ========== section end ========== -->

@endsection