@extends('layout.admin_layout')
@section('title', 'Batch Extension Approval Listing')
@section('dashboard')

<!-- ========== table components start ========== -->
<section class="table-components">
    <div class="container-fluid">

    @if(session('error'))
        <div class="alert alert-danger alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('error') }}
        </div>
        @endif

        @if(session('success'))
        <div class="alert alert-success alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('success') }}
        </div>
        @endif


        <!-- ========== title-wrapper start ========== -->
        <div class="title-wrapper pt-30">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <div class="title">
                        <h2>Batch Extension Approval</h2>
                    </div>
                </div>

            </div>
            <!-- end row -->
        </div>
        <!-- ========== title-wrapper end ========== -->

        <!-- ========== tables-wrapper start ========== -->
        <div class="tables-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card-style mb-30">
                        <div class="table-wrapper table-responsive">
                            <table class="table" id="data-table">
                                <thead>
                                    <tr class="text-sm">
                                        <th class="text-uppercase">#</th>
                                        <th class="text-uppercase">Batch Name</th>
                                        <th class="text-uppercase">Faculty name</th>
                                        <th class="text-uppercase">From Date</th>
                                        <th class="text-uppercase">TO Date</th>
                                        <th class="text-uppercase">Start Time</th>
                                        <th class="text-uppercase">End Time</th>
                                        <th class="text-uppercase">Student capacity</th>
                                        <th class="text-uppercase">Is Completed</th>
                                        <th class="text-uppercase">Status</th>
                                        <th class="text-uppercase text-sm">New Requested Date</th>
                                        <th class="text-uppercase text-sm">Remarks</th>
                                        <th class="text-uppercase print-hidden">Action</th>
                                    </tr>
                                    <!-- end table row-->
                                </thead>
                                <tbody>
                                    @if (isset($data))
                                    @foreach ($data as $record)
                                    <tr>
                                        <th scope="row" class="text-sm">{{ $loop->index + 1 }}</th>
                                        <td class="min-width text-sm">{{$record->Name }}</td>
                                        <td class="min-width text-sm">{{$record->FirstName." ".$record->LastName }}</td>
                                        <td class="min-width text-sm">{{date('d-M-y',strtotime($record->FromDate))}}</td>
                                        <td class="min-width text-sm">{{date('d-M-y',strtotime($record->ToDate))}}</td>
                                        <td class="min-width text-sm">{{$record->StartTimeInMinutes }}</td>
                                        <td class="min-width text-sm">{{$record->EndTimeInMinutes }}</td>
                                        <td class="min-width text-sm">{{$record->StudentCapacity }}</td>
                                        <td class="min-width text-sm">
                                            @if($record->IsCompleted == 1)
                                            <span class="status-btn active-btn">Yes</span>
                                            @else
                                            <span class="status-btn close-btn">No</span>
                                            @endif
                                        </td>
                                        <td class="min-width text-sm">
                                            @if($record->IsActive == 1)
                                            <span class="status-btn active-btn" title="Active">Active</span>
                                            @else
                                            <span class="status-btn close-btn" title="Inactive">Inactive</span>
                                            @endif
                                        </td>
                                        <td class="min-width text-sm">{{date('d-M-y',strtotime($record->NewDate))}}</td>
                                        <td class="min-width text-sm">{{$record->Remarks }}</td>
                                        <td>
                                            <div class="action">
                                                <a href="{{ route('batchextensionapproval.approve',['id'=>$record->id ]) }}" class="text-primary" onclick="return confirm('Are you sure Approve?')" title="Approve"><i class="lni lni-checkmark-circle"></i></a>
                                                <a href="{{ route('batchextensionapproval.cancel',['id'=>$record->id ]) }}" class="text-danger" onclick="return confirm('Are you sure Cancel?')" title="Cancel "><i class="lni lni-close"></i></a>
                                            </div>
                                        </td>
                                    </tr>
                                    @endforeach
                                    @endif
                                </tbody>
                            </table>
                            <!-- end table -->
                        </div>
                    </div>
                    <!-- end card -->
                </div>
                <!-- end col -->
            </div>
            <!-- end row -->
        </div>
        <!-- ========== tables-wrapper end ========== -->
    </div>
    <!-- end container -->
</section>
<!-- ========== table components end ========== -->



@endsection