@extends('layout.admin_layout')
@section('title', 'FeeStructure Add')
@section('dashboard')
<!-- ========== section start ========== -->
<section class="section">
    <div class="container-fluid">

    @if(session('error'))
        <div class="alert alert-danger alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('error') }}
        </div>
        @endif

        @if(session('success'))
        <div class="alert alert-success alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('success') }}
        </div>
        @endif

        <!-- ========== title-wrapper start ========== -->
        <div class="title-wrapper pt-30">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <div class="title">
                        <h2>Add FeeStructure</h2>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="breadcrumb-wrapper">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a href="{{route('feestructure.listing')}}" class="main-btn active-btn-light rounded-full btn-hover btn-sm">
                                        <i class="lni lni-arrow-left"></i>
                                        All FeeStructure
                                    </a>
                                </li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
            <!-- end row -->
        </div>
        <div class="row g-0 auth-row">
            <!-- end col -->
            <div class="col-md-12">
                <div class="signup-wrapper">
                    <div class="form-wrapper">
                        <form action="{{ route('feestructure.addnew') }}" method="post">
                            @csrf
                            <div class="row">
                                <div class="col-md-6 col-xs-12">
                                    <div class="input-style-1">
                                        <label for="Name" class="compulsory">Structure Name </label>
                                        <input type="text" name="Name" id="Name" value="{{ old('Name') }}" placeholder="Enter Name" />
                                        <input type="hidden" name="AcademicYearId" value="{{$academicsName}}">
                                        @error('Name')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                                <div class="col-md-6 col-xs-12">
                                    <div class="input-style-1">
                                        <label for="EffectiveDate" class="compulsory">Effective Date </label>
                                        <input type="date" name="EffectiveDate" id="EffectiveDate" value="{{ old('EffectiveDate') }}" />
                                        @error('EffectiveDate')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 col-xs-12">
                                    <div class="select-style-1">
                                        <label for="CourseId" class="compulsory">Course</label>
                                        <div class="select-position">
                                            <select name="CourseId" id="CourseId">
                                                <option selected disabled>Please select course</option>
                                                @if (isset($courses))
                                                @foreach ($courses as $course)
                                                <option value="{{$course->id}}" {{old('CourseId') == $course->id ? 'selected' : '' }}>{{$course->Name}}</option>
                                                @endforeach
                                                @endif
                                            </select>
                                        </div>
                                        @error('CourseId')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                                <div class="col-md-6 col-xs-12">
                                    <div class="select-style-1">
                                        <label for="IsActive" class="compulsory">Status</label>
                                        <div class="select-position">
                                            <select name="IsActive" id="IsActive">
                                                <option value="1" selected>Active</option>
                                                <option value="0">Inactive</option>
                                            </select>
                                        </div>
                                        @error('IsActive')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <!-- end col -->

                                <div class="col-12">
                                    <button class="main-btn dark-btn rounded-full btn-hover btn-sm">
                                        Submit
                                    </button>
                                </div>
                            </div>
                            <!-- end row -->
                        </form>

                    </div>
                </div>
            </div>
            <!-- end col -->
        </div>

    </div>
    <!-- end container -->
</section>
<!-- ========== section end ========== -->

@endsection