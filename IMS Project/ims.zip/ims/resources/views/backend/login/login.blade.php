@extends('layout.admin_login_layout')
@section('title', 'Login')
@section('login')
<div class="loginbox"><img src="{{ $instituteLogoPath }}" alt="Institute Logo" class="avatar">
    <h1>Sign In </h1>
    @if($errors->any())
    <div class="alert alert-danger alert-dismissible mt-20 fade show alert-sm" role="alert">
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        <ul>
            @foreach($errors->all() as $error)
            <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
    @endif

    @if(session('error'))
    <div class="alert alert-danger alert-dismissible mt-20 fade show alert-sm" role="alert">
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        {{ session('error') }}
    </div>
    @endif

    @if(session('success'))
    <div class="alert alert-success alert-dismissible mt-20 fade show alert-sm" role="alert">
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        {{ session('success') }}
    </div>
    @endif

    <form method="post" action="{{ route('user.admin') }}">
        @csrf
        <label class="login" for="email">Username</label>
        <input type="text" name="email" id="email" placeholder="Enter Username" value="{{old('email')}}" autofocus>
        <label class="login" for="password">Password</label><span toggle="#password" class="eye-icon toggle-password"></span>
        <input type="password" name="password" id="password" placeholder="Enter Password" autofocus>  
      

        <label for="remember">Remember Me <span><input type="checkbox" name="remember" id="remember"></span></label>


        <input type="submit" value="Login">
        <a href="#">Forgot password?</a><br>
    </form>
</div>

@push('script')
<script>
    $(document).ready(function() {
        setTimeout(function() {
            $(".alert").alert("close");
        }, 5000);
    });
    document.addEventListener("DOMContentLoaded", function() {
        var passwordInput = document.getElementById("password");
        var eyeIcon = document.querySelector(".eye-icon");

        eyeIcon.addEventListener("click", function() {
            eyeIcon.classList.toggle("visible");

            if (passwordInput.type === "password") {
                passwordInput.type = "text";
            } else {
                passwordInput.type = "password";
            }
        });

        // Check if password field is visible and adjust eye icon
        if (passwordInput.type === "text") {
            eyeIcon.classList.add("visible");
        }
    });
</script>
@endpush
@endsection