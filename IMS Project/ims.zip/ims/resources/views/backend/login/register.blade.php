@extends('layout.admin_login_layout')

@section('login')
<div class="loginbox"> <img src="{{ url('assets/images/logo.png')}}" class="avatar">
    <h1>Sign Up </h1>
    @if($errors->any())
    <div class="alert alert-danger alert-dismissible fade show alert-sm" role="alert">
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        <ul>
            @foreach($errors->all() as $error)
            <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
    @endif

    @if(session('error'))
    <div class="alert alert-danger alert-dismissible fade show alert-sm" role="alert">
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        {{ session('error') }}
    </div>
    @endif

    @if(session('success'))
    <div class="alert alert-success alert-dismissible fade show alert-sm" role="alert">
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        {{ session('success') }}
    </div>
    @endif


    <form method="post" action="{{ route('user.add') }}">
        @csrf
        <label class="login" for="name">Name</label>
        <input type="text" name="name" id="name" value="{{ old('name') }}" placeholder="Enter Name">
        <label class="login" for="email">Email</label>
        <input type="text" name="email" id="email" value="{{ old('email') }}" placeholder="Enter Email">
        <label class="login" for="password">Password</label>
        <input type="password" name="password" id="password" placeholder="Enter Password">
        <input type="submit" value="Register">
        <a href="{{ route('login') }}" class="text-md-end">Click here to Login</a>
    </form>

</div>

@endsection