@extends('layout.admin_layout')
@section('title', 'Firm Edit')
@section('dashboard')
<!-- ========== section start ========== -->
<section class="section">
    <div class="container-fluid">

    @if(session('error'))
        <div class="alert alert-danger alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('error') }}
        </div>
        @endif

        @if(session('success'))
        <div class="alert alert-success alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('success') }}
        </div>
        @endif


        <!-- ========== title-wrapper start ========== -->
        <div class="title-wrapper pt-30">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <div class="title">
                        <h2>Update Firm</h2>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="breadcrumb-wrapper">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a href="{{route('firm.listing')}}" class="main-btn active-btn-light rounded-full btn-hover btn-sm">
                                        <i class="lni lni-arrow-left"></i>
                                        All Firms
                                    </a>
                                </li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
            <!-- end row -->
        </div>
        <div class="row g-0 auth-row">
            <!-- end col -->
            <div class="col-md-12">
                <div class="signup-wrapper">
                    <div class="form-wrapper">
                        <form action="{{ route('firm.editfirm',['id' =>$data->id]) }}" method="post" enctype="multipart/form-data">
                            @csrf
                            <div class="row">
                                <div class="col-md-4 col-xs-12">
                                    <div class="input-style-1">
                                        <label for="Name" class="compulsory">Name </label>
                                        <input type="text" name="Name" id="Name" value="{{$data->Name}}" placeholder="Enter Name" />
                                        <input type="hidden" name="InstituteId" value="{{$data->institutesid}}">
                                        @error('Name')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                                <div class="col-md-4 col-xs-12">
                                    <div class="input-style-1">
                                        <label for="Code" class="compulsory">Code</label>
                                        <input type="tel" name="Code" id="Code" value="{{$data->Code}}" placeholder="Enter Code" />
                                        @error('Code')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                                <div class="col-md-4 col-xs-12">
                                    <div class="input-style-1">
                                        <label for="BankName">Bank Name</label>
                                        <input type="text" name="BankName" id="BankName" value="{{$data->BankName}}" placeholder="Enter Bank Name" />
                                        @error('BankName')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4 col-xs-12">
                                    <div class="input-style-1">
                                        <label for="AccountNumber">Account Number</label>
                                        <input type="text" name="AccountNumber" id="AccountNumber" value="{{$data->AccountNumber}}" placeholder="Enter Account Number" />
                                        @error('AccountNumber')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                                <div class="col-md-4 col-xs-12">
                                    <div class="input-style-1">
                                        <label for="IfscCode">Ifsc Code</label>
                                        <input type="text" name="IfscCode" id="IfscCode" value="{{$data->IfscCode}}" placeholder="Enter IfscCode" />
                                        @error('IfscCode')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                                <div class="col-md-4 col-xs-12">
                                    <div class="input-style-1">
                                        <label for="Branch">Branch</label>
                                        <input type="text" name="Branch" id="Branch" value="{{$data->Branch}}" placeholder="Enter Branch" />
                                        @error('Branch')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>

                            </div>

                            <div class="row">
                                <div class="col-md-4 col-xs-12">
                                    <div class="input-style-1">
                                    @if($data->UpiQrCode  != null)
                                        <label>UpiQr Code</label>
                                        <!-- Display image preview -->
                                        <a href="{{ url('uploads/UpiQrCode/' . $data->UpiQrCode) }}" target="_blank">
                                            <img src="{{ url('uploads/UpiQrCode/' . $data->UpiQrCode) }}" alt="UpiQr Code" width="90px">
                                        </a>
                                        <a class="main-btn danger-btn-light rounded-full btn-hover btn-sm" href="{{ url('firm/deleteimage/' . $data->id . '?imageType=UpiQrCode') }}" onclick="return confirm('Are you sure?');"> Remove </a>
                                        @else
                                        <label for="UpiQrCode">UpiQr Code</label>
                                        <input class="form-control" type="file" name="UpiQrCode" id="UpiQrCode" onchange="previewImage('UpiQrCode', 'preview_UpiQrCode')" accept="image/*">
                                        <img id="preview_UpiQrCode" src="#" alt="Visiting Card" style="display:none;" width="80px">
                                        @error('UpiQrCode')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                        @endif
                                    </div>
                                </div>
                                <div class="col-md-4 col-xs-12">
                                    <div class="select-style-1">
                                        <label for="IsActive" class="compulsory">Status</label>
                                        <div class="select-position">
                                        <select name="IsActive" id="IsActive">
                                                <option value="1" {{$data->IsActive == '1'?'selected':''}}>Active</option>
                                                <option value="0" {{$data->IsActive == '0'?'selected':''}}>Inactive</option>
                                            </select>
                                        </div>
                                        @error('IsActive')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                                <!-- end col -->

                                <div class="col-12">
                                    <button class="main-btn dark-btn rounded-full btn-hover btn-sm">
                                        Update
                                    </button>
                                </div>
                            </div>
                            <!-- end row -->
                        </form>

                    </div>
                </div>
            </div>
            <!-- end col -->
        </div>

    </div>
    <!-- end container -->
</section>
<!-- ========== section end ========== -->
@push('script')
<script src="{{ url('assets/js/custom/custom.js')}}"></script>
@endpush

@endsection