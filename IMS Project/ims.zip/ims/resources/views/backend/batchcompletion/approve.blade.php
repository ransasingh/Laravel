@extends('layout.admin_layout')
@section('title', 'Batch Completion Details')
@section('dashboard')

<!-- ========== table components start ========== -->
<section class="table-components">
    <div class="container-fluid">

        @if(session('error'))
        <div class="alert alert-danger alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('error') }}
        </div>
        @endif

        @if(session('success'))
        <div class="alert alert-success alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('success') }}
        </div>
        @endif


        <!-- ========== title-wrapper start ========== -->
        <div class="title-wrapper pt-30">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <div class="title">
                        <h2>Batch Completion Details</h2>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="breadcrumb-wrapper">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a href="{{URL::previous();}}" class="main-btn active-btn-light rounded-full btn-hover btn-sm">
                                        <i class="lni lni-arrow-left"></i>
                                        Back
                                    </a>
                                </li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
            <!-- end row -->
        </div>
        <!-- ========== title-wrapper end ========== -->

        <!-- ========== tables-wrapper start ========== -->
        <div class="tables-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card-style mb-30">
                        <div class="table-wrapper table-responsive">
                            <form action="{{ route('batchecompletion.addnew',['id' =>$data->id]) }}" method="POST" id="data-form">
                                @csrf
                                <table class="table custom-table " id="data-table">
                                    <thead>
                                        <tr class="text-sm">
                                            @if ($data->IsApproved == 0)
                                            <th class="text-uppercase">
                                                <label for="selectall">
                                                    <input type="checkbox" class="form-check-input" id="selectall"> Select All
                                                </label>
                                            </th>
                                            @endif
                                            <th class="text-uppercase">Student Name</th>
                                            <th class="text-uppercase">Subject</th>
                                            <th class="text-uppercase">Course</th>
                                            <th class="text-uppercase">Attendance</th>
                                            <th class="text-uppercase">Total Sessions</th>
                                        </tr>
                                        <!-- end table row-->
                                    </thead>
                                    <tbody>
                                        @if (isset($students))
                                        @foreach ($students as $student)
                                        <tr>
                                            @if ($data->IsApproved == 0)
                                            <th scope="row" class="text-sm"><input class="form-check-input" type="checkbox" name="selectedStudents[]" value="{{ $student->id }}"></th>
                                            @endif
                                            <td class="min-width text-sm">{{ $student->FirstName }} {{ $student->LastName }}</td>
                                            <td class="min-width text-sm">
                                                @if (isset($batchDetails))
                                                @foreach($batchDetails as $batchDetail)
                                                @if($batchDetail->BatchId == $student->BatchDetailId)
                                                {{ $batchDetail->subject_name }}
                                                @endif
                                                @endforeach
                                                @endif
                                            </td>
                                            <td class="min-width text-sm">{{ $student->course_name }}</td>
                                            <td class="min-width text-sm">
                                                @if (isset($attendanceCounts))
                                                @foreach($attendanceCounts as $attendanceCount)
                                                @if($attendanceCount->StudentId == $student->id)
                                                {{ $attendanceCount->attendance_count }}
                                                @endif
                                                @endforeach
                                                @endif
                                            </td>
                                            <td class="min-width text-sm">
                                                @if (isset($batchDetails))
                                                @foreach($batchDetails as $batchDetail)
                                                @if($batchDetail->BatchId == $student->BatchDetailId)
                                                {{ $batchDetail->NoOfSession }}
                                                @endif
                                                @endforeach
                                                @endif
                                            </td>

                                        </tr>
                                        @endforeach
                                        @endif
                                    </tbody>
                                </table>
                                @if ($data->IsApproved == 0)
                                <button class="main-btn dark-btn rounded-full btn-hover btn-sm" id="submit-button" disabled>
                                    Submit
                                </button>
                                @endif
                            </form> <!-- end table -->
                        </div>
                    </div>
                    <!-- end card -->
                </div>
                <!-- end col -->
            </div>
            <!-- end row -->
        </div>
        <!-- ========== tables-wrapper end ========== -->
    </div>
    <!-- end container -->
</section>
<!-- ========== table components end ========== -->
@push('script')
<script>
    document.addEventListener('DOMContentLoaded', function() {
        var checkboxes = document.querySelectorAll('tbody input[type="checkbox"]');
        var submitButton = document.getElementById('submit-button');

        checkboxes.forEach(function(checkbox) {
            checkbox.addEventListener('change', function() {
                var checked = false;
                checkboxes.forEach(function(cb) {
                    if (cb.checked) {
                        checked = true;
                        return;
                    }
                });
                submitButton.disabled = !checked;
            });
        });

        document.getElementById('selectall').addEventListener('change', function() {
            var isChecked = this.checked;
            checkboxes.forEach(function(checkbox) {
                checkbox.checked = isChecked;
            });
            submitButton.disabled = !isChecked;
        });
    });
</script>

@endpush

@endsection