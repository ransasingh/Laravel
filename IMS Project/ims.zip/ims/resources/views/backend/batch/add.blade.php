@extends('layout.admin_layout')
@section('title', 'Batch Add')
@section('dashboard')
<!-- ========== section start ========== -->
<section class="section">
    <div class="container-fluid">

        @if(session('error'))
        <div class="alert alert-danger alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('error') }}
        </div>
        @endif

        @if(session('success'))
        <div class="alert alert-success alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('success') }}
        </div>
        @endif


        <!-- ========== title-wrapper start ========== -->
        <div class="title-wrapper pt-30">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <div class="title">
                        <h2>Add Batch</h2>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="breadcrumb-wrapper">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a href="{{route('batch.listing')}}" class="main-btn active-btn-light rounded-full btn-hover btn-sm">
                                        <i class="lni lni-arrow-left"></i>
                                        All Batch
                                    </a>
                                </li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
            <!-- end row -->
        </div>
        <div class="row g-0 auth-row">
            <!-- end col -->
            <div class="col-md-12">
                <div class="signup-wrapper">
                    <div class="form-wrapper">
                        <form action="{{ route('batch.addnew') }}" method="post" enctype="multipart/form-data">
                            @csrf
                            <div class="row">
                                <div class="col-md-6 col-xs-12">
                                    <div class="select-style-1">
                                        <label for="SubjectId" class="compulsory">Subject</label>
                                        <div class="select-position">
                                            <select name="SubjectId" id="SubjectId">
                                                <option selected disabled>Select Subject</option>
                                                @if (isset($subjects))
                                                @foreach ($subjects as $subject)
                                                <option value="{{$subject->id}}" {{old('SubjectId') == $subject->id ? 'selected' : '' }}>{{$subject->Name}}</option>
                                                @endforeach
                                                @endif
                                            </select>
                                        </div>
                                        @error('SubjectId')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                                <div class="col-md-6 col-xs-12">
                                    <div class="input-style-1">
                                        <label for="StudentCapacity" class="compulsory">Student Capacity </label>
                                        <input type="number" name="StudentCapacity" id="StudentCapacity" value="{{ old('StudentCapacity') }}" min="0" />
                                        @error('StudentCapacity')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 col-xs-12">
                                    <div class="input-style-1">
                                        <label for="FromDate" class="compulsory">From Date </label>
                                        <input type="date" name="FromDate" id="FromDate" value="{{ old('FromDate') }}" />
                                        @error('FromDate')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                                <div class="col-md-6 col-xs-12">
                                    <div class="input-style-1">
                                        <label for="ToDate" class="compulsory">To Date </label>
                                        <input type="date" name="ToDate" id="ToDate" value="{{ old('ToDate') }}" />
                                        @error('ToDate')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 col-xs-12">
                                    <div class="input-style-1">
                                        <label for="StartTimeInMinutes" class="compulsory">From Time</label>
                                        <input type="time" name="StartTimeInMinutes" id="StartTimeInMinutes" value="{{ old('StartTimeInMinutes') }}" />
                                        @error('StartTimeInMinutes')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                                <div class="col-md-6 col-xs-12">
                                    <div class="input-style-1">
                                        <label for="EndTimeInMinutes" class="compulsory">To Time</label>
                                        <input type="time" name="EndTimeInMinutes" id="EndTimeInMinutes" value="{{ old('EndTimeInMinutes') }}" />

                                        @error('EndTimeInMinutes')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 col-xs-12">
                                    <div class="select-style-1">
                                        <label for="FacultyId" class="compulsory">Faculty</label>
                                        <div class="select-position">
                                            <select name="FacultyId" id="FacultyId">
                                                <option selected disabled>Select Faculty</option>
                                                @if (isset($faculties))
                                                @foreach ($faculties as $faculty)
                                                <option value="{{$faculty->id}}" {{old('FacultyId') == $faculty->id ? 'selected' : '' }}>{{$faculty->FirstName ." ".$faculty->LastName}}</option>
                                                @endforeach
                                                @endif
                                            </select>
                                        </div>
                                        <span id="facultyValidationMsg" class="text-danger"></span>
                                        @error('FacultyId')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                                <div class="col-md-3 col-xs-12">
                                    <br>
                                    <a href="#" class="main-btn success-btn rounded-full btn-hover btn-sm faculty-batch-link" id="facultyBatchLink" target="_blank">
                                        Check Faculty Batches
                                    </a>
                                </div>
                                <div class="col-md-3 col-xs-12">
                                    <div class="select-style-1">
                                        <label for="IsActive" class="compulsory">Is Active</label>
                                        <div class="select-position">
                                            <select name="IsActive" id="IsActive">
                                                <option value="1" selected>Active</option>
                                                <option value="0">Inactive</option>
                                            </select>
                                        </div>
                                        @error('IsActive')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 col-xs-12">
                                    <div class="select-style-1">
                                        <label for="IsCompleted" class="compulsory">Is Batch Completed</label>
                                        <div class="select-position">
                                            <select name="IsCompleted" id="IsCompleted">
                                                <option value="1" disabled>Yes</option>
                                                <option value="0" selected>No</option>
                                            </select>
                                        </div>
                                        @error('IsCompleted')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12 col-xs-12">
                                    <div class="table-wrapper table-responsive">
                                        <table class="table custom-table">
                                            <tr class="text-center">
                                                <th> <label class="form-check-label" for="Sun">Sun</label></th>
                                                <th> <label class="form-check-label" for="Mon">Mon</label></th>
                                                <th> <label class="form-check-label" for="Tue">Tue</label></th>
                                                <th> <label class="form-check-label" for="Wed">Wed</label></th>
                                                <th> <label class="form-check-label" for="Thu">Thu</label></th>
                                                <th> <label class="form-check-label" for="Fri">Fri</label></th>
                                                <th> <label class="form-check-label" for="Sat">Sat</label></th>
                                            </tr>
                                            <tr class="text-center">
                                                <td><input class="form-check-input" type="checkbox" id="Sun" name="BatchDay[]" value="0" /></td>
                                                <td><input class="form-check-input" type="checkbox" id="Mon" name="BatchDay[]" value="1" checked /></td>
                                                <td><input class="form-check-input" type="checkbox" id="Tue" name="BatchDay[]" value="2" /></td>
                                                <td><input class="form-check-input" type="checkbox" id="Wed" name="BatchDay[]" value="3" /></td>
                                                <td><input class="form-check-input" type="checkbox" id="Thu" name="BatchDay[]" value="4" /></td>
                                                <td><input class="form-check-input" type="checkbox" id="Fri" name="BatchDay[]" value="5" /></td>
                                                <td><input class="form-check-input" type="checkbox" id="Sat" name="BatchDay[]" value="6" /></td>
                                            </tr>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <!-- end col -->
                            <div class="row">
                                <div class="col-12 mt-10">
                                    <button class="main-btn dark-btn rounded-full btn-hover btn-sm">
                                        Submit
                                    </button>
                                </div>
                            </div>
                            <!-- end row -->
                        </form>

                    </div>
                </div>
            </div>
            <!-- end col -->
        </div>

    </div>
    <!-- end container -->
</section>
<!-- ========== section end ========== -->
@push('script')
<script src="{{ url('assets/js/custom/custom.js')}}"></script>
<script>
    $(document).ready(function() {
        $('.faculty-batch-link').on('click', function(e) {
            var selectedFacultyId = $('#FacultyId').val();
            var baseUrl = "{{ route('faculty.batch.listing') }}";

            // Check if a faculty is selected
            if (!selectedFacultyId) {
                // Show validation message and prevent link navigation
                $('#facultyValidationMsg').text('Please select a faculty.');
                e.preventDefault();
            } else {
                // Clear validation message if it was shown
                $('#facultyValidationMsg').text('');

                // Update the link with the selected facultyId
                var newUrl = baseUrl + '?facultyId=' + selectedFacultyId;
                $(this).attr('href', newUrl);
            }
        });
    });
</script>

@endpush

@endsection