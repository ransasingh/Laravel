@extends('layout.admin_layout')
@section('title', 'Batch Edit')
@section('dashboard')
<!-- ========== section start ========== -->
<section class="section">
    <div class="container-fluid">

        @if(session('error'))
        <div class="alert alert-danger alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('error') }}
        </div>
        @endif

        @if(session('success'))
        <div class="alert alert-success alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('success') }}
        </div>
        @endif


        <!-- ========== title-wrapper start ========== -->
        <div class="title-wrapper pt-30">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <div class="title">
                        <h2>Update Batch</h2>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="breadcrumb-wrapper">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a href="{{route('batch.listing')}}" class="main-btn active-btn-light rounded-full btn-hover btn-sm">
                                        <i class="lni lni-arrow-left"></i>
                                        All Batch
                                    </a>
                                </li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
            <!-- end row -->
        </div>
        <div class="row g-0 auth-row">
            <!-- end col -->
            <div class="col-md-12">
                <div class="signup-wrapper">
                    <div class="form-wrapper">
                        <form action="{{ route('batch.editbatch',['id' =>$data->id]) }}" method="post" enctype="multipart/form-data">
                            @csrf
                            <div class="row">
                                <div class="col-md-6 col-xs-12">
                                    <div class="select-style-1">
                                        <label for="SubjectId" class="compulsory">Subject</label>
                                        <div class="select-position">
                                            <select name="SubjectId" id="SubjectId">
                                                <option selected disabled>Select Subject</option>
                                                @if (isset($subjects))
                                                @foreach ($subjects as $subject)
                                                <option value="{{$subject->id}}" {{$data->Name == $subject->Name ? 'selected' : '' }}>{{$subject->Name}}</option>
                                                @endforeach
                                                @endif
                                            </select>
                                        </div>
                                        @error('SubjectId')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                                <div class="col-md-3 col-xs-12">
                                    <div class="input-style-1">
                                        <label for="Name">Batch Name </label>
                                        <input type="text" name="Name" id="Name" value="{{$data->Name}}" disabled />
                                    </div>
                                </div>
                                <div class="col-md-3 col-xs-12">
                                    <div class="input-style-1">
                                        <label for="StudentCapacity" class="compulsory">Student Capacity </label>
                                        <input type="number" name="StudentCapacity" id="StudentCapacity" value="{{$data->StudentCapacity}}" min="0" />
                                        @error('StudentCapacity')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 col-xs-12">
                                    <div class="input-style-1">
                                        <label for="FromDate" class="compulsory">From Date </label>
                                        <input type="date" name="FromDate" id="FromDate" value="{{$data->FromDate}}" />
                                        @error('FromDate')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                                <div class="col-md-6 col-xs-12">
                                    <div class="input-style-1">
                                        <label for="ToDate" class="compulsory">To Date </label>
                                        <input type="date" name="ToDate" id="ToDate" value="{{$data->ToDate}}" />
                                        @error('ToDate')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 col-xs-12">
                                    <div class="input-style-1">
                                        <label for="StartTimeInMinutes" class="compulsory">From Time</label>
                                        <input type="time" name="StartTimeInMinutes" id="StartTimeInMinutes" value="{{$data->StartTimeInMinutes}}" />
                                        @error('StartTimeInMinutes')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                                <div class="col-md-6 col-xs-12">
                                    <div class="input-style-1">
                                        <label for="EndTimeInMinutes" class="compulsory">To Time</label>
                                        <input type="time" name="EndTimeInMinutes" id="EndTimeInMinutes" value="{{$data->EndTimeInMinutes}}" />

                                        @error('EndTimeInMinutes')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 col-xs-12">
                                    <div class="select-style-1">
                                        <label for="FacultyId" class="compulsory">Faculty</label>
                                        <div class="select-position">
                                            <select name="FacultyId" id="FacultyId">
                                                <option selected disabled>Select Faculty</option>
                                                @if (isset($faculties))
                                                @foreach ($faculties as $faculty)
                                                <option value="{{$faculty->id}}" {{$data->FacultyId == $faculty->id ? 'selected' : '' }}>{{$faculty->FirstName ." ".$faculty->LastName}}</option>
                                                @endforeach
                                                @endif
                                            </select>
                                        </div>
                                        <span id="facultyValidationMsg" class="text-danger"></span>
                                        @error('FacultyId')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                                <div class="col-md-3 col-xs-12">
                                    <br>
                                    <a href="#" class="main-btn success-btn rounded-full btn-hover btn-sm faculty-batch-link" id="facultyBatchLink" target="_blank">
                                        Check Faculty Batches
                                    </a>
                                </div>
                                <div class="col-md-3 col-xs-12">
                                    <div class="select-style-1">
                                        <label for="IsActive" class="compulsory">Is Active</label>
                                        <div class="select-position">
                                            <select name="IsActive" id="IsActive">
                                                <option value="1" {{$data->IsActive == "1"? 'selected' : ''}}>Active</option>
                                                <option value="0" {{$data->IsActive == "0"? 'selected' : ''}}>Inactive</option>
                                            </select>
                                        </div>
                                        @error('IsActive')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 col-xs-12">
                                    <div class="select-style-1">
                                        <label for="IsCompleted" class="compulsory">Is Batch Completed</label>
                                        <div class="select-position">
                                            <select name="IsCompleted" id="IsCompleted">
                                                <option value="1" {{$data->IsCompleted == "1"? 'selected' : ''}}>Yes</option>
                                                <option value="0" {{$data->IsCompleted == "0"? 'selected' : ''}}>No</option>
                                            </select>
                                        </div>
                                        @error('IsCompleted')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12 col-xs-12">
                                    <div class="table-wrapper table-responsive">
                                        <table class="table custom-table">
                                            <tr class="text-center">
                                                <th><label class="form-check-label" for="Sun">Sun</label></th>
                                                <th><label class="form-check-label" for="Mon">Mon</label></th>
                                                <th><label class="form-check-label" for="Tue">Tue</label></th>
                                                <th><label class="form-check-label" for="Wed">Wed</label></th>
                                                <th><label class="form-check-label" for="Thu">Thu</label></th>
                                                <th><label class="form-check-label" for="Fri">Fri</label></th>
                                                <th><label class="form-check-label" for="Sat">Sat</label></th>
                                            </tr>
                                            <tr class="text-center">
                                                @foreach([0, 1, 2, 3, 4, 5, 6] as $day)
                                                <td>
                                                    @php
                                                    $dayName = \Carbon\Carbon::now()->startOfWeek()->addDays($day)->format('l');
                                                    $isChecked = $batchDetailData->contains('BatchDay', $day);
                                                    @endphp
                                                    <input class="form-check-input" type="checkbox" id="{{ $dayName }}" name="BatchDay[]" value="{{ $day }}" {{ $isChecked ? 'checked' : '' }} />
                                                </td>
                                                @endforeach
                                            </tr>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <!-- end col -->
                            <div class="col-12">
                                <button class="main-btn dark-btn rounded-full btn-hover btn-sm">
                                    Update
                                </button>
                            </div>
                    </div>
                    <!-- end row -->
                    </form>

                </div>
            </div>
        </div>
        <!-- end col -->
        <span class="divider">
        </span>

        <div class="tables-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card-style mb-10">
                        <h4>Student suggestions to assign</h4>
                        <div class="table-wrapper table-responsive">
                            <form id="studentForm" action="{{ route('studentbatchassign.addnew') }}" method="post">
                                @csrf
                                <table class="table custom-table" id="data-table">
                                    <thead>
                                        <tr>
                                            <th class="text-uppercase">
                                                <input type="checkbox" class="form-check-input" id="selectAllCheckbox">SelectAll
                                            </th>
                                            <th class="text-uppercase">First Name</th>
                                            <th class="text-uppercase">Last Name</th>
                                            <th class="text-uppercase">Student Code</th>
                                            <th class="text-uppercase">Commited From Time</th>
                                            <th class="text-uppercase">Commited To Time</th>
                                            <th class="text-uppercase">See Profile</th>
                                            <th class="text-uppercase">Already Assigned ?</th>
                                        </tr>
                                        <!-- end table row-->
                                    </thead>
                                    <tbody class="section1">
                                        @if (isset($studentsInSubject))
                                        @foreach ($studentsInSubject as $record)
                                        <tr>
                                            <td>
                                                <input type="checkbox" class="form-check-input" name="StudentId[]" value="{{$record->id}}">
                                                <input type="hidden" name="BatchDetailId" value="{{$data->id}}">
                                            </td>
                                            <td class="min-width text-sm">{{$record->FirstName }}</td>
                                            <td class="min-width text-sm">{{$record->LastName }}</td>
                                            <td class="min-width text-sm">{{$record->StudentCode }}</td>
                                            <td class="min-width text-sm">{{$record->BatchFromMnt }}</td>
                                            <td class="min-width text-sm">{{$record->BatchToMnt }}</td>
                                            <td><a href="{{route('student.edit',['id' =>$record->id])}}" target="_blank">View Profile</a></td>
                                            <td class="min-width text-sm">No</td>
                                        </tr>
                                        @endforeach
                                        @endif
                                    </tbody>
                                </table>
                                <div class="col-12">
                                    <button class="main-btn dark-btn rounded-full btn-hover btn-sm">
                                        Assign Students
                                    </button>
                                </div>
                            </form>
                            <!-- end table -->
                        </div>
                    </div>
                    <!-- end card -->
                </div>
                <!-- end col -->
            </div>
            <!-- end row -->
        </div>

        <span class="divider">
        </span>

        <div class="tables-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card-style">
                        <div class="d-grid gap-2 d-md-flex justify-content-md-end align-items-center">
                            <h4 class="me-auto">Student Already Assigned</h4>
                            <button id="sendSelectedWhatsApp" onclick="sendSelectedWhatsApp()" class="btn btn-primary">Send WhatsApp Message to Selected Students</button>
                        </div>
                        <div class="table-wrapper table-responsive">

                            <table class="table custom-table" id="data-table">
                                <thead>
                                    <tr>
                                        <th class="text-uppercase">
                                            <div>
                                                <input type="checkbox" id="selectAllStudents" onchange="toggleSelectAll()" />
                                                <label for="selectAllStudents">Select All</label>
                                            </div>
                                        </th>
                                        <th class="text-uppercase">First Name</th>
                                        <th class="text-uppercase">Last Name</th>
                                        <th class="text-uppercase">Student Code</th>
                                        <th class="text-uppercase">Whatsapp</th>
                                        <th class="text-uppercase print-hidden">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @if (isset($studentBatchAssignData))
                                    @foreach ($studentBatchAssignData as $record)
                                  
                                    <tr>
                                        <td scope="row" class="text-sm">
                                            <input type="checkbox" class="select-student" data-mobile="{{ $record->MobileNumber }}" />
                                        </td>
                                        <td class="min-width text-sm">{{$record->FirstName }}</td>
                                        <td class="min-width text-sm">{{$record->LastName }}</td>
                                        <td class="min-width text-sm">{{$record->StudentCode }}</td>
                                        <td class="min-width">
                                            <a href="javascript:void(0);" onclick="sendWhatsAppMessage('{{ $record->MobileNumber }}', 'Dear {{ $record->FirstName }} {{ $record->LastName }}, Your batch for {{ $data->Name }} has been scheduled to start from {{date('d-M-y',strtotime( $data->FromDate)) }} with {{ isset($record->FirstName) && isset($record->LastName) ? $record->FirstName . ' ' . $record->LastName : '' }}, kindly check. For any further details, do contact our admin department. Happy Learning!!')">
                                                <i class="lni lni-whatsapp"></i>
                                            </a>
                                        </td>
                                        <td>
                                            <div class="action">
                                                <a href="{{route('studentbatchassign.delete',['id'=>$record->assigned_id ]) }}" class="text-danger" onclick="return confirm('Are you sure?')" title="Delete"><i class="lni lni-trash-can"></i></a>
                                            </div>
                                        </td>
                                    </tr>
                                    @endforeach
                                    @endif
                                </tbody>
                            </table>
                            <!-- end table -->
                        </div>
                        @if (isset($studentBatchAssignData))
                        <div class="row">
                            <div class="col-md-6">
                                <!-- Show entries message -->
                                <div class="dataTables_info" id="data-table_info" role="status" aria-live="polite">
                                    Showing 1 to {{ $studentBatchAssignData->count() }} of {{ $studentBatchAssignData->count() }} entries
                                </div>
                            </div>
                        </div>
                        @endif
                    </div>
                    <!-- end card -->
                </div>

            </div>
            <!-- end col -->
        </div>
        <!-- end row -->

    </div>

    </div>
    <!-- end container -->
</section>
<!-- ========== section end ========== -->
@push('script')
<script src="{{ url('assets/js/custom/custom.js')}}"></script>
<script>
    document.getElementById('selectAllCheckbox').addEventListener('change', function() {
        var checkboxes = document.querySelectorAll('.section1 input[type="checkbox"]');
        checkboxes.forEach(function(checkbox) {
            checkbox.checked = event.target.checked;
        });
    });

    function sendWhatsAppMessage(mobileNumber, message) {
        var whatsappUrl = "https://wa.me/" + mobileNumber + "?text=" + encodeURIComponent(message);
        window.open(whatsappUrl, '_blank');
    }

    function sendSelectedWhatsApp() {
        var selectedStudents = document.querySelectorAll('.select-student:checked');
        var message = "Your batch for {{ $data->Name }} has been scheduled to start from {{date('d-M-y',strtotime( $data->FromDate)) }} with {{ isset($record->FirstName) && isset($record->LastName) ? $record->FirstName . ' ' . $record->LastName : '' }}, kindly check. For any further details, do contact our admin department. Happy Learning!!";

        selectedStudents.forEach(function(student) {
            var mobileNumber = student.getAttribute('data-mobile');
            sendWhatsAppMessage(mobileNumber, message);
        });
    }

    function toggleSelectAll() {
        var checkboxes = document.querySelectorAll('.select-student');
        var selectAllCheckbox = document.getElementById('selectAllStudents');

        checkboxes.forEach(function(checkbox) {
            checkbox.checked = selectAllCheckbox.checked;
        });
    }
    $(document).ready(function() {
        $('.faculty-batch-link').on('click', function(e) {
            var selectedFacultyId = $('#FacultyId').val();
            var baseUrl = "{{ route('faculty.batch.listing') }}";

            // Check if a faculty is selected
            if (!selectedFacultyId) {
                // Show validation message and prevent link navigation
                $('#facultyValidationMsg').text('Please select a faculty.');
                e.preventDefault();
            } else {
                // Clear validation message if it was shown
                $('#facultyValidationMsg').text('');

                // Update the link with the selected facultyId
                var newUrl = baseUrl + '?facultyId=' + selectedFacultyId;
                $(this).attr('href', newUrl);
            }
        });
    });
</script>
@endpush

@endsection