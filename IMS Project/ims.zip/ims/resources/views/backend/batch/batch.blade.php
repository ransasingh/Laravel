@extends('layout.admin_layout')
@section('title', 'Faculty Batch Detail')
@section('dashboard')

<!-- ========== table components start ========== -->
<section class="table-components">
    <div class="container-fluid">

        @if(session('error'))
        <div class="alert alert-danger alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('error') }}
        </div>
        @endif

        @if(session('success'))
        <div class="alert alert-success alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('success') }}
        </div>
        @endif


        <!-- ========== title-wrapper start ========== -->
        <div class="title-wrapper pt-30">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <div class="title">
                        <h2>Faculty Batch Detail</h2>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="breadcrumb-wrapper">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a href="{{URL::previous();}}" class="main-btn active-btn-light rounded-full btn-hover btn-sm">
                                        <i class="lni lni-arrow-left"></i>
                                        Back
                                    </a>
                                </li>
                            </ol>
                        </nav>
                    </div>
                </div>

            </div>
            <!-- end row -->
        </div>
        <!-- ========== title-wrapper end ========== -->

        <!-- ========== tables-wrapper start ========== -->
        <div class="tables-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card-style mb-30">

                        <div class="table-wrapper table-responsive">
                            <table class="table">
                                <thead>
                                    <tr class="text-sm text-center">
                                        <th class="text-uppercase">#</th>
                                        <th class="text-uppercase">Name</th>
                                        <th class="text-uppercase">Subject</th>
                                        <th class="text-uppercase">From Date</th>
                                        <th class="text-uppercase">To Date</th>
                                        <th class="text-uppercase">Start Time</th>
                                        <th class="text-uppercase">End Time</th>
                                        <th class="text-uppercase">Days</th>
                                        <th class="text-uppercase">Faculty</th>
                                    </tr>
                                    <!-- end table row-->
                                </thead>
                                <tbody>
                                    @if (isset($data))
                                    @foreach ($data as $record)
                                    <tr class="text-center">
                                        <th scope="row" class="text-sm">{{ $loop->index + 1 }}</th>
                                        <td class="min-width text-sm">{{$record->Name }}</td>
                                        <td class="min-width text-sm">{{$record->Name }}</td>
                                        <td class="min-width text-sm">{{date('d-M-y',strtotime($record->FromDate))}}</td>
                                        <td class="min-width text-sm">{{date('d-M-y',strtotime($record->ToDate))}}</td>
                                        <td class="min-width text-sm">{{$record->StartTimeInMinutes }}</td>
                                        <td class="min-width text-sm">{{$record->EndTimeInMinutes }}</td>
                                        <td class="min-width text-sm">
                                            @php
                                            $daysOfWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
                                            $days = explode(',', $record->BatchDays);
                                            @endphp

                                            @foreach($days as $day)
                                            {{ $daysOfWeek[trim($day)] }}
                                            @if(!$loop->last)
                                            ,
                                            @endif
                                            @endforeach

                                        </td>
                                        <td class="min-width text-sm">{{$record->FirstName." ".$record->LastName }}</td>

                                    </tr>
                                    @endforeach
                                    @endif
                                </tbody>
                            </table>
                            <!-- end table -->
                        </div>
                    </div>
                    <!-- end card -->
                </div>
                <!-- end col -->
            </div>
            <!-- end row -->
        </div>
        <!-- ========== tables-wrapper end ========== -->
    </div>
    <!-- end container -->
</section>
<!-- ========== table components end ========== -->



@endsection