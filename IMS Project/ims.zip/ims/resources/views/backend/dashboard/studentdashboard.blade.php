@extends('layout.admin_layout')
@section('title', 'Student Dashboard')
@section('dashboard')
<!-- ========== section start ========== -->
<section class="section">
    <div class="container-fluid">
        @if($errors->any())
        <div class="alert alert-danger alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            <ul>
                @foreach($errors->all() as $error)
                <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
        @endif

        @if(session('error'))
        <div class="alert alert-danger alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('error') }}
        </div>
        @endif

        @if(session('success'))
        <div class="alert alert-success alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('success') }}
        </div>
        @endif


        <!-- ========== title-wrapper start ========== -->
        <div class="title-wrapper pt-10">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <div class="title">
                        <h2>Student Dashboard</h2>
                    </div>
                </div>
                <!-- Your HTML code -->
                <div class="col-md-6">
                    <div class="breadcrumb-wrapper">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <div class="dropdown">
                                        <button class="dropdown-toggle btn btn-link" type="button" id="notificationDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                                            <i class="mdi mdi-bell"></i>
                                            <span id="notificationCount" class="badge bg-danger">0</span>
                                        </button>
                                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="notificationDropdown" id="notificationList">
                                            <!-- Notification items will be populated here -->
                                        </ul>
                                    </div>
                                </li>
                            </ol>
                        </nav>
                    </div>
                </div>

                <!-- Modal for notification details -->
                <div class="modal fade" id="notificationModal" tabindex="-1" aria-labelledby="notificationModalLabel" aria-hidden="true">
                    <div class="modal-dialog  modal-dialog-top modal-sm">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="notificationModalLabel">Notification</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <div id="notificationDetail"></div>
                            </div>
                        </div>
                    </div>
                </div>



                @push('script')
                <script>
                    // Function to fetch and update the notification count
                    function updateNotificationCount() {
                        fetch('{{ route("notifications.count") }}')
                            .then(response => response.json())
                            .then(data => {
                                document.getElementById('notificationCount').textContent = data.count;
                            })
                            .catch(error => console.error('Error fetching notification count:', error));
                    }

                    // Function to fetch notifications and populate the dropdown
                    function fetchNotifications() {
                        fetch('{{ route("notifications.show") }}')
                            .then(response => response.json())
                            .then(data => {

                                const notificationList = document.getElementById('notificationList');
                                notificationList.innerHTML = ''; // Clear previous notifications

                                data.forEach(notification => {
                                    const listItem = document.createElement('li');
                                    const link = document.createElement('a');
                                    link.classList.add('dropdown-item');
                                    link.href = '#';
                                    link.textContent = notification.Subject;
                                    link.setAttribute('data-notification-id', notification.id);
                                    link.addEventListener('click', function(event) {
                                        event.preventDefault();
                                        fetchNotificationDetails(notification.id);
                                    });
                                    listItem.appendChild(link);
                                    notificationList.appendChild(listItem);
                                });
                            })
                            .catch(error => console.error('Error fetching notifications:', error));
                    }

                    // Fetch notifications and update count when the page loads
                    document.addEventListener("DOMContentLoaded", function() {
                        updateNotificationCount();
                        fetchNotifications();
                    });

                    // Function to fetch and display notification details in modal
                    function fetchNotificationDetails(notificationId) {
                        fetch('{{ route("notifications.show") }}/' + notificationId)
                            .then(response => response.json())
                            .then(data => {
                                var notificationDetail = data[0].Body;
                                // Set innerHTML to display HTML content
                                document.getElementById('notificationDetail').innerHTML = notificationDetail;
                                $('#notificationModal').modal('show'); // Show the modal after fetching notification details
                            })
                            .catch(error => console.error('Error fetching notification details:', error));
                    }
                </script>
                @endpush

            </div>
            <!-- end row -->
        </div>
        <!-- ========== title-wrapper end ========== -->
        <div class="row">
            <div class="col-xl-3 col-lg-4 col-sm-6">
                <div class="icon-card mb-30">
                    <div class="icon blue">
                        <i class="lni lni-book"></i>
                    </div>
                    <div class="content text-center">
                        <h6 class="mb-10">Total Subject</h6>
                        <h3 class="text-bold mb-10">{{$subjectCount}}</h3>
                    </div>
                </div>
                <!-- End Icon Cart -->
            </div>

            <div class="col-xl-3 col-lg-4 col-sm-6">
                <div class="icon-card mb-30">
                    <div class="icon purple">
                        <i class="mdi mdi-alarm-multiple"></i>
                    </div>

                    <div class="content text-center">
                        <h6 class="mb-10">Total Batch</h6>
                        <h3 class="text-bold mb-10">{{$batchCount}}</h3>
                    </div>
                </div>
                <!-- End Icon Cart -->
            </div>

            <div class="col-xl-3 col-lg-4 col-sm-6">
                <div class="icon-card mb-30">
                    <div class="icon green">
                        <i class="mdi mdi-cash-multiple"></i>
                    </div>
                    <div class="content text-center">
                        <h6 class="mb-10">Total Emi</h6>
                        <h3 class="text-bold mb-10">{{$emiCount}}</h3>
                    </div>
                </div>
                <!-- End Icon Cart -->
            </div>

            <div class="col-xl-3 col-lg-4 col-sm-6">
                <div class="icon-card mb-30">
                    <div class="icon orange">
                        <i class="mdi mdi-credit-card-check"></i>
                    </div>
                    <div class="content text-center">
                        <h6 class="mb-10">Total Paid Emi</h6>
                        <h3 class="text-bold mb-10">{{$paidEmiCount}}</h3>

                    </div>
                </div>

            </div>

        </div>

        <!-- End Row -->

        <div class="row">
            <div class="col-lg-7">
                <div class="card-style mb-30">
                    <div class="title d-flex flex-wrap align-items-center justify-content-between">
                        <div class="left">
                            <h6 class="text-medium mb-2">Subject Wise Batch</h6>
                        </div>
                    </div>
                    <!-- End Title -->
                    <div class="chart-container ">
                        <canvas id="SubjectWiseBatch" style="width: 100%; height: 100%;"></canvas>
                    </div>
                </div>
            </div>
            <div class="col-lg-5 col-xs-12">
                <div class="card-style mb-30">
                    <h4 class="mb-2">Due Emi</h4>
                    <div class="table-wrapper table-responsive">
                        <table class="table" id="data-table">
                            <thead>
                                <tr class="text-sm">
                                    <th class="text-uppercase">#</th>
                                    <th class="text-uppercase">Student</th>
                                    <th class="text-uppercase">Installment Amount</th>
                                    <th class="text-uppercase">Installment Due Date</th>
                                </tr>
                                <!-- end table row-->
                            </thead>
                            <tbody>
                                @if (isset($studentDueemi))
                                @foreach ($studentDueemi as $record)
                                <tr>
                                    <th scope="row" class="text-sm">{{ $loop->index + 1 }}</th>
                                    <td class="min-width text-sm">{{$record->FirstName ." ". $record->LastName  }}</td>
                                    <td class="min-width text-sm">{{$record->InstallmentAmount}}</td>
                                    <td class="min-width text-sm">{{date('d-M-y',strtotime($record->InstallmentDueDate))}}</td>
                                </tr>
                                @endforeach
                                @endif
                            </tbody>
                        </table>
                        <!-- end table -->
                    </div>
                </div>
                <!-- end card -->
            </div>
            <!-- end col -->


        </div>



    </div>
    <!-- end container -->
</section>
<!-- ========== section end ========== -->


@push('script')
<script>
    // Define a set of colors to use for subjects
    var subjectColors = ['#FF5733', '#33FF57', '#5733FF', '#33FFFF', '#FF33FF', '#FFFF33', '#3399FF'];

    document.addEventListener("DOMContentLoaded", function() {
        fetchSubjectWiseBatchData();
    });

    function fetchSubjectWiseBatchData() {
        fetch('{{ route("getSubjectWiseBatchData") }}')
            .then(response => response.json())
            .then(data => {
                renderBatchChart(data);
            })
            .catch(error => {
                console.error('Error fetching data:', error);
            });
    }

    function renderBatchChart(data) {
        var labels = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        var datasets = [];

        data.forEach((day, index) => {
            day.batches.forEach(batch => {
                var subject = batch.subject;

                // If the subject doesn't exist in datasets, add it with a color
                if (!datasets.find(dataset => dataset.label === subject)) {
                    datasets.push({
                        label: subject,
                        data: [0, 0, 0, 0, 0, 0, 0],
                        backgroundColor: subjectColors[datasets.length % subjectColors.length],
                        borderColor: subjectColors[datasets.length % subjectColors.length],
                        borderWidth: 1
                    });
                }

                // Update the batch count in the correct index corresponding to the day of the week
                var dayIndex = labels.indexOf(day.day);
                datasets.find(dataset => dataset.label === subject).data[dayIndex] = day.count;
            });
        });

        var ctx = document.getElementById('SubjectWiseBatch').getContext('2d');
        var myChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: datasets
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }
</script>
@endpush



@endsection