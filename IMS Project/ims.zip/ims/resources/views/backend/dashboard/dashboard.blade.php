@extends('layout.admin_layout')
@section('title', 'Dashboard')
@section('dashboard')
<!-- ========== section start ========== -->
<section class="section">
    <div class="container-fluid">
        @if($errors->any())
        <div class="alert alert-danger alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            <ul>
                @foreach($errors->all() as $error)
                <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
        @endif

        @if(session('error'))
        <div class="alert alert-danger alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('error') }}
        </div>
        @endif

        @if(session('success'))
        <div class="alert alert-success alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('success') }}
        </div>
        @endif

        <!-- ========== title-wrapper start ========== -->
        <div class="title-wrapper pt-10">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <div class="title">
                        <h2>Super Admin Dashboard</h2>
                    </div>
                </div>
                <!-- Your HTML code -->
                <div class="col-md-6">
                    <div class="breadcrumb-wrapper">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <div class="dropdown">
                                        <button class="dropdown-toggle btn btn-link" type="button" id="notificationDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                                            <i class="mdi mdi-bell"></i>
                                            <span id="notificationCount" class="badge bg-danger">0</span>
                                        </button>
                                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="notificationDropdown" id="notificationList">
                                            <!-- Notification items will be populated here -->
                                        </ul>
                                    </div>
                                </li>
                            </ol>
                        </nav>
                    </div>
                </div>

                <!-- Modal for notification details -->
                <div class="modal fade" id="notificationModal" tabindex="-1" aria-labelledby="notificationModalLabel" aria-hidden="true">
                    <div class="modal-dialog  modal-dialog-top modal-sm">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="notificationModalLabel">Notification</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <div id="notificationDetail"></div>
                            </div>
                        </div>
                    </div>
                </div>

                @push('script')
                <script>
                    // Function to fetch and update the notification count
                    function updateNotificationCount() {
                        fetch('{{ route("notifications.count") }}')
                            .then(response => response.json())
                            .then(data => {
                                document.getElementById('notificationCount').textContent = data.count;
                            })
                            .catch(error => console.error('Error fetching notification count:', error));
                    }

                    // Function to fetch notifications and populate the dropdown
                    function fetchNotifications() {
                        fetch('{{ route("notifications.show") }}')
                            .then(response => response.json())
                            .then(data => {

                                const notificationList = document.getElementById('notificationList');
                                notificationList.innerHTML = ''; // Clear previous notifications

                                data.forEach(notification => {
                                    const listItem = document.createElement('li');
                                    const link = document.createElement('a');
                                    link.classList.add('dropdown-item');
                                    link.href = '#';
                                    link.textContent = notification.Subject;
                                    link.setAttribute('data-notification-id', notification.id);
                                    link.addEventListener('click', function(event) {
                                        event.preventDefault();
                                        fetchNotificationDetails(notification.id);
                                    });
                                    listItem.appendChild(link);
                                    notificationList.appendChild(listItem);
                                });
                            })
                            .catch(error => console.error('Error fetching notifications:', error));
                    }

                    // Fetch notifications and update count when the page loads
                    document.addEventListener("DOMContentLoaded", function() {
                        updateNotificationCount();
                        fetchNotifications();
                    });

                    // Function to fetch and display notification details in modal
                    function fetchNotificationDetails(notificationId) {
                        fetch('{{ route("notifications.show") }}/' + notificationId)
                            .then(response => response.json())
                            .then(data => {
                                var notificationDetail = data[0].Body;
                                // Set innerHTML to display HTML content
                                document.getElementById('notificationDetail').innerHTML = notificationDetail;
                                $('#notificationModal').modal('show'); // Show the modal after fetching notification details
                            })
                            .catch(error => console.error('Error fetching notification details:', error));
                    }
                </script>
                @endpush

            </div>

        </div>
        <!-- end row -->
    </div>
    <!-- ========== title-wrapper end ========== -->
    <div class="row">
        <div class="col-xl-2 col-lg-4 col-sm-6">
            <div class="icon-card mb-30">
                <div class="icon purple">
                    <i class="lni lni-user"></i>
                </div>
                <div class="content text-center">
                    <h6 class="mb-10">Total Students</h6>
                    <h3 class="text-bold mb-10">{{$studentCount}}</h3>
                </div>
            </div>
            <!-- End Icon Cart -->
        </div>

        <div class="col-xl-2 col-lg-4 col-sm-6">
            <div class="icon-card mb-30">
                <div class="icon success">
                    <i class="lni lni-checkmark-circle"></i> <!-- Change the icon here -->
                </div>
                <div class="content text-center">
                    <h6 class="mb-10">Active Students</h6>
                    <h3 class="text-bold mb-10">{{$activeStudentCount}}</h3>
                </div>
            </div>
            <!-- End Icon Cart -->
        </div>

        <div class="col-xl-2 col-lg-4 col-sm-6">
            <div class="icon-card mb-30">
                <div class="icon primary">
                    <i class="lni lni-circle-minus"></i> <!-- Change the icon here -->
                </div>
                <div class="content text-center">
                    <h6 class="mb-10">Inactive Students</h6>
                    <h3 class="text-bold mb-10">{{$inactiveStudentCount}}</h3>
                </div>
            </div>
            <!-- End Icon Cart -->
        </div>

        <div class="col-xl-3 col-lg-4 col-sm-6">
            <div class="icon-card mb-30">
                <div class="icon orange">
                    <i class="lni lni-hourglass"></i> <!-- Change the icon here -->
                </div>
                <div class="content text-center">
                    <h6 class="mb-10 text-sm">Pending Batch Completion Approval</h6>
                    <h3 class="text-bold mb-10">{{$batchapprovalcount}}</h3>
                    <!-- Additional Information -->
                    <a href="{{ route('batchecompletionapproval.listing') }}" class="btn btn-primary">More Info <i class="lni lni-arrow-right-circle"></i></a>
                </div>
            </div>
            <!-- End Icon Card -->
        </div>
        <div class="col-xl-3 col-lg-4 col-sm-6">
            <div class="icon-card mb-30">
                <div class="icon blue">
                    <i class="lni lni-hourglass"></i> <!-- Change the icon here -->
                </div>
                <div class="content text-center">
                    <h6 class="mb-10 text-sm">Pending Batch Extension Approval</h6>
                    <h3 class="text-bold mb-10">{{$batchextenstionapprovalcount}}</h3>
                    <!-- Additional Information -->
                    <a href="{{ route('batchextensionapproval.listing') }}" class="btn btn-primary">More Info <i class="lni lni-arrow-right-circle"></i></a>
                </div>
            </div>
            <!-- End Icon Card -->
        </div>

    </div>

    <!-- End Row -->

    <div class="row">
        <div class="col-lg-7">
            <div class="card-style mb-30">
                <div class="title d-flex flex-wrap align-items-center justify-content-between">
                    <div class="left">
                        <h6 class="text-medium mb-2">Course Wise Income</h6>
                    </div>
                    <div class="right">
                        <form id="timePeriodForm" method="post">
                            @csrf
                            <div class="select-style-1 mb-2">
                                <div class="select-position select-sm">
                                    <select id="timePeriodSelect" name="timePeriod" class="light-bg">
                                        <option value="current_month" selected>Current Month</option>
                                        <option value="current_year">Current Year</option>
                                        <option value="last_month">Last Month</option>
                                        <option value="last_3_months">Last 3 Months</option>
                                        <option value="last_year">Last Year</option>
                                    </select>
                                </div>
                            </div>
                            <!-- end select -->
                        </form>
                    </div>
                </div>
                <!-- End Title -->
                <div class="chart-container ">
                    <canvas id="courseIncomeChart" style="width: 100%; height: 100%;"></canvas>
                </div>
            </div>
        </div>


        <div class="col-lg-5">
            <div class="card-style mb-30">
                <div class="title d-flex flex-wrap align-items-center justify-content-between">
                    <div class="left">
                        <h6 class="text-medium mb-2">Course Wise | Student</h6>
                    </div>
                    <div class="right">
                        <form id="TrafficPeriodSelectForm" method="post">
                            @csrf
                            <div class="select-style-1 mb-2">
                                <div class="select-position select-sm">
                                    <select id="TrafficPeriodSelect" name="TrafficChartPeriod" class="bg-ligh">
                                        <option value="current_month">Current Month</option>
                                        <option value="current_year">Current Year</option>
                                        <option value="last_6_months">Last 6 Months</option>
                                        <option value="last_3_months">Last 3 Months</option>
                                        <option value="last_year">Last Year</option>
                                    </select>
                                </div>
                            </div>
                        </form>
                        <!-- end select -->
                    </div>
                </div>
                <!-- End Title -->
                <div class="chart-container">
                    <canvas id="courseTrafficChart" style="width: 100%; height: 100%;"></canvas>
                </div>
                <!-- End Chart -->
            </div>
        </div>
    </div>
    <div class="tables-wrapper">
        <div class="row">
            <div class="col-lg-7 col-xs-12">
                <div class="card-style mb-30">
                    <h4 class="mb-2">Due Emi</h4>
                    <div class="table-wrapper table-responsive">
                        <table class="table" id="data-table">
                            <thead>
                                <tr class="text-sm">
                                    <th class="text-uppercase">#</th>
                                    <th class="text-uppercase">Student</th>
                                    <th class="text-uppercase">Installment Amount</th>
                                    <th class="text-uppercase">Installment Due Date</th>
                                </tr>
                                <!-- end table row-->
                            </thead>
                            <tbody>
                                @if (isset($studentDueemi))
                                @foreach ($studentDueemi as $record)
                                <tr>
                                    <th scope="row" class="text-sm">{{ $loop->index + 1 }}</th>
                                    <td class="min-width text-sm">{{$record->FirstName ." ". $record->LastName  }}</td>
                                    <td class="min-width text-sm">{{$record->InstallmentAmount}}</td>
                                    <td class="min-width text-sm">{{date('d-M-y',strtotime($record->InstallmentDueDate))}}</td>
                                </tr>
                                @endforeach
                                @endif
                            </tbody>
                        </table>
                        <!-- end table -->
                    </div>
                </div>
                <!-- end card -->
            </div>
            <!-- end col -->
        </div>
        <!-- end row -->
    </div>


    </div>
    <!-- end container -->
</section>
<!-- ========== section end ========== -->


@push('script')
<script>
    document.addEventListener("DOMContentLoaded", function() {
        let courseIncomeChart;
        let courseTrafficChart;

        function fetchCourseIncomeData(startDate, endDate, timePeriod) {
            fetch('{{ route("CourseIncomeData") }}', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                    },
                    body: JSON.stringify({
                        startDate: startDate,
                        endDate: endDate,
                        timePeriod: timePeriod // Pass the timePeriod parameter
                    })
                })
                .then(response => response.json())
                .then(data => {
                    generateIncomeChart(data);
                })
                .catch(error => {
                    console.error('Error fetching course income data:', error);
                });
        }

        function generateIncomeChart(data) {
            const labels = data.map(item => item.course_name);
            const values = data.map(item => item.TotalIncome);

            const ctx = document.getElementById('courseIncomeChart').getContext('2d');

            if (courseIncomeChart) {
                courseIncomeChart.destroy();
            }

            courseIncomeChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Total Income',
                        data: values,
                        backgroundColor: 'rgba(75, 192, 192, 0.2)',
                        borderColor: 'rgba(75, 192, 192, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        }

        function fetchCourseTrafficData(startDate, endDate, timePeriod) {
            fetch('{{ route("CourseTrafficData") }}', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                    },
                    body: JSON.stringify({
                        startDate: startDate,
                        endDate: endDate,
                        TrafficChartPeriod: timePeriod // Updated to match the parameter name expected by the controller
                    })
                })
                .then(response => response.json())
                .then(data => {
                    generateTrafficChart(data);
                })
                .catch(error => {
                    console.error('Error fetching course traffic data:', error);
                });
        }

        function generateTrafficChart(data) {
            const courseNames = data.map(course => course.name);
            const studentCounts = data.map(course => course.student_count);

            const ctx = document.getElementById('courseTrafficChart').getContext('2d');

            if (courseTrafficChart) {
                courseTrafficChart.destroy();
            }

            courseTrafficChart = new Chart(ctx, {
                type: 'pie',
                data: {
                    labels: courseNames,
                    datasets: [{
                        label: 'Student Count',
                        data: studentCounts,
                        backgroundColor: [
                            '#ff6384', // Red
                            '#36a2eb', // Blue
                            '#ffce56', // Yellow
                            '#4bc0c0', // Green
                            '#9966ff', // Purple
                            '#ff7f7f', // Pink
                            '#66ff66' // Light Green
                        ]
                    }]
                }
            });
        }

        const currentDate = new Date();
        const lastMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1);
        const startDate = lastMonth.toISOString().slice(0, 10);
        const endDate = currentDate.toISOString().slice(0, 10);

        // Initially fetch data for the current month for both charts
        fetchCourseIncomeData(startDate, endDate, 'current_month');
        fetchCourseTrafficData(startDate, endDate, 'current_month');

        // Add event listener to time period select for income chart
        document.getElementById('timePeriodSelect').addEventListener('change', function() {
            const timePeriod = this.value;
            let startDate, endDate;

            if (timePeriod === 'current_month') {
                startDate = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1).toISOString().slice(0, 10);
                endDate = currentDate.toISOString().slice(0, 10);
            } else if (timePeriod === 'current_year') {
                startDate = new Date(currentDate.getFullYear(), 0, 1).toISOString().slice(0, 10);
                endDate = currentDate.toISOString().slice(0, 10);
            } else if (timePeriod === 'last_month') {
                startDate = new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1).toISOString().slice(0, 10);
                endDate = new Date(currentDate.getFullYear(), currentDate.getMonth(), 0).toISOString().slice(0, 10);
            } else if (timePeriod === 'last_3_months') {
                startDate = new Date(currentDate.getFullYear(), currentDate.getMonth() - 3, 1).toISOString().slice(0, 10);
                endDate = currentDate.toISOString().slice(0, 10);
            } else if (timePeriod === 'last_year') {
                startDate = new Date(currentDate.getFullYear() - 1, currentDate.getMonth(), 1).toISOString().slice(0, 10);
                endDate = currentDate.toISOString().slice(0, 10);
            }

            fetchCourseIncomeData(startDate, endDate, timePeriod); // Pass the timePeriod parameter
        });

        // Add event listener to time period select for traffic chart
        document.getElementById('TrafficPeriodSelect').addEventListener('change', function() {
            const timePeriod = this.value;
            let startDate, endDate;

            if (timePeriod === 'current_month') {
                startDate = new Date().toISOString().slice(0, 10);
                endDate = new Date().toISOString().slice(0, 10);
            } else if (timePeriod === 'current_year') {
                startDate = new Date(new Date().getFullYear(), 0, 1).toISOString().slice(0, 10);
                endDate = new Date().toISOString().slice(0, 10);
            } else if (timePeriod === 'last_6_months') {
                startDate = new Date(new Date().getFullYear(), new Date().getMonth() - 5, 1).toISOString().slice(0, 10);
                endDate = new Date().toISOString().slice(0, 10);
            } else if (timePeriod === 'last_3_months') {
                startDate = new Date(new Date().getFullYear(), new Date().getMonth() - 2, 1).toISOString().slice(0, 10);
                endDate = new Date().toISOString().slice(0, 10);
            } else if (timePeriod === 'last_year') {
                startDate = new Date(new Date().getFullYear() - 1, 0, 1).toISOString().slice(0, 10);
                endDate = new Date(new Date().getFullYear() - 1, 11, 31).toISOString().slice(0, 10);
            }

            fetchCourseTrafficData(startDate, endDate, timePeriod); // Pass the timePeriod parameter
        });
    });
</script>
@endpush


@endsection