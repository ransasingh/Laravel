@extends('layout.admin_layout')
@section('title', 'Batch Extension Edit')
@section('dashboard')
<!-- ========== section start ========== -->
<section class="section">
    <div class="container-fluid">

    @if(session('error'))
        <div class="alert alert-danger alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('error') }}
        </div>
        @endif

        @if(session('success'))
        <div class="alert alert-success alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('success') }}
        </div>
        @endif


        <!-- ========== title-wrapper start ========== -->
        <div class="title-wrapper pt-30">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <div class="title">
                        <h2>Add Batch Extension</h2>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="breadcrumb-wrapper">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a href="{{route('batchextension.listing')}}" class="main-btn active-btn-light rounded-full btn-hover btn-sm">
                                        <i class="lni lni-arrow-left"></i>
                                        All Batch Extension
                                    </a>
                                </li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
            <!-- end row -->
        </div>
        <div class="row g-0 auth-row">
            <!-- end col -->
            <div class="col-md-12">
                <div class="signup-wrapper">
                    <div class="form-wrapper">
                        <form action="{{ route('batchextension.editbatchextension',['id' =>$data->id]) }}" method="post" enctype="multipart/form-data">
                            @csrf
                            <div class="row">
                                <div class="col-md-6 col-xs-12">
                                    <div class="input-style-1">
                                        <label for="Name">Batch Name </label>
                                        <input type="hidden" name="BatchId"  value="{{$data->id}}"/>
                                        <input type="text" name="Name" id="Name" value="{{$data->Name}}" disabled />
                                    </div>
                                </div>
                                <div class="col-md-6 col-xs-12">
                                    <div class="input-style-1">
                                        <label for="NewDate" class="compulsory">New End Date </label>
                                        <input type="date" name="NewDate" id="NewDate" value="{{date('Y-m-d')}}" />
                                        @error('NewDate')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12 col-xs-12">
                                    <div class="input-style-1">
                                        <label for="Remarks">Remarks </label>
                                        <textarea name="Remarks" id="Remarks" cols="30" rows="2">{{old('Remarks')}}</textarea>
                                        @error('Remarks')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                            </div>

                            <!-- end col -->
                            <div class="col-12">
                                <button class="main-btn dark-btn rounded-full btn-hover btn-sm">
                                    Request New Date
                                </button>
                            </div>
                            <!-- end row -->
                        </form>
                    </div>

                </div>
            </div>
        </div>
        <!-- end col -->

    </div>

    </div>
    <!-- end container -->
</section>
<!-- ========== section end ========== -->
@push('script')
<script src="{{ url('assets/js/custom/custom.js')}}"></script>

@endpush

@endsection