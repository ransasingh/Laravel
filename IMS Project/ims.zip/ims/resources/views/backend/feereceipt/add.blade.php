@extends('layout.admin_layout')
@section('title', 'Student Fee')
@section('dashboard')
<!-- ========== section start ========== -->
<section class="section">
    <div class="container-fluid">

        @if(session('error'))
        <div class="alert alert-danger alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('error') }}
        </div>
        @endif

        @if(session('success'))
        <div class="alert alert-success alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('success') }}
        </div>
        @endif

        <!-- ========== title-wrapper start ========== -->
        <div class="title-wrapper pt-30">
            <div class="row align-items-center">
                <div class="col-md-9">
                    <div class="title">
                        <h2>Update Student Fee</h2>
                    </div>
                    <ul class="nav nav-tabs" id="myTabs">
                        <li class="nav-item">
                            <a class="nav-link{{ request()->routeIs('student.edit') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('student.edit',['id' => request('id')]) }}">Student Info</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link{{ request()->routeIs('studentcourse.add') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('studentcourse.add',['id' => request('id')]) }}">Course Details</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link{{ request()->routeIs('feereceipt.add') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('feereceipt.add',['id' => request('id')]) }}">Fee Details</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link{{ request()->routeIs('student.scalender') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('student.scalender',['id' => request('id')]) }}">Calender</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link{{ request()->routeIs('student.PortfolioSubmission') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('student.PortfolioSubmission',['id' => request('id')]) }}">Portfolio Submission</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link{{ request()->routeIs('student.batchcompletion') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('student.batchcompletion',['id' => request('id')]) }}">Batch Completion</a>
                        </li>
                    </ul>

                </div>
                <div class="col-md-3">
                    <div class="breadcrumb-wrapper">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a href="{{route('student.listing')}}" class="main-btn active-btn-light rounded-full btn-hover btn-sm">
                                        <i class="lni lni-arrow-left"></i>
                                        All Students
                                    </a>
                                </li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
            <!-- end row -->
        </div>


        <div class="row ">
            <!-- end col -->
            <div class="col-md-4 col-xs-12">
                <div class="card-style">
                    <div class="card-body">
                        <h5 class="card-title">Total Fee Amount</h5><br>
                        <div class="d-flex align-items-center">
                            <div class="main-btn active-btn rounded-full  btn-sm">
                                <div class="icon purple">
                                    <i class="lni lni-rupee"></i>
                                </div>
                            </div>
                            <div class="ps-3">
                                <form method="post" action="{{ route('updateTotalFee', ['id' => $data->id]) }}">
                                    @csrf
                                    <div class="input-group">
                                        <input type="number" min="1" class="form-control text-bold" name="TotalFeeAmount" value="{{ $data->TotalFeeAmount }}" disabled>
                                        <input type="hidden" name="StudentId" value="{{$data->id}}">
                                        <button class="main-btn dark-btn rounded-full btn-hover btn-sm">
                                            Update
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-4 col-xs-12">
                <div class="card-style">
                    <div class="card-body">
                        <h5 class="card-title">Paid Fee Amount</h5><br>
                        <div class="d-flex align-items-center">
                            <div class="main-btn active-btn rounded-full btn-sm">
                                <div class="icon purple">
                                    <i class="lni lni-circle-plus"></i>
                                </div>
                            </div><br><br>
                            <div class="ps-3">
                                <h6 class="text-bold">
                                    {{ $totalpaidAmount }}
                                </h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-xs-12">
                <div class="card-style">
                    <div class="card-body">
                        <h5 class="card-title">Remaining Fee Amount</h5><br>
                        <div class="d-flex align-items-center">
                            <div class="main-btn active-btn rounded-full  btn-sm">
                                <div class="icon purple">
                                    <i class="lni lni-circle-minus"></i>
                                </div>
                            </div><br><br>
                            <div class="ps-3">
                                <h6 class="text-bold">
                                    @if ($totalpaidAmount == 0)
                                    {{$data->TotalFeeAmount}}
                                    @else
                                    {{ $totalRemainingAmount }}
                                    @endif
                                </h6>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- end col -->
        <span class="divider">
        </span>
        <div class="row">
            <div class="tables-wrapper">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card-style mb-10">
                            @if (isset($totalRemainingAmount) && $totalRemainingAmount != 0)
                            <div class="d-grid gap-2 d-md-flex justify-content-md-end mb-1">
                                <a href="{{ route('feeadd',['id' => $data->id]) }}" class="main-btn dark-btn rounded-full btn-hover btn-sm">Collect Fee</a>
                            </div>
                            @endif
                            <div class="table-wrapper table-responsive">
                                <table class="table" id="data-table">
                                    <thead>
                                        <tr>
                                            <th class="text-uppercase">#</th>
                                            <th class="text-uppercase">Financial Year</th>
                                            <th class="text-uppercase">Receipt No</th>
                                            <th class="text-uppercase">Receipt Date</th>
                                            <th class="text-uppercase">Receipt Amount</th>
                                            <th class="text-uppercase print-hidden">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @if (isset($feedetails))
                                        @foreach ($feedetails as $record)
                                        <tr>
                                            <th scope="row" class="text-sm">{{ $loop->index + 1 }}</th>
                                            <td class="min-width text-sm">{{$record->FinancialYearId }}</td>
                                            <td class="min-width text-sm">{{$record->ReceiptNo }}</td>
                                            <td class="min-width text-sm">{{date('d-m-Y',strtotime($record->ReceiptDate)) }}</td>
                                            <td class="min-width text-sm">{{$record->totalAmount}}</td>

                                            <td>
                                                <div class="action">
                                                    <a href="{{ route('feereceipt.print',['id'=>$record->id ]) }}" class="text-success print-receipt" title="Print Receipt" target="_blank">
                                                        <i class="lni lni-printer"></i>
                                                    </a>
                                                    <a href="#" class="text-info" onclick="sendWhatsApp('{{ $data->MobileNumber }}', '{{ route('makepdf',['id'=>$record->id ]) }}')" title="Send via WhatsApp">
                                                        <i class="lni lni-whatsapp"></i>
                                                    </a>

                                                    <a href="{{ route('feereceipt.delete',['id'=>$record->id ]) }}" class="text-danger" onclick="return confirm('Are you sure?')" title="Delete"><i class="lni lni-trash-can"></i></a>
                                                </div>
                                            </td>
                                        </tr>
                                        @endforeach
                                        @endif
                                        @push('script')
                                        <script>
                                            function sendWhatsApp(phoneNumber, pdfLink) {
                                                var message = "Hello! I wanted to inquire about something. Here is the PDF: " + pdfLink;
                                                var url = "https://wa.me/" + phoneNumber + "?text=" + encodeURIComponent(message);
                                                window.open(url, '_blank');
                                            }
                                            $('.print-receipt').click(function(e) {
                                                e.preventDefault();
                                                var printWindow = window.open($(this).attr('href'), '_blank');
                                                printWindow.print();
                                            });
                                        </script>
                                        @endpush
                                    </tbody>
                                </table>
                                <!-- end table -->
                            </div>
                        </div>
                        <!-- end card -->
                    </div>
                    <!-- end col -->
                </div>
                <!-- end row -->
            </div>
        </div>
        <span class="divider">
        </span>
        @if (isset($totalRemainingAmount) && $totalRemainingAmount != 0)
        <div class="row">
            <div class="col-md-12">
                <div class="signup-wrapper">
                    <div class="form-wrapper">
                        <div id="messageContainer"></div>
                        <div class="row">
                            <div class="col-md-4 col-xs-12">
                                <div class="input-style-1">
                                    <label for="RemainingAmount">Remaining Amount </label>
                                    <input type="text" class="text-bold" name="RemainingAmount" id="RemainingAmount" value="{{ $totalpaidAmount === 0 ? $data->TotalFeeAmount : $totalRemainingAmount }}" readonly />

                                </div>
                            </div>
                            <div class="col-md-4 col-xs-12">
                                <div class="input-style-1">
                                    <label for="NoOfEmi" class="compulsory">No of EMI's</label>
                                    <input type="number" name="NoOfEmi" id="NoOfEmi" value="{{ old('NoOfEmi') }}" min="1" required />
                                    @error('NoOfEmi')
                                    <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-4 col-xs-12">
                                <div class="input-style-1">
                                    <label for="FromDate">From Date </label>
                                    <input type="date" name="FromDate" id="FromDate" value="{{ date('Y-m-d') }}" />
                                    @error('FromDate')
                                    <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12">
                                <button class="main-btn dark-btn rounded-full btn-hover btn-sm" onclick="calculateAndAddRows()">
                                    Calculate EMI
                                </button>
                            </div>
                        </div>

                    </div>

                </div>

            </div>
        </div>
        @endif
        <span class="divider">
        </span>
        <div class="row">
            <div class="tables-wrapper">
                <div class="row">
                    <div class="col-lg-12">
                        <div id="notification" class="notification"></div>
                        <div class="card-style mb-10">
                            @if (isset($totalRemainingAmount) && $totalRemainingAmount != 0)
                            <div class="d-grid gap-2 d-md-flex justify-content-md-end mb-1">
                                <button class="main-btn dark-btn rounded-full btn-hover btn-sm" onclick="addRow()">
                                    Add EMI
                                </button>
                            </div>
                            @endif
                            <div class="table-wrapper table-responsive">
                                <form id="emiForm" method="post" class="emi-form">
                                    <input type="hidden" name="FeeStructureId" id="feeStructureId" value="{{$data->FeeStructureId}}">
                                    <input type="hidden" name="StudentId" id="studentId" value="{{$data->id}}">
                                    <input type="hidden" name="totalRemainingAmount" id="totalRemainingAmount" value="{{ $totalpaidAmount === 0 ? $data->TotalFeeAmount : $totalRemainingAmount }}">
                                    <table class="table" id="installmentTable">
                                        <thead>
                                            <tr>
                                                <th class="text-uppercase">Installment Amount</th>
                                                <th class="text-uppercase">Installment Due Date</th>
                                                <th class="text-uppercase">Is Paid</th>
                                                <th class="text-uppercase print-hidden">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody id="emiTableBody">

                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <td colspan="1">Total :
                                                    <span>
                                                        <h4 id="SumOfFee">00.00</h4>
                                                    </span>
                                                </td>
                                            </tr>
                                        </tfoot>
                                    </table>
                                    <div class="row">
                                        <!-- end col -->

                                        <div class="col-12">
                                            <button type="button" class="main-btn dark-btn btn-saveemai rounded-full btn-hover btn-sm">
                                                Save EMI
                                            </button>
                                        </div>
                                    </div>
                                </form>
                                <!-- end table -->
                            </div>
                        </div>
                        <!-- end card -->
                    </div>
                    <!-- end col -->
                </div>
                <!-- end row -->
            </div>
        </div>
    </div>
    <!-- end container -->
</section>
<!-- ========== section end ========== -->
@push('script')
<script src="{{ url('assets/js/custom/custom.js')}}"></script>
<script>
    $(document).ready(function() {

        function showNotification(message, type) {
            // Implement your notification logic here
            console.log(type + ': ' + message);
        }

        const urlParams = new URLSearchParams(window.location.search);
        const myParam = urlParams.get('id');

        function collectEmiData() {
            var emiData = [];
            var tableRows = $('#installmentTable tbody tr');

            tableRows.each(function(index, row) {
                var columns = $(row).find('td');
                var installmentAmount = $(columns[0]).find('input').val();
                var dueDate = $(columns[1]).find('input').val();
                var isPaid = $(columns[2]).find('input').val() === 'Yes';

                emiData.push({
                    installmentAmount: installmentAmount,
                    dueDate: dueDate,
                    isPaid: isPaid
                });
            });

            return emiData;
        }

        var isFormSubmitted = false;

        $(".btn-saveemai").on("click", function(e) {
            e.preventDefault();

            if (isFormSubmitted) {
                showNotification('Data has already been saved. Refresh the page to add more EMIs.', 'error');
                return;
            }

            var emiData = collectEmiData();
            var studentId = $("#studentId").val();
            var feeStructureId = $("#feeStructureId").val();
            var totalRemainingAmount = parseFloat($("#totalRemainingAmount").val());

            if (emiData.length === 0) {
                showNotification('Please enter at least one row of EMI data.', 'error');
                return;
            }

            var totalInstallmentAmount = emiData.reduce(function(sum, emiItem) {
                if (emiItem && typeof emiItem.installmentAmount !== 'undefined') {
                    var installmentAmount = parseFloat(emiItem.installmentAmount);

                    if (!isNaN(installmentAmount)) {
                        return sum + installmentAmount;
                    }
                }
                console.log('Invalid or missing InstallmentAmount property:', emiItem);
                return sum;
            }, 0);

            if (totalRemainingAmount < totalInstallmentAmount) {
                showNotification('Adding a new installment would exceed the remaining limit.', 'error');
                return;
            }

            isFormSubmitted = true;

            $.ajax({
                url: "{{ route('emi') }}",
                method: "POST",
                contentType: "application/json",
                data: JSON.stringify({
                    _token: $('meta[name="csrf-token"]').attr("content"),
                    emiData: emiData,
                    studentId: studentId,
                    feeStructureId: feeStructureId,
                }),
                success: function(response) {
                    console.log('Success:', response);
                    showNotification('Data saved successfully!', 'success');
                    // Optionally reload the page or perform other actions
                    window.location.reload();
                },
                error: function(error) {
                    console.error('Error:', error);
                    if (error.responseJSON && error.responseJSON.errors) {
                        showNotification(Object.values(error.responseJSON.errors).flat().join('\n'), 'error');
                    } else {
                        showNotification('Error saving data. Please try again.', 'error');
                    }
                },
            });
        });


        // Function to update the total
        function updateTotal(totalAmount) {
            // Assuming you have an element with id 'totalAmount'
            $('#SumOfFee').text(totalAmount);
        }

        $.ajax({
            url: "{{ route('showemi', ['studentId' => ':studentId']) }}".replace(':studentId', myParam),
            type: 'GET',
            success: function(response) {
                var installments = response.installments;
                var tableBody = $('#installmentTable tbody');
                tableBody.empty();
                var totalAmount = 0;

                for (var i = 0; i < installments.length; i++) {
                    var installment = installments[i];
                    var installmentId = installment.id;
                    var deleteUrl = "{{ route('deleteemi', ['installmentId' => ':installmentId', 'studentId' => ':studentId']) }}"
                        .replace(':installmentId', installmentId)
                        .replace(':studentId', myParam);
                    var row = '<tr>';
                    row += '<td><input type="text" value="' + (installment.InstallmentAmount || '') + '" class="form-control installment-amount input-space" /></td>';
                    row += '<td><input type="date" value="' + (installment.InstallmentDueDate || '') + '" class="form-control installment-due-date input-space" /></td>';
                    row += '<td><input type="text" value="' + (installment.IsActive ? 'Yes' : 'No') + '" class="form-control installment-is-active input-space" disabled /></td>';
                    row += '<td><a href="' + deleteUrl + '" class="delete-link text-danger" data-installment-id="' + installmentId + '"><i class="lni lni-trash-can"></i></a></td>';
                    row += '</tr>';
                    tableBody.append(row);

                    // Add the installment amount to the total if it is a valid number
                    if (!isNaN(parseFloat(installment.InstallmentAmount))) {
                        totalAmount += parseFloat(installment.InstallmentAmount);
                    }
                }
                // Update total after adding or modifying rows
                updateTotal(totalAmount);

            },
            error: function(error) {
                showNotification(error.responseJSON.message, 'error');
            }
        });

        function showNotification(message, type = 'success') {
            var notificationElement = document.getElementById('notification');

            if (type === 'success') {
                notificationElement.style.backgroundColor = '#4caf50';
            } else if (type === 'error') {
                notificationElement.style.backgroundColor = '#f44336';
            }

            notificationElement.innerText = message;
            notificationElement.style.display = 'block';

            setTimeout(function() {
                notificationElement.style.display = 'none';
            }, 5000);
        }

    });
</script>

@endpush


@endsection