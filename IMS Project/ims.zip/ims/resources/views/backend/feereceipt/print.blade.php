﻿
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Fee Receipt</title>

    <link rel="stylesheet" href="{{ url('assets/css/bootstrap.min.css')}}" />
    <link rel="stylesheet" href="{{ url('assets/css/print.css')}}" />


</head>

<body>
    <div class="container mt-5 custom-container">
        <div class="row">
            <div class="col-md-8" style="display: flex;">
                <img class="col-md-1 logo-for-print" style="margin-left: 130px;margin-right: 40px;" src="{{ $instituteLogoPath }}" width="130px" alt="Institute Logo">
                <div class="col-md-4  card">
                    <div class="card-body text-container">
                        <h1><b>{{$studentDetails->institute_name}}</b></h1>
                        <h4><b>Payment Receipt</b></h4>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-2 offset-10">
                <div class="card">
                    <div class="card-body">
                        <h5><b>Receipt No.: <b> {{$receipt->ReceiptNo}}</b></b></h5>
                        <h5><b>Date: <b></b>{{date('d/M/Y',strtotime($receipt->ReceiptDate))}}</b></h5>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-10 offset-2">
                <div class="card">
                    <div class="card-body">
                        <h5>
                            <b>
                                Received From
                                Ms/Mr. <b>{{$studentDetails->FirstName." ".$studentDetails->LastName }}</b>
                            </b>
                        </h5>
                        <h5>
                            <b>
                                Course
                                Name: <b>{{$studentDetails->course_name}}</b>
                            </b>
                        </h5>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-9 offset-2">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th class="col-md-9 text-center">Particulars</th>
                            <th class="col-md-3 text-center">Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        @php
                        $totalAmount = 0;
                        @endphp
                        @if (isset($details))
                        @foreach ($details as $detail )
                        <tr>
                            <td>{{$detail->fee_head_name}}</td>
                            <td>{{$detail->Amount}}/-</td>
                        </tr>
                        @php
                        $totalAmount += $detail->Amount;
                        @endphp
                        @endforeach
                        @endif
                        <tr>
                            <td class="text-end"><b>Total</b></td>
                            <td>{{$totalAmount}}/-</td>
                        </tr>
                    </tbody>
                </table>

            </div>
        </div>
        <div class="row">
            <div class="col-md-10 offset-2">
                <div class="card">
                    <div class="card-body">
                        <h5>
                            <b>
                                Payment Mode:
                                <b>{{$receipt->PaymentMode}}</b>
                            </b>
                        </h5>
                        <h5>
                            <b>
                                Payment Ref No/ Cheque No.
                                <b>{{$receipt->ChequeNoOrUtr}}</b>
                            </b>
                        </h5>
                        <h5>
                            <b>
                                Received By: Name & Sign.
                                <b>{{$receipt->created_by_name}}</b>
                            </b>
                        </h5>
                        <h6><b>1.The payment is subject to realisation</b></h6>
                        <h6>
                            <b>2. The above payment is non-refundable / non-transferrable includes applicable taxes</b>
                        </h6>
                        <h4>
                            <hr />
                        </h4>
                        <h5>
                            <b>
                                &nbsp; &nbsp;&nbsp;401, Ship Square B, Opp. Sales India, Nr. Himalaya Mall, Drivein road.
                                Ahmedabad
                            </b>
                        </h5>
                        <h5 class="text-center"><b>Call: 9825303436 | 9033222499</b></h5>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!--Student Copy-->
    <div class="container mt-3 custom-container">
        <div class="row">
            <div class="col-md-8" style="display: flex;">
                <img class="col-md-1" style="margin-left: 120px;margin-right: 40px;" src="{{ $instituteLogoPath }}" width="130px" alt="Institute Logo">
                <div class="col-md-4  card">
                    <div class="card-body text-container">
                        <h1><b>{{$studentDetails->institute_name}}</b></h1>
                        <h4><b>Payment Receipt</b></h4>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-2 offset-10">
                <div class="card">
                    <div class="card-body">
                        <h5><b>Receipt No.: <b> {{$receipt->ReceiptNo}}</b></b></h5>
                        <h5><b>Date: <b></b>{{date('d/M/Y',strtotime($receipt->ReceiptDate))}}</b></h5>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-10 offset-2">
                <div class="card">
                    <div class="card-body">
                        <h5>
                            <b>
                                Received From
                                Ms/Mr. <b>{{$studentDetails->FirstName." ".$studentDetails->LastName }}</b>
                            </b>
                        </h5>
                        <h5>
                            <b>
                                Course
                                Name: <b>{{$studentDetails->course_name}}</b>
                            </b>
                        </h5>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-9 offset-2">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th class="col-md-9 text-center">Particulars</th>
                            <th class="col-md-3 text-center">Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        @php
                        $totalAmount = 0;
                        @endphp
                        @if (isset($details))
                        @foreach ($details as $detail )
                        <tr>
                            <td>{{$detail->fee_head_name}}</td>
                            <td>{{$detail->Amount}}/-</td>
                        </tr>
                        @php
                        $totalAmount += $detail->Amount;
                        @endphp
                        @endforeach
                        @endif
                        <tr>
                            <td class="text-end"><b>Total</b></td>
                            <td>{{$totalAmount}}/-</td>
                        </tr>
                    </tbody>
                </table>

            </div>
        </div>
        <div class="row">
            <div class="col-md-10 offset-2">
                <div class="card">
                    <div class="card-body">
                        <h5>
                            <b>
                                Payment Mode:
                                <b>{{$receipt->PaymentMode}}</b>
                            </b>
                        </h5>
                        <h5>
                            <b>
                                Payment Ref No/ Cheque No.
                                <b>{{$receipt->ChequeNoOrUtr}}</b>
                            </b>
                        </h5>
                        <h5>
                            <b>
                                Received By: Name & Sign.
                                <b>{{$receipt->created_by_name}}</b>
                            </b>
                        </h5>
                        <h6><b>1.The payment is subject to realisation</b></h6>
                        <h6>
                            <b>2. The above payment is non-refundable / non-transferrable includes applicable taxes</b>
                        </h6>
                        <h4>
                            <hr />
                        </h4>
                        <h5>
                            <b>
                                &nbsp; &nbsp;&nbsp;401, Ship Square B, Opp. Sales India, Nr. Himalaya Mall, Drivein road.
                                Ahmedabad
                            </b>
                        </h5>
                        <h5 class="text-center"><b>Call: 9825303436 | 9033222499</b></h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Bootstrap JS and Popper.js are required for Bootstrap components -->
    <script src="{{ url('assets/js/bootstrap.bundle.min.js')}}"></script>
    <script src="{{ url('assets/js/jquery-3.7.1.min.js')}}"></script>


</body>

</html>