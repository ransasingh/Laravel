@extends('layout.admin_layout')
@section('title', 'Student Fee')
@section('dashboard')
<!-- ========== section start ========== -->
<section class="section">
    <div class="container-fluid">

    @if(session('error'))
        <div class="alert alert-danger alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('error') }}
        </div>
        @endif

        @if(session('success'))
        <div class="alert alert-success alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('success') }}
        </div>
        @endif


        <!-- ========== title-wrapper start ========== -->
        <div class="title-wrapper pt-30">
            <div class="row align-items-center">
                <div class="col-md-9">
                    <div class="title">
                        <h2>Update Student Fee</h2>
                    </div>
                    <ul class="nav nav-tabs" id="myTabs">
                        <li class="nav-item">
                            <a class="nav-link{{ request()->is('student/show*') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('student.show',['id' => request('id')]) }}">Student Info</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link{{ request()->is('studentcourse/detail*') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('studentcourse.detail',['id' => request('id')]) }}">Course Details</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link{{ request()->is('feereceipt/detail*') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('feereceipt.detail',['id' => request('id')]) }}">Fee Details</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link{{ request()->is('student/calender*') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('student.calender',['id' => request('id')]) }}">Calender</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link{{ request()->routeIs('student.PortfolioSubmission') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('student.PortfolioSubmission',['id' => request('id')]) }}">Portfolio Submission</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link{{ request()->routeIs('student.batchcompletion') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('student.batchcompletion',['id' => request('id')]) }}">Batch Completion</a>
                        </li>
                    </ul>
                </div>

            </div>
            <!-- end row -->
        </div>


        <div class="row ">
            <!-- end col -->
            <div class="col-md-4 col-xs-12">
                <div class="card-style">
                    <div class="card-body">
                        <h5 class="card-title">Total Fee Amount</h5><br>
                        <div class="d-flex align-items-center">
                            <div class="main-btn active-btn rounded-full  btn-sm">
                                <div class="icon purple">
                                    <i class="lni lni-rupee"></i>
                                </div>
                            </div>
                            <div class="ps-3">
                                <h6 class="text-bold">
                                    {{ $data->TotalFeeAmount }}
                                </h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
          
            <div class="col-md-4 col-xs-12">
                <div class="card-style">
                    <div class="card-body">
                        <h5 class="card-title">Paid Fee Amount</h5><br>
                        <div class="d-flex align-items-center">
                            <div class="main-btn active-btn rounded-full btn-sm">
                                <div class="icon purple">
                                    <i class="lni lni-circle-plus"></i>
                                </div>
                            </div><br><br>
                            <div class="ps-3">
                                <h6 class="text-bold">
                                    {{ $totalpaidAmount }}
                                </h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-xs-12">
                <div class="card-style">
                    <div class="card-body">
                        <h5 class="card-title">Remaining Fee Amount</h5><br>
                        <div class="d-flex align-items-center">
                            <div class="main-btn active-btn rounded-full  btn-sm">
                                <div class="icon purple">
                                    <i class="lni lni-circle-minus"></i>
                                </div>
                            </div><br><br>
                            <div class="ps-3">
                                <h6 class="text-bold">
                                    @if ($totalpaidAmount == 0)
                                    {{$data->TotalFeeAmount}}
                                    @else
                                    {{ $totalRemainingAmount }}
                                    @endif
                                </h6>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- end col -->
        <span class="divider">
        </span>
        <div class="row">
            <div class="tables-wrapper">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card-style mb-10">
                            <div class="table-wrapper table-responsive">
                                <table class="table">
                                    <thead>
                                    <tr class="text-sm">
                                            <th class="text-uppercase">#</th>
                                            <th class="text-uppercase">Financial Year</th>
                                            <th class="text-uppercase">Receipt No</th>
                                            <th class="text-uppercase">Receipt Date</th>
                                            <th class="text-uppercase">Receipt Amount</th>
                                            <th class="text-uppercase print-hidden">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @if (isset($feedetails))
                                        @foreach ($feedetails as $record)
                                        <tr>
                                            <th scope="row" class="text-sm">{{ $loop->index + 1 }}</th>
                                            <td class="min-width text-sm">{{$record->FinancialYearId }}</td>
                                            <td class="min-width text-sm">{{$record->ReceiptNo }}</td>
                                            <td class="min-width text-sm">{{date('d-m-Y',strtotime($record->ReceiptDate)) }}</td>
                                            <td class="min-width text-sm">{{$record->totalAmount}}</td>

                                            <td>
                                                <div class="action">
                                                    <a href="{{ route('feereceipt.print',['id'=>$record->id ]) }}" class="text-success print-receipt" title="Print Receipt" target="_blank">
                                                        <i class="lni lni-printer"></i>
                                                    </a>

                                                </div>
                                            </td>
                                        </tr>
                                        @endforeach
                                        @endif
                                        @push('script')
                                        <script>
                                            $('.print-receipt').click(function(e) {
                                                e.preventDefault();
                                                var printWindow = window.open($(this).attr('href'), '_blank');
                                                printWindow.print();
                                            });
                                        </script>
                                        @endpush
                                    </tbody>
                                </table>
                                <!-- end table -->
                            </div>
                        </div>
                        <!-- end card -->
                    </div>
                    <!-- end col -->
                </div>
                <!-- end row -->
            </div>
        </div>

        <span class="divider">
        </span>
        <div class="row">
            <div class="tables-wrapper">
                <div class="row">
                    <div class="col-lg-12">
                        <div id="notification" class="notification"></div>
                        <div class="card-style mb-10">
                            <div class="table-wrapper table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr class="text-sm">
                                            <th class="text-uppercase">#</th>
                                            <th class="text-uppercase">Installment Amount</th>
                                            <th class="text-uppercase">Installment Due Date</th>
                                            <th class="text-uppercase">Is Paid</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @if (isset($installments))
                                        @foreach ($installments as $record)
                                        <tr>
                                            <th scope="row" class="text-sm">{{ $loop->index + 1 }}</th>
                                            <td class="min-width text-sm">{{$record->InstallmentAmount}}</td>
                                            <td class="min-width text-sm">{{date('d-M-Y',strtotime($record->InstallmentDueDate)) }}</td>
                                            <td class="min-width text-sm">
                                                @if($record->IsActive == 1)
                                                <span class="status-btn active-btn" title="Yes">Yes</span>
                                                @else
                                                <span class="status-btn close-btn" title="No">No</span>
                                                @endif
                                            </td>
                                        </tr>
                                        @endforeach
                                        @endif
                                    </tbody>
                                    <tfoot>

                                        <tr>
                                            <td colspan="1">Total :
                                                <span>
                                            <td class="min-width text-sm">{{$totalInstallmentAmount }}</td>
                                            </span>
                                            </td>
                                        </tr>
                                    </tfoot>
                                </table>

                                </form>
                                <!-- end table -->
                            </div>
                        </div>
                        <!-- end card -->
                    </div>
                    <!-- end col -->
                </div>
                <!-- end row -->
            </div>
        </div>
    </div>
    <!-- end container -->
</section>
<!-- ========== section end ========== -->
@push('script')
<script src="{{ url('assets/js/custom/custom.js')}}"></script>

@endpush


@endsection