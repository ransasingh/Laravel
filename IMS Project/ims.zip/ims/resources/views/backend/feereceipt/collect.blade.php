@extends('layout.admin_layout')
@section('title', 'Student Fee')
@section('dashboard')
<!-- ========== section start ========== -->
<section class="section">
    <div class="container-fluid">

    @if(session('error'))
        <div class="alert alert-danger alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('error') }}
        </div>
        @endif

        @if(session('success'))
        <div class="alert alert-success alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('success') }}
        </div>
        @endif


        <!-- ========== title-wrapper start ========== -->
        <div class="title-wrapper pt-30">
            <div class="row align-items-center">
                <div class="col-md-9">
                    <div class="title">
                        <h2>Add Fee Receipt</h2>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="breadcrumb-wrapper">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a href="{{ url()->previous() }}" class="main-btn active-btn-light rounded-full btn-hover btn-sm">
                                        <i class="lni lni-arrow-left"></i>
                                        Back
                                    </a>
                                </li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
            <!-- end row -->
        </div>

        <!-- end col -->
        <div class="col-md-12">
            <div class="signup-wrapper">
                <div class="form-wrapper">
                    <form action="{{ route('feereceipt.addnew') }}" method="post">
                        @csrf
                        <div class="row mb-3 text-bold">
                            <div class="col-md-2 col-xs-12"> Student :</div>
                            <input type="hidden" name="StudentId" value="{{$student->id}}">
                            <input type="hidden" name="FinancialYearId" value="{{$finacialyearname}}">
                            <div class="col-md-4 col-xs-12">{{$student->FirstName}} {{$student->LastName}}</div>
                            <div class="col-md-2 col-xs-12"> Financial Year :</div>
                            <div class="col-md-4 col-xs-12"> {{$finacialyearname}}</div>
                        </div>
                        <div class="row mb-3 text-bold">
                            <div class="col-md-2 col-xs-12">Receipt No :</div>
                            <div class="col-md-4 col-xs-12">{{$finacialyearname}}</div>
                            <div class="col-md-2 col-xs-12">Course :</div>
                            <div class="col-md-4 col-xs-12">{{$student->course_name}}</div>
                        </div>
                        <div class="row mb-3 text-bold">
                            <label class="col-md-2 col-xs-12" for="ReceiptDate">Receipt Date :</label>
                            <div class="col-md-4 col-xs-12">
                                <input class="form-control" id="ReceiptDate" name="ReceiptDate" type="date" value="{{ date('Y-m-d') }}" />
                                @error('ReceiptDate')
                                <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                            <div class="col-md-2 col-xs-12">Total Fee :</div>
                            <div class="col-md-4 col-xs-12">{{number_format($student->TotalFeeAmount, 2)}}</div>
                        </div>
                        @php
                        $totalPaidFee = 0;
                        $totalRemainingFee = 0;
                        @endphp
                        @foreach ($feeheads as $feeHead)
                        @php
                        $totalPaidFee += $feeHead->PaidAmount ?? 0;
                        $totalRemainingFee += $feeHead->RemainingAmount ?? 0;
                        @endphp
                        @endforeach
                        <div class="row mb-3 text-bold">
                            <div class="col-md-2 col-xs-12">Total Paid Fee :</div>
                            <div class="col-md-4 col-xs-12">{{ number_format($totalPaidFee, 2) }}</div>

                            <div class="col-md-2 col-xs-12 text-sm ">Total Remaining Fee :</div>
                            <div class="col-md-4 col-xs-12">{{ number_format($totalRemainingFee, 2) }}</div>
                        </div>

                        <div class="row mb-3 text-bold">
                            <div class="col-md-2 col-xs-12">Payment Mode :</div>
                            <div class="col-md-4 col-xs-12">
                                <select class="form-control" id="PaymentMode" name="PaymentMode">
                                    <option value="Cash" {{old('PaymentMode') == 'CA' ? 'selected' : ''}}>Cash</option>
                                    <option value="Cheque" {{old('PaymentMode') == 'CH' ? 'selected' : ''}}>Cheque</option>
                                    <option value="Online" {{old('PaymentMode') == 'Ol' ? 'selected' : ''}}>Online</option>
                                </select>
                                @error('PaymentMode')
                                <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>

                            <div class="col-md-2 col-xs-12 text-sm">Cheque No or UTR :</div>
                            <div class="col-md-4 col-xs-12">
                                <input class="form-control" id="ChequeNoOrUtr" name="ChequeNoOrUtr" type="text" value="{{old('ChequeNoOrUtr')}}" />
                                @error('ChequeNoOrUtr')
                                <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <div class="row mb-3 text-bold">
                            <div class="col-md-2 col-xs-12">Cheque Date :</div>
                            <div class="col-md-4 col-xs-12">
                                <input class="form-control" id="ChequeDate" name="ChequeDate" type="date" value="{{old('ChequeDate')}}" />
                                @error('ChequeDate')
                                <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                            <div class="col-md-2 col-xs-12 compulsory"> Firm :</div>
                            <div class="col-md-4 col-xs-12">
                                <select class="form-control" id="BankId" name="BankId" required="required">
                                    <option selected disabled>--Select--</option>
                                    @if (isset($firms))
                                    @foreach ($firms as $firm )
                                    <option value="{{$firm->id}}" {{old('BankId') == $firm->id ? 'selected': ''}}>{{$firm->Code.'-'.$firm->Name}}</option>
                                    @endforeach
                                    @endif

                                </select>
                                @error('BankId')
                                <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>
                        <hr>
                        <table name="FeeStrucMap" class="table">
                            <thead>
                            <tr class="text-sm">
                                    <th>Fee Head</th>
                                    <th>Total Amount</th>
                                    <th>Remaining Amount</th>
                                    <th>Pay Amount</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- Use a foreach loop to generate rows dynamically -->
                                @if (isset($feeheads))
                                @foreach ($feeheads as $feeHead)
                                <tr>
                                    <td>{{ $feeHead->FeeHeadName }}</td>
                                    <td>{{ $feeHead->Amount }}</td>
                                    <td>
                                        @if ($feeHead->PaidAmount !== null)
                                        {{ $feeHead->RemainingAmount }}
                                        @else
                                        {{ $feeHead->Amount ?? 'N/A' }}
                                        @endif
                                    </td>
                                    <td>
                                        <input type="number" class="fee-input form-control" name="FeeHeadId[{{ $feeHead->FeeHeadId }}]" value="{{ old('FeeHeadId.' . $feeHead->FeeHeadId, $feeHead->RemainingAmount ?? 0) }}" min="0" @if ($feeHead->PaidAmount !== null)
                                        max="{{ $feeHead->RemainingAmount }}"
                                        @else
                                        max="{{ $feeHead->Amount ?? '0' }}"
                                        @endif/>
                                        <input type="hidden" name="feeHeadRemainingAmount" value="{{ $feeHead->RemainingAmount }}">
                                        @error('FeeHeadId.' . $feeHead->FeeHeadId)
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                        <input type="hidden" name="FeeStructureId" value="{{ $feeHead->FeeStructureId }}">
                                    </td>
                                </tr>
                                @endforeach
                                @endif
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="3" style="text-align:end">Total :</td>
                                    <td>
                                        <h4 id="SumOfFee">00.00</h4>
                                    </td>
                                </tr>
                            </tfoot>
                        </table>


                        <div class="row">
                            <!-- end col -->

                            <div class="col-12">
                                <button class="main-btn dark-btn rounded-full btn-hover btn-sm">
                                    Submit
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!-- end container -->
</section>
<!-- ========== section end ========== -->
@push('script')
<script src="{{ url('assets/js/custom/custom.js')}}"></script>

@endpush


@endsection