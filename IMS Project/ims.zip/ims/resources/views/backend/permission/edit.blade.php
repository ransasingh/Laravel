@extends('layout.admin_layout')

@section('dashboard')

<!-- ========== table components start ========== -->
<section class="table-components">
    <div class="container-fluid">
    @if($errors->any())
        <div class="alert alert-danger alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            <ul>
                @foreach($errors->all() as $error)
                <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
        @endif

        @if(session('error'))
        <div class="alert alert-danger alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('error') }}
        </div>
        @endif

        @if(session('success'))
        <div class="alert alert-success alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('success') }}
        </div>
        @endif


        <!-- ========== title-wrapper start ========== -->
        <div class="title-wrapper pt-10">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <div class="title">
                        <h2>Update Role</h2>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="breadcrumb-wrapper">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a href="{{route('role.listing')}}" class="main-btn active-btn-light rounded-full btn-hover btn-sm">
                                        <i class="lni lni-arrow-left"></i>
                                        All Roles
                                    </a>
                                </li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
            <!-- end row -->
        </div>
        <!-- ========== title-wrapper end ========== -->

        <!-- ========== tables-wrapper start ========== -->
        <div class="row g-0 auth-row">
            <!-- end col -->
            <div class="col-lg-6">
                <div class="signup-wrapper">
                    <div class="form-wrapper">
                        <form action="{{ route('role.editrole',['id' =>$data->id]) }}" method="post">
                            @csrf
                            <div class="row">
                                <div class="col-12">
                                    <div class="input-style-1">
                                        <label id="name">Name</label>
                                        <input type="text" name="name" id="name" value="{{$data->name}}" />
                                    </div>
                                </div>
                                <!-- end col -->
                                <div class="col-12">
                                    <div class="input-style-1">
                                        <label for="slug">Slug</label>
                                        <input type="slug" name="slug" id="slug" value="{{$data->slug}}" />
                                    </div>
                                </div>

                                <div class="col-12">
                                    <div class="button-group d-flex justify-content-center flex-wrap">
                                        <button class="main-btn primary-btn btn-hover w-100 text-center">
                                            Update
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <!-- end row -->
                        </form>

                    </div>
                </div>
            </div>
            <!-- end col -->
        </div>
        <!-- ========== tables-wrapper end ========== -->
    </div>
    <!-- end container -->
</section>
<!-- ========== table components end ========== -->

@push('script')
<script type="text/javascript">
    $(function() {
        var table = $('#data-table').DataTable({
            lengthMenu: [10, 25, 50, 75, 100],
            processing: true,
            serverSide: true,
            responsive: true,
            ajax: "{{ route('users.listing') }}",
            columns: [{
                    data: null,
                    render: function(data, type, row, meta) {
                        // Calculate the series number based on the current page and page length
                        var seriesNumber = meta.row + meta.settings._iDisplayStart + 1;
                        return seriesNumber;
                    },
                    name: 'id',
                    className: 'text-center',
                },
                {
                    data: 'name',
                    name: 'name'
                },
                {
                    data: 'mobile',
                    name: 'mobile'
                },
                {
                    data: 'email',
                    name: 'email'
                },
                {
                    data: 'role',
                    name: 'role'
                },

                {
                    data: null,
                    render: function(data, type, row) {
                        var editUrl = "";
                        "{{-- route('users.edit', ['id' => ':id']) --}}" //.replace(':id', row.id);
                        return `
                        <a href="${editUrl}" class="btn btn-xs btn-round btn-border btn-primary"><i class="lni lni-eye"></i></a>`;
                    },
                    orderable: false,
                    searchable: false,
                    className: 'text-center'
                },
            ]
        });
    });
</script>
@endpush

@endsection