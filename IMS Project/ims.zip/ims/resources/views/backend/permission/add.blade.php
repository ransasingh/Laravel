@extends('layout.admin_layout')

@section('dashboard')

<!-- ========== table components start ========== -->
<section class="table-components">
    <div class="container-fluid">
        @if($errors->any())
        <div class="alert alert-danger alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            <ul>
                @foreach($errors->all() as $error)
                <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
        @endif

        @if(session('error'))
        <div class="alert alert-danger alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('error') }}
        </div>
        @endif

        @if(session('success'))
        <div class="alert alert-success alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('success') }}
        </div>
        @endif


        <!-- ========== title-wrapper start ========== -->
        <div class="title-wrapper pt-10">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <div class="title">
                        <h2>Add New Permission</h2>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="breadcrumb-wrapper">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a href="{{route('permission.listing')}}" class="main-btn active-btn-light rounded-full btn-hover btn-sm">
                                        <i class="lni lni-arrow-left"></i>
                                        All Permission
                                    </a>
                                </li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
            <!-- end row -->
        </div>
        <!-- ========== title-wrapper end ========== -->

        <!-- ========== tables-wrapper start ========== -->
        <div class="row g-0 auth-row">
            <!-- end col -->
            <div class="col-lg-6">
                <div class="signup-wrapper">
                    <div class="form-wrapper">
                        <form action="{{ route('permission.addnew') }}" method="post">
                            @csrf
                            <div class="row">
                                <div class="col-12">
                                    <div class="input-style-1">
                                        <label id="name">Name</label>
                                        <input type="text" name="name" id="name" value="{{ old('name') }}" placeholder="Name" />
                                    </div>
                                </div>
                                <!-- end col -->
                                <div class="col-12">
                                    <div class="input-style-1">
                                        <label for="slug">Slug</label>
                                        <input type="slug" name="slug" id="slug" value="{{ old('slug') }}" placeholder="slug" />
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-12">
                                        <button class="main-btn primary-btn-light rounded-full btn-hover btn-sm">
                                            Submit
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <!-- end row -->
                        </form>

                    </div>
                </div>
            </div>
            <!-- end col -->
        </div>
        <!-- ========== tables-wrapper end ========== -->
    </div>
    <!-- end container -->
</section>
<!-- ========== table components end ========== -->



@endsection