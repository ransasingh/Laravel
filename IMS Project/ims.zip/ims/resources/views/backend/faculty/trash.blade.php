@extends('layout.admin_layout')
@section('title', 'Faculty Trash Listing')
@section('dashboard')

<!-- ========== table components start ========== -->
<section class="table-components">
    <div class="container-fluid">
        
    @if(session('error'))
        <div class="alert alert-danger alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('error') }}
        </div>
        @endif

        @if(session('success'))
        <div class="alert alert-success alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('success') }}
        </div>
        @endif

        <!-- ========== title-wrapper start ========== -->
        <div class="title-wrapper pt-30">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <div class="title">
                        <h2>Faculty Trash Listing</h2>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="breadcrumb-wrapper">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a href="{{route('faculty.listing')}}" class="main-btn active-btn-light rounded-full btn-hover btn-sm">
                                        <i class="lni lni-arrow-left"></i>
                                        All Faculty
                                    </a>
                                </li>
                            </ol>
                        </nav>
                    </div>
                </div>

            </div>
            <!-- end row -->
        </div>
        <!-- ========== title-wrapper end ========== -->

        <!-- ========== tables-wrapper start ========== -->
        <div class="tables-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card-style mb-30">

                        <div class="table-wrapper table-responsive">
                            <table class="table" id="data-table">
                                <thead>
                                <tr class="text-sm">
                                        <th class="text-uppercase">#</th>
                                        <th class="text-uppercase">Profile Image</th>
                                        <th class="text-uppercase">First Name</th>
                                        <th class="text-uppercase">Last Name</th>
                                        <th class="text-uppercase">Mobile</th>
                                        <th class="text-uppercase">Email</th>
                                        <th class="text-uppercase">StateName</th>
                                        <th class="text-uppercase">City</th>
                                        <th class="text-uppercase">Status</th>
                                        <th class="text-uppercase print-hidden">Action</th>
                                    </tr>
                                    <!-- end table row-->
                                </thead>
                                <tbody>
                                    @if (isset($data))
                                    @foreach ($data as $record)
                                    <tr>
                                        <th scope="row" class="text-sm">{{ $loop->index + 1 }}</th>
                                        <td class="min-width text-sm">
                                            <div class="rounded-circle overflow-hidden" style="width: 65px; height: 65px;">
                                                @if($record->ProfileImage && file_exists(public_path('uploads/faculty/profile/' . $record->ProfileImage)))
                                                <img src="{{ asset('uploads/faculty/profile/' . $record->ProfileImage) }}" alt="Profile Image" class="img-fluid" style="object-fit: cover; width: 100%; height: 100%;">
                                                @else
                                                <img src="{{ url('assets/images/default/user_image.png')}}" alt="Default Image" class="img-fluid" style="object-fit: cover; width: 100%; height: 100%;">
                                                @endif
                                            </div>
                                        </td>
                                        <td class="min-width text-sm">{{$record->FirstName }}</td>
                                        <td class="min-width text-sm">{{$record->LastName }}</td>
                                        <td class="min-width text-sm">{{$record->MobileNumber }}</td>
                                        <td class="min-width text-sm">{{$record->EmailId }}</td>
                                        <td class="min-width text-sm">{{$record->state_name }}</td>
                                        <td class="min-width text-sm">{{$record->CityName }}</td>
                                        <td class="min-width text-sm">
                                            @if($record->IsActive == 1)
                                            <span class="status-btn active-btn" title="Active">Active</span>
                                            @else
                                            <span class="status-btn close-btn" title="Inactive">Inactive</span>
                                            @endif
                                        </td>
                                        <td>
                                            <div class="action">
                                                <a href="{{ route('faculty.restore',['id'=>$record->id ]) }}" class="text-primary" title="Restore"><i class="lni lni-spinner-arrow"></i></a>
                                                <a href="{{ route('faculty.delete',['id'=>$record->id ]) }}" class="text-danger" onclick="return confirm('Are you sure?')" title="Delete"><i class="lni lni-trash-can"></i></a>
                                            </div>
                                    </tr>
                                    @endforeach
                                    @endif
                                </tbody>
                            </table>
                            <!-- end table -->
                        </div>
                    </div>
                    <!-- end card -->
                </div>
                <!-- end col -->
            </div>
            <!-- end row -->
        </div>
        <!-- ========== tables-wrapper end ========== -->
    </div>
    <!-- end container -->
</section>
<!-- ========== table components end ========== -->



@endsection