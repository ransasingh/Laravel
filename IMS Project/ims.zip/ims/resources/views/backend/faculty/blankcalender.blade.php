@extends('layout.admin_layout')
@section('title', 'Faculty Calendar')
@section('css')
<link rel="stylesheet" href="{{ url('assets/css/custom.css') }}">
@endsection

@section('dashboard')

<!-- ========== section start ========== -->
<section class="section">
    <div class="container-fluid">

        @if(session('error'))
        <div class="alert alert-danger alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('error') }}
        </div>
        @endif

        @if(session('success'))
        <div class="alert alert-success alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('success') }}
        </div>
        @endif

        <!-- ========== title-wrapper start ========== -->
        <div class="title-wrapper pt-30">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <div class="title">
                        <h2>Update Faculty</h2>
                    </div>
                    <ul class="nav nav-tabs" id="myTabs">
                        @php
                        $userRole = auth()->user()->RoleId;
                        @endphp
                        @if ($userRole == 3)
                        <li class="nav-item">
                            <a class="nav-link{{ request()->is('faculty/show*') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('faculty.show',['id' => request('id')]) }}">Faculty Info</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link{{ request()->is('faculty/calender/add*') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('faculty.calender.add',['id' => request('id')])}}">Calendar</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link{{ request()->is('faculty/PortfolioSubmission*') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('faculty.PortfolioSubmission',['id' => request('id')]) }}">Portfolio Submission</a>
                        </li>
                        @else
                        <li class="nav-item">
                            <a class="nav-link{{ request()->is('faculty/edit*') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('faculty.edit',['id' => request('id')]) }}">Faculty Info</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link{{ request()->is('faculty/calender/add*') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('faculty.calender.add',['id' => request('id')]) }}">Calendar</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link{{ request()->is('faculty/PortfolioSubmission*') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('faculty.PortfolioSubmission',['id' => request('id')]) }}">Portfolio Submission</a>
                        </li>
                        @endif
                    </ul>
                </div>
                @if ($userRole != 3)
                <div class="col-md-6">
                    <div class="breadcrumb-wrapper">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a href="{{route('faculty.listing')}}" class="main-btn active-btn-light rounded-full btn-hover btn-sm">
                                        <i class="lni lni-arrow-left"></i>
                                        All Faculty
                                    </a>
                                </li>
                            </ol>
                        </nav>
                    </div>
                </div>
                @endif
            </div>

            <div class="row g-0 auth-row">
                <div class="card-style calendar-card mb-40">
                    <div id="calendar-mini"></div>
                </div>
            </div>
        </div>
        <!-- end container -->
</section>
<!-- ========== section end ========== -->

@endsection

@push('script')
<script>
    document.addEventListener("DOMContentLoaded", function() {
        var calendarMiniEl = document.getElementById("calendar-mini");

        var calendarMini = new FullCalendar.Calendar(calendarMiniEl, {
            initialView: "dayGridMonth",
            events: [] // Empty array of events
        });

        calendarMini.render();
    });
</script>
@endpush