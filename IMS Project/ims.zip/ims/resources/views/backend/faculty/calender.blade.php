@extends('layout.admin_layout')
@section('title', 'Faculty Calender')
@section('css')
<link rel="stylesheet" href="{{ url('assets/css/custom.css') }}">
@endsection

@section('dashboard')

<!-- ========== section start ========== -->
<section class="section">
    <div class="container-fluid">

        @if(session('error'))
        <div class="alert alert-danger alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('error') }}
        </div>
        @endif

        @if(session('success'))
        <div class="alert alert-success alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('success') }}
        </div>
        @endif


        <!-- ========== title-wrapper start ========== -->
        <div class="title-wrapper pt-30">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <div class="title">
                        <h2>Update Faculty</h2>
                    </div>
                    <ul class="nav nav-tabs" id="myTabs">
                        @php
                        $userRole = auth()->user()->RoleId;
                        @endphp
                        @if ($userRole == 3)
                        <li class="nav-item">
                            <a class="nav-link{{ request()->is('faculty/show*') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('faculty.show',['id' => request('id')]) }}">Faculty Info</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link{{ request()->is('faculty/calender/add*') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('faculty.calender.add',['id' => request('id')])}}">Calendar</a>
                        </li>
                         <li class="nav-item">
                            <a class="nav-link{{ request()->is('faculty/PortfolioSubmission*') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('faculty.PortfolioSubmission',['id' => request('id')]) }}">Portfolio Submission</a>
                        </li>
                        @else
                        <li class="nav-item">
                            <a class="nav-link{{ request()->is('faculty/edit*') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('faculty.edit',['id' => request('id')]) }}">Faculty Info</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link{{ request()->is('faculty/calender/add*') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('faculty.calender.add',['id' => request('id')]) }}">Calendar</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link{{ request()->is('faculty/PortfolioSubmission*') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('faculty.PortfolioSubmission',['id' => request('id')]) }}">Portfolio Submission</a>
                        </li>
                        @endif


                    </ul>

                </div>
                @if ($userRole != 3)
                <div class="col-md-6">
                    <div class="breadcrumb-wrapper">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a href="{{route('faculty.listing')}}" class="main-btn active-btn-light rounded-full btn-hover btn-sm">
                                        <i class="lni lni-arrow-left"></i>
                                        All Faculty
                                    </a>
                                </li>
                            </ol>
                        </nav>
                    </div>
                </div>
                @endif
            </div>
            <!-- end row -->
        </div>
        <div class="row g-0 auth-row">

            <div class="card-style calendar-card mb-40">
                <div id="calendar-mini"></div>
            </div>

        </div>

    </div>
    <!-- end container -->
</section>
<!-- Batch Detail Modal -->
<div class="modal fade" id="batchDetailModal" tabindex="-1" aria-labelledby="batchDetailModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="batchDetailModalLabel">Batch Detail</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <dl class="row">
                    <dt class="col-sm-4">Name</dt>
                    <dd class="col-sm-8" id="batchName"></dd>

                    <dt class="col-sm-4">From Date</dt>
                    <dd class="col-sm-8" id="fromDate"></dd>

                    <dt class="col-sm-4">To Date</dt>
                    <dd class="col-sm-8" id="toDate"></dd>

                    <dt class="col-sm-4">Start At</dt>
                    <dd class="col-sm-8" id="startTime"></dd>

                    <dt class="col-sm-4">End At</dt>
                    <dd class="col-sm-8" id="endTime"></dd>

                    <dt class="col-sm-4">Software</dt>
                    <dd class="col-sm-8" id="software"></dd>

                    <dt class="col-sm-4">Total Students</dt>
                    <dd class="col-sm-8" id="totalStudents"></dd>
                </dl>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="saveButton">Attendance</button>
            </div>
        </div>
    </div>
</div>

<!-- HTML code -->
<!-- Attendance Modal -->
<div class="modal fade" id="newModal" tabindex="-1" aria-labelledby="newModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-fullscreen modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="newModalLabel">Attendance</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div id="notification" class="notification"></div>
                <div class="row mb-10">
                    <div class="col-md-6">
                        <p>Batch Name: <span id="displayBatchName"></span></p>
                    </div>
                    <div class="col-md-6">
                        <p>Batch Date: <span id="displayBatchDate"></span></p>
                    </div>
                </div>

                <input type="hidden" id="batchName">
                <input type="hidden" id="batchDate">
                <input type="hidden" id="batchid">
                <button id="startBatchBtn" class="btn btn-primary">Start Batch</button>
                <button id="endBatchBtn" class="btn btn-danger" style="display: none;">End Batch</button>
                <div id="studentCheckboxes" class="mt-5"></div>
            </div>
            <div class="modal-footer mt-3">
                <div class="ms-auto">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button id="saveAttendanceBtn" type="button" class="btn btn-primary">Save</button>
                </div>
            </div>
        </div>
    </div>
</div>




<!-- ========== section end ========== -->
@push('script')
<script src="{{ url('assets/js/custom/custom.js')}}"></script>
<script>
    var batchName, batchDate, batchid;

    function showNotification(message, type = 'success') {
        var notificationElement = document.getElementById('notification');

        if (type === 'success') {
            notificationElement.style.backgroundColor = '#4caf50';
        } else if (type === 'error') {
            notificationElement.style.backgroundColor = '#f44336';
        }

        notificationElement.innerText = message;
        notificationElement.style.display = 'block';

        setTimeout(function() {
            notificationElement.style.display = 'none';
        }, 5000);
    }

    document.addEventListener("DOMContentLoaded", function() {
        var calendarMiniEl = document.getElementById("calendar-mini");
        var batches = @json($batches);

        var events = [];
        for (const [date, batchArray] of Object.entries(batches)) {
            batchArray.forEach(batch => {
                events.push({
                    title: `${batch.Name} ${batch.StartTimeInMinutes} To ${batch.EndTimeInMinutes}`,
                    start: `${date}T${batch.StartTimeInMinutes}`,
                    end: `${date}T${batch.EndTimeInMinutes}`,
                    extendedProps: {
                        batch: {
                            BatchId: batch.BatchId,
                            Name: batch.Name,
                            FromDate: batch.FromDate,
                            ToDate: batch.ToDate,
                            StartTimeInMinutes: batch.StartTimeInMinutes,
                            EndTimeInMinutes: batch.EndTimeInMinutes,
                            StudentCapacity: batch.StudentCapacity,
                        }
                    }
                });
            });
        }

        var calendarMini = new FullCalendar.Calendar(calendarMiniEl, {
            initialView: "dayGridMonth",
            eventDisplay: "block", // Set event display to "block" to remove the dot
            events: events,
            eventDidMount: function(info) {
                // Customize event rendering (adjust size, etc.)
                info.el.style.fontSize = '9px'; // Example: adjust font size
                info.el.style.background = '#9501fc'; // Example: adjust background color
                info.el.style.color = '#333'; // Example: adjust text color
                info.el.style.border = '1px solid #fc0101'; // Example: add border
                info.el.style.padding = '1px'; // Example: add padding
            },
            eventClick: function(info) {
                var batch = info.event.extendedProps.batch; // Assuming you attach the batch details to the event

                // Set options for formatting the date
                var options = {
                    day: '2-digit',
                    month: 'short',
                    year: 'numeric'
                };

                // Function to format the date string in "dd/Mon/yyyy" format
                function formatDate(dateString) {
                    var date = new Date(dateString);
                    return date.toLocaleDateString('en-GB', options);
                }

                var date = info.event.start;
                batchDate = date.toLocaleDateString();
                // Set global variables

                batchid = document.getElementById('batchid').value = batch.BatchId;
                batchDate = document.getElementById('batchDate').value = formatDate(batchDate);

                // Populate modal with batch details
                batchName = document.getElementById('batchName').innerText = batch.Name;
                document.getElementById('fromDate').innerText = formatDate(batch.FromDate);
                document.getElementById('toDate').innerText = formatDate(batch.ToDate);
                document.getElementById('startTime').innerText = batch.StartTimeInMinutes;
                document.getElementById('endTime').innerText = batch.EndTimeInMinutes;
                document.getElementById('software').innerText = batch.Name;
                document.getElementById('totalStudents').innerText = batch.StudentCapacity;

                // Open the modal
                var myModal = new bootstrap.Modal(document.getElementById('batchDetailModal'));
                myModal.show();
            },
            headerToolbar: {
                end: "today prev,next"
            },
            dayMaxEvents: true // Enable scrolling when the maximum number of events per day is exceeded
        });

        // Ensure scrolling is enabled by adding overflow property
        calendarMiniEl.style.overflow = 'auto';

        calendarMini.render();
        document.getElementById('saveButton').addEventListener('click', function() {
            var batchDate = document.getElementById('batchDate').value
            document.getElementById('displayBatchName').textContent = batchName; // Display batch name
            document.getElementById('displayBatchDate').textContent = batchDate; // Display batch date

            var newModal = new bootstrap.Modal(document.getElementById('newModal'));
            newModal.show();
        });
    });



    document.addEventListener("DOMContentLoaded", function() {
        var students = @json($students);
        var cardCounter = 0;
        var StartTime;
        var EndTime;
        var BatchDetailId;
        var startBatchBtn = document.getElementById('startBatchBtn');
        var endBatchBtn = document.getElementById('endBatchBtn');

        // Check if batch has already started
        var batchStarted = sessionStorage.getItem('batchStarted');
        if (batchStarted) {
            startBatchBtn.style.display = 'none'; // Hide start batch button if batch has already started
            endBatchBtn.style.display = 'inline-block'; // Show end batch button
        }

        startBatchBtn.addEventListener('click', function() {
            var currentDate = new Date();
            var startTimeOptions = {
                hour12: false,
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit'
            };
            StartTime = currentDate.toLocaleTimeString('en-US', startTimeOptions);

            startBatchBtn.style.display = 'none';
            endBatchBtn.style.display = 'inline-block';

            // Store batch start status in sessionStorage
            sessionStorage.setItem('batchStarted', true);
        });

        endBatchBtn.addEventListener('click', function() {
            var currentDate = new Date();
            var startTimeOptions = {
                hour12: false,
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit'
            };
            EndTime = currentDate.toLocaleTimeString('en-US', startTimeOptions);
            // saveAttendance(); // Call function to save attendance after setting end time
            // window.location.reload();
            // Hide both start and end batch buttons after ending the batch
            startBatchBtn.style.display = 'none';
            endBatchBtn.style.display = 'none';
            // Clear batch start status from sessionStorage
            sessionStorage.removeItem('batchStarted');
        });


        function saveAttendance() {
            var studentAttendanceData = [];
            var facultyAttendanceData = {};

            var studentCards = document.querySelectorAll('#studentCheckboxes .card');

            studentCards.forEach(function(card) {
                var studentId = card.getAttribute('data-student-id');
                var studentNameElement = card.querySelector('.card-title');
                var courseNameElement = card.querySelector('.card-subtitle');
                var dayAttendanceElement = card.querySelector('input[name="attendanceOptions[' + studentId + '][DayAttendance]"]:checked');
                var isOnlineElement = card.querySelector('input[name="attendanceOptions[' + studentId + '][IsOnline]"]:checked');

                if (studentNameElement && courseNameElement && dayAttendanceElement && isOnlineElement) {
                    var studentName = studentNameElement.textContent.trim();
                    var courseName = courseNameElement.textContent.trim();
                    var dayAttendance = dayAttendanceElement.value;
                    var isOnline = isOnlineElement.value;

                    studentAttendanceData.push({
                        studentName: studentName,
                        StudentId: studentId, // Corrected key name
                        courseName: courseName,
                        DayAttandance: dayAttendance,
                        IsOnline: isOnline,
                        BatchDetailId: batchid, // Corrected variable name
                        ForDate: batchDate, // Corrected variable name
                        StartTime: StartTime,
                        EndTime: EndTime // Corrected variable name
                    });

                    // Populate facultyAttendanceData with batch details
                    facultyAttendanceData.BatchDetailId = batchid; // Corrected key name
                    facultyAttendanceData.ForDate = batchDate; // Corrected key name
                    facultyAttendanceData.StartTime = StartTime;
                    facultyAttendanceData.EndTime = EndTime;
                } else {
                    console.error("One or more elements not found for this student card:", card);
                }
            });

            if (studentAttendanceData.length === 0) {
                showNotification('Please select attendance for at least one student.', 'error');
                return;
            }

            var requestData = {
                student_attendance_data: studentAttendanceData,
                faculty_attendance_data: facultyAttendanceData
            };


            // Simulate the AJAX request
            fetch("@php echo route('saveAttendance')@endphp", {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}' // CSRF token from Blade
                    },
                    body: JSON.stringify(requestData)
                })
                .then(response => {
                    if (response.ok) {
                        // Handle success response
                        return response.json();
                    } else if (response.status === 422) {
                        // Handle validation errors
                        return response.json().then(errors => {
                            var errorMessage = '';
                            for (var key in errors) {
                                if (errors.hasOwnProperty(key)) {
                                    errorMessage += errors[key].join('\n') + '\n';
                                }
                            }
                            // Show validation error notification
                            showNotification(errorMessage, 'error');
                            return Promise.reject(new Error(errorMessage)); // Reject the promise to trigger the catch block
                        });
                    } else {
                        // Handle other error responses
                        var errorMessage = 'Failed to save attendance';
                        // Show error notification
                        showNotification(errorMessage, 'error');
                        return Promise.reject(new Error(errorMessage)); // Reject the promise to trigger the catch block
                    }
                })
                .then(data => {
                    showNotification('Attendance saved successfully', 'success');
                })
                .catch(error => {
                    showNotification('Error occurred while saving attendance: ' + error.message, 'error');
                });
        }

        // Function to create a radio group
        function createRadioGroup(studentId, groupName, options) {
            var radioGroup = document.createElement('div');
            options.forEach(function(option) {
                var radioButton = document.createElement('input');
                radioButton.type = 'radio';
                radioButton.name = 'attendanceOptions[' + studentId + '][' + groupName + ']'; // Use the same name for radio buttons in each group
                radioButton.value = option.value;
                radioButton.checked = option.checked || false; // Set the default checked state, default is false
                radioButton.classList.add(groupName, 'form-check-input', 'mr-2');

                var radioLabel = document.createElement('label');
                radioLabel.classList.add('form-check-label');
                radioLabel.innerText = option.label;
                radioLabel.setAttribute('for', groupName + option.value); // Set 'for' attribute to connect label with input

                var radioDiv = document.createElement('div');
                radioDiv.classList.add('form-check');
                radioDiv.appendChild(radioButton);
                radioDiv.appendChild(radioLabel);

                radioGroup.appendChild(radioDiv);
            });
            return radioGroup;
        }

        // Populate student checkboxes
        var studentCheckboxes = document.getElementById('studentCheckboxes');
        students.forEach(function(student) {
            // Break the loop when 10 cards are created
            if (cardCounter >= 10) {
                return;
            }

            // Create a card for each student
            var card = document.createElement('div');
            card.classList.add('card', 'mb-3'); // Add Bootstrap class for styling
            card.style.width = '18rem'; // Adjust card width as needed

            // Create a card body
            var cardBody = document.createElement('div');
            cardBody.classList.add('card-body');

            // Display student's name
            var studentName = document.createElement('h5');
            studentName.classList.add('card-title');
            studentName.innerText = student.FirstName + ' ' + student.LastName;

            // Display course name below student's name
            var courseName = document.createElement('h6');
            courseName.classList.add('card-subtitle', 'mb-2', 'text-muted');
            courseName.innerText = student.course_name;

            // Append student name and course name to card body
            cardBody.appendChild(studentName);
            cardBody.appendChild(courseName);

            // Create radio buttons for attendance options
            var dayAttendanceRadioGroup = createRadioGroup(student.id, 'DayAttendance', [{
                    label: 'Present',
                    value: '1'
                },
                {
                    label: 'Late',
                    value: '2'
                },
                {
                    label: 'Absent',
                    value: '0',
                    checked: true
                } // Set Absent as default checked
            ]);
            var isOnlineRadioGroup = createRadioGroup(student.id, 'IsOnline', [{
                    label: 'Offline',
                    value: '0',
                    checked: true
                },
                {
                    label: 'Online',
                    value: '1'
                }
            ]);

            // Add radio groups to the card body
            cardBody.appendChild(dayAttendanceRadioGroup);
            cardBody.appendChild(document.createElement('br')); // Add line break
            cardBody.appendChild(isOnlineRadioGroup);

            // Append card body to card
            card.appendChild(cardBody);

            // Append card to the current row or create a new row if needed
            if (cardCounter % 5 === 0) {
                row = document.createElement('div');
                row.classList.add('row', 'row-cols-1', 'row-cols-md-2', 'row-cols-lg-3', 'g-4'); // Add Bootstrap class for styling
                studentCheckboxes.appendChild(row);
            }
            var col = document.createElement('div');
            col.classList.add('col'); // Add Bootstrap class for styling
            card.setAttribute('data-student-id', student.id);
            col.appendChild(card);
            row.appendChild(col);
            // Increment card counter
            cardCounter++;
        });

        // Save attendance button event listener
        document.getElementById('saveAttendanceBtn').addEventListener('click', function() {
            saveAttendance();
            window.location.reload();
        });
    });
</script>


@endpush

@endsection