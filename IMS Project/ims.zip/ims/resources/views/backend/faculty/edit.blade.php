@extends('layout.admin_layout')
@section('title', 'Faculty Edit')
@section('dashboard')
<!-- ========== section start ========== -->
<section class="section">
    <div class="container-fluid">

    @if(session('error'))
        <div class="alert alert-danger alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('error') }}
        </div>
        @endif

        @if(session('success'))
        <div class="alert alert-success alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('success') }}
        </div>
        @endif


        <!-- ========== title-wrapper start ========== -->
        <div class="title-wrapper pt-30">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <div class="title">
                        <h2>Update Faculty</h2>
                    </div>
                    <ul class="nav nav-tabs" id="myTabs">
                        <li class="nav-item">
                            <a class="nav-link{{ request()->is('faculty/edit*') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('faculty.edit',['id' => request('id')]) }}">Faculty Info</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link{{ request()->is('faculty/calender/add*') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('faculty.calender.add',['id' => request('id')]) }}">Calendar</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link{{ request()->is('faculty/PortfolioSubmission*') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('faculty.PortfolioSubmission',['id' => request('id')]) }}">Portfolio Submission</a>
                        </li>

                    </ul>

                </div>
                <div class="col-md-6">
                    <div class="breadcrumb-wrapper">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a href="{{route('faculty.listing')}}" class="main-btn active-btn-light rounded-full btn-hover btn-sm">
                                        <i class="lni lni-arrow-left"></i>
                                        All Faculty
                                    </a>
                                </li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
            <!-- end row -->
        </div>
        <div class="row g-0 auth-row">
            <!-- end col -->
            <div class="col-md-12">
                <div class="signup-wrapper">
                    <div class="form-wrapper">
                        <form action="{{ route('faculty.editfaculty',['id' =>$data->id]) }}" method="post" enctype="multipart/form-data">
                            @csrf
                            <div class="row">
                                <div class="col-md-6 col-xs-12">
                                    <div class="input-style-1">
                                        @if(isset($data->ProfileImage) && $data->ProfileImage != "default.jpg")
                                        <div class="image-container">
                                            <a href="{{ asset('uploads/faculty/profile/' . $data->ProfileImage) }}" target="_blank">
                                                <img class="rounded-image" src="{{ asset('uploads/faculty/profile/' . $data->ProfileImage) }}" alt="ProfileImage" width="100px">
                                            </a>
                                            <a class="main-btn danger-btn-light rounded-full btn-hover btn-sm" href="{{ url('faculty/deleteimage/' . $data->id . '?imageType=ProfileImage') }}" onclick="return confirm('Are you sure?');"> Remove </a>
                                        </div>
                                        <label for="ProfileImage">Profile Image</label>
                                        @else
                                        <div class="image-container">
                                            <img class="rounded-image" id="preview_ProfileImage" src="{{ url('assets/images/default/user_image.png')}}" width="100px">
                                        </div>
                                        <label for="ProfileImage">Profile Image</label>
                                        <input class="form-control" type="file" name="ProfileImage" id="ProfileImage" onchange="previewImage('ProfileImage', 'preview_ProfileImage')" accept="image/*">
                                        @error('ProfileImage')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                        @endif
                                    </div>
                                </div>
                                <div class="col-md-6 col-xs-12">
                                    <div class="input-style-1">
                                        @if(isset($data->SignImage) && $data->SignImage != "sign.jpg")
                                        <div class="image-container">
                                            <a href="{{ asset('uploads/faculty/signature/' . $data->SignImage) }}" target="_blank">
                                                <img class="rounded-image" src="{{ asset('uploads/faculty/signature/' . $data->SignImage) }}" alt="SignImage" width="100px">
                                            </a>
                                            <a class="main-btn danger-btn-light rounded-full btn-hover btn-sm" href="{{ url('faculty/deleteimage/' . $data->id . '?imageType=SignImage') }}" onclick="return confirm('Are you sure?');"> Remove </a>
                                        </div>
                                        <label for="SignImage">Sign Image</label>
                                        @else
                                        <div class="image-container">
                                            <img class="rounded-image" id="preview_SignImage" src="{{ url('assets/images/default/signature_logo.png')}}" width="100px">
                                        </div>
                                        <label for="SignImage">Sign Image</label>
                                        <input class="form-control" type="file" name="SignImage" id="SignImage" onchange="previewImage('SignImage', 'preview_SignImage')" accept="image/*">
                                        @error('SignImage')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                        @endif
                                    </div>
                                </div>

                            </div>
                            <div class="row">
                                <div class="col-md-4 col-xs-12">
                                    <div class="input-style-1">
                                        <label for="FirstName" class="compulsory">First Name </label>
                                        <input type="text" name="FirstName" id="FirstName" value="{{$data->FirstName}}" placeholder="Enter First Name" />
                                        <input type="hidden" name="InstituteId" value="{{$data->InstituteId}}">
                                        <input type="hidden" name="UserId" value="{{$data->UserId}}">
                                        <input type="hidden" name="BranchId" value="{{$data->BranchId}}">
                                        @error('FirstName')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                                <div class="col-md-4 col-xs-12">
                                    <div class="input-style-1">
                                        <label for="LastName" class="compulsory">Last Name</label>
                                        <input type="tel" name="LastName" id="LastName" value="{{$data->LastName}}" placeholder="Enter Last Name" />
                                        @error('LastName')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                                <div class="col-md-4 col-xs-12">
                                    <div class="input-style-1">
                                        <label for="MobileNumber" class="compulsory">Mobile Number</label>
                                        <input type="tel" name="MobileNumber" minlength="10" maxlength="10" id="MobileNumber" value="{{$data->MobileNumber}}" placeholder="Enter Mobile Number" />
                                        @error('MobileNumber')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4 col-xs-12">
                                    <div class="input-style-1">
                                        <label for="EmailId" class="compulsory">Email</label>
                                        <input type="email" name="EmailId" id="EmailId" value="{{$data->EmailId}}" placeholder="Enter Email" />
                                        @error('EmailId')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>

                                <div class="col-md-4 col-xs-12">
                                    <div class="input-style-1">
                                        <label for="EmployeeCode">Employee Code</label>
                                        <input type="text" readonly name="EmployeeCode" id="EmployeeCode" value="{{$data->EmployeeCode}}" />
                                    </div>
                                </div>
                                <div class="col-md-4 col-xs-12">
                                    <div class="input-style-1">
                                        <label for="AddressLine1" class="compulsory">Address Line1</label>
                                        <textarea name="AddressLine1" id="AddressLine1" cols="30" rows="1" placeholder="Enter Address">{{$data->AddressLine1}}</textarea>
                                        @error('AddressLine1')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                            </div>

                            <div class="row">

                                <div class="col-md-4 col-xs-12">
                                    <div class="input-style-1">
                                        <label for="AddressLine2">Address Line2</label>
                                        <textarea name="AddressLine2" id="AddressLine2" cols="30" rows="1" placeholder="Enter Address">{{$data->AddressLine2}}</textarea>
                                    </div>
                                </div>
                                <div class="col-md-4 col-xs-12">
                                    <div class="select-style-1">
                                        <label for="StateId" class="compulsory">State</label>
                                        <div class="select-position">
                                            <select name="StateId" id="StateId">
                                                <option selected disabled>Please select State</option>
                                                @if (isset($states))
                                                @foreach ($states as $state)
                                                <option value="{{$state->id}}" {{$data->StateId == $state->id ? 'selected' : '' }}>{{$state->Name}}</option>
                                                @endforeach
                                                @endif
                                            </select>
                                        </div>
                                        @error('StateId')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                                <div class="col-md-4 col-xs-12">
                                    <div class="input-style-1">
                                        <label for="CityName" class="compulsory">City</label>
                                        <input type="text" name="CityName" id="CityName" value="{{$data->CityName}}" placeholder="Enter City Name" />
                                        @error('CityName')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-4 col-xs-12">
                                        <div class="input-style-1">
                                            <label for="PostalCode" class="compulsory">Postal Code</label>
                                            <input type="text" name="PostalCode" id="PostalCode" value="{{$data->PostalCode}}" placeholder="Enter Postal Code" />
                                            @error('PostalCode')
                                            <span class="text-danger">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>

                                    <div class="col-md-4 col-xs-12">
                                        <div class="select-style-1">
                                            <div class="form-check checkbox-style"><br>
                                                <input class="form-check-input" type="checkbox" id="copyCheckbox" />
                                                <label class="form-check-label" for="copyCheckbox">Copy Address</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div class="row">
                                <div class="col-md-4 col-xs-12">
                                    <div class="input-style-1">
                                        <label for="PrAddressLine1" class="compulsory">Permanent Address 1</label>
                                        <textarea name="PrAddressLine1" id="PrAddressLine1" cols="30" rows="1" placeholder="Enter Permanent Address">{{$data->PrAddressLine1}}</textarea>
                                        @error('PrAddressLine1')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                                <div class="col-md-4 col-xs-12">
                                    <div class="input-style-1">
                                        <label for="PrAddressLine2">Permanent Address 2</label>
                                        <textarea name="PrAddressLine2" id="PrAddressLine2" cols="30" rows="1" placeholder="Enter Permanent Address">{{$data->PrAddressLine2}}</textarea>
                                    </div>
                                </div>
                                <div class="col-md-4 col-xs-12">
                                    <div class="select-style-1">
                                        <label for="PrStateId" class="compulsory">State</label>
                                        <div class="select-position">
                                            <select name="PrStateId" id="PrStateId">
                                                <option selected disabled>Please select State</option>
                                                @if (isset($states))
                                                @foreach ($states as $state)
                                                <option value="{{$state->id}}" {{$data->PrStateId == $state->id ? 'selected' : '' }}>{{$state->Name}}</option>
                                                @endforeach
                                                @endif
                                            </select>
                                        </div>
                                        @error('PrStateId')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>

                            </div>
                            <div class="row">
                                <div class="col-md-4 col-xs-12">
                                    <div class="input-style-1">
                                        <label for="PrCityName" class="compulsory">City</label>
                                        <input type="text" name="PrCityName" id="PrCityName" value="{{$data->PrCityName}}" placeholder="Enter City Name" />
                                        @error('PrCityName')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                                <div class="col-md-4 col-xs-12">
                                    <div class="input-style-1">
                                        <label for="EmergencyContactNumber" class="compulsory">Emergency Contact Number</label>
                                        <input type="tel" name="EmergencyContactNumber" minlength="10" maxlength="10" id="EmergencyContactNumber" value="{{$data->EmergencyContactNumber}}" placeholder="Enter Emergency Contact Number" />
                                        @error('EmergencyContactNumber')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                                <div class="col-md-4 col-xs-12">
                                    <div class="select-style-1">
                                        <label for="BloodGroup" class="compulsory">Blood Group</label>
                                        <div class="select-position">
                                            <select name="BloodGroup" id="BloodGroup">
                                                <option selected disabled>Select blood group </option>
                                                <option value="Not_Known" {{ $data->BloodGroup == 'Not_Known' ? 'selected' : '' }}>Not Known</option>
                                                <option value="A+" {{ $data->BloodGroup == 'A+' ? 'selected' : '' }}>A+</option>
                                                <option value="A-" {{ $data->BloodGroup == 'A-' ? 'selected' : '' }}>A-</option>
                                                <option value="B+" {{ $data->BloodGroup == 'B+' ? 'selected' : '' }}>B+</option>
                                                <option value="B-" {{ $data->BloodGroup == 'B-' ? 'selected' : '' }}>B-</option>
                                                <option value="O+" {{ $data->BloodGroup == 'O+' ? 'selected' : '' }}>O+</option>
                                                <option value="O-" {{ $data->BloodGroup == 'O-' ? 'selected' : '' }}>O-</option>
                                                <option value="AB+" {{ $data->BloodGroup == 'AB+' ? 'selected' : '' }}>AB+</option>
                                                <option value="AB-" {{ $data->BloodGroup == 'AB-' ? 'selected' : '' }}>AB-</option>
                                            </select>
                                        </div>
                                        @error('BloodGroup')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                            <div class="row">

                                <div class="col-md-4 col-xs-12">
                                    <div class="select-style-1">
                                        <label for="IsActive" class="compulsory">Is Active</label>
                                        <div class="select-position">
                                            <select name="IsActive" id="IsActive">
                                                <option value="1" {{ $data->IsActive == '1' ? 'selected' : '' }}>Active</option>
                                                <option value="0" {{ $data->IsActive == '0' ? 'selected' : '' }}>Inactive</option>
                                            </select>
                                        </div>
                                        @error('IsActive')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>

                            </div>

                            <!-- end col -->
                            <div class="row">
                                <div class="col-12">
                                    <button class="main-btn dark-btn rounded-full btn-hover btn-sm">
                                        Update
                                    </button>
                                </div>
                            </div>
                            <!-- end row -->
                        </form>

                    </div>
                </div>
            </div>
            <!-- end col -->
        </div>

    </div>
    <!-- end container -->
</section>
<!-- ========== section end ========== -->
@push('script')
<script src="{{ url('assets/js/custom/custom.js')}}"></script>
@endpush

@endsection