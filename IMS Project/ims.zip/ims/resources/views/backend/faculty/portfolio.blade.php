@extends('layout.admin_layout')
@section('title', 'Portfolio Submission')
@section('dashboard')

<!-- ========== table components start ========== -->
<section class="table-components">
    <div class="container-fluid">

        @if(session('error'))
        <div class="alert alert-danger alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('error') }}
        </div>
        @endif

        @if(session('success'))
        <div class="alert alert-success alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('success') }}
        </div>
        @endif

        <!-- ========== title-wrapper start ========== -->
        <div class="title-wrapper pt-30">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <div class="title">
                        <h2>Update Faculty</h2>
                    </div>
                    <ul class="nav nav-tabs" id="myTabs">
                        @php
                        $userRole = auth()->user()->RoleId;
                        @endphp
                        @if ($userRole == 3)
                        <li class="nav-item">
                            <a class="nav-link{{ request()->is('faculty/show*') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('faculty.show',['id' => request('id')]) }}">Faculty Info</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link{{ request()->is('faculty/calender/add*') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('faculty.calender.add',['id' => request('id')]) }}">Calendar</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link{{ request()->is('faculty/PortfolioSubmission*') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('faculty.PortfolioSubmission',['id' => request('id')]) }}">Portfolio Submission</a>
                        </li>
                        @else
                        <li class="nav-item">
                            <a class="nav-link{{ request()->is('faculty/edit*') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('faculty.edit',['id' => request('id')]) }}">Faculty Info</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link{{ request()->is('faculty/calender/add*') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('faculty.calender.add',['id' => request('id')]) }}">Calendar</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link{{ request()->is('faculty/PortfolioSubmission*') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('faculty.PortfolioSubmission',['id' => request('id')]) }}">Portfolio Submission</a>
                        </li>
                        @endif
                    </ul>
                </div>
                @php
                $userRole = auth()->user()->RoleId;
                @endphp
                @if ($userRole != 3)
                <div class="col-md-6">
                    <div class="breadcrumb-wrapper">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a href="{{route('faculty.listing')}}" class="main-btn active-btn-light rounded-full btn-hover btn-sm">
                                        <i class="lni lni-arrow-left"></i>
                                        All Faculty
                                    </a>
                                </li>
                            </ol>
                        </nav>
                    </div>
                </div>
                @endif
            </div>
            <!-- end row -->
        </div>
        <!-- ========== title-wrapper end ========== -->

        <!-- ========== tables-wrapper start ========== -->
        <div class="tables-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card-style mb-30">
                        <div class="table-wrapper table-responsive">
                            <h4 class="mb-10">Batch Completed Student List</h4>
                            <table class="table" id="data-table">
                                <thead>
                                <tr class="text-sm">
                                        <th class="text-uppercase">Batch</th>
                                        <th class="text-uppercase">Subject</th>
                                        <th class="text-uppercase">First Name</th>
                                        <th class="text-uppercase">Last Name</th>
                                        <th class="text-uppercase print-hidden">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @if (isset($data))
                                    @foreach ($data as $record)
                                    <tr>
                                        <td class="min-width text-sm">{{$record->batch_name }}</td>
                                        <td class="min-width text-sm">{{$record->subject_name }}</td>
                                        <td class="min-width text-sm">{{$record->FirstName }}</td>
                                        <td class="min-width text-sm">{{$record->LastName }}</td>
                                        <td>
                                            <div class="action">
                                                <button type="button" class="text-primary open-modal" data-bs-toggle="modal" data-bs-target="#studentModal" data-student-id="{{$record->studentId}}" data-subject-id="{{$record->subjectId}}" data-faculty-id="{{$record->facultyId}}" data-updated-date="{{$record->updated_at}}">
                                                    Action
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                    @endforeach
                                    @endif
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Modal -->
        <div class="modal fade" id="studentModal" tabindex="-1" aria-labelledby="studentModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div id="responseMessage"></div>
                    <div class="modal-header">
                        <h5 class="modal-title" id="studentModalLabel">Student Details</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form id="portfolioForm" action="{{ route('SavePortfolioSubmission') }}" method="POST">
                        @csrf
                        <div class="modal-body">
                            <input type="hidden" name="StudentId" id="modalStudentId">
                            <input type="hidden" name="SubjectId" id="modalSubjectId">
                            <input type="hidden" name="FacultyId" id="modalFacultyId">
                            <div class="mb-3">
                                <label for="submission_date" class="form-label">Submission Date</label>
                                <input type="text" class="form-control" id="submission_date" name="SubmissionDate">
                            </div>
                            <div class="mb-3">
                                <label for="invitation_date" class="form-label compulsory">Investigate Date</label>
                                <input type="date" class="form-control" id="invitation_date" name="ApprovedAt" max="{{ date('Y-m-d') }}">
                            </div>
                            <div class="mb-3">
                                <label class="form-label compulsory">Is Approved</label>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="IsApproved" id="approveRadio" value="1">
                                    <label class="form-check-label" for="approveRadio">
                                        Approved
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="IsApproved" id="rejectRadio" value="0">
                                    <label class="form-check-label" for="rejectRadio">
                                        Rejected
                                    </label>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="remark" class="form-label compulsory">Remarks</label>
                                <textarea class="form-control" id="remark" name="PortfolioFile"></textarea>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-primary" id="saveButton">Save</button>
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>


        <span class="divider"></span>
        <div class="tables-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card-style mb-30">
                        <div class="table-wrapper table-responsive">
                            <h4 class="mb-10">Portfolio Submitted List</h4>
                            <table class="table" id="data-table1">
                                <thead>
                                <tr class="text-sm">
                                        <th class="text-uppercase">Subject</th>
                                        <th class="text-uppercase">First Name</th>
                                        <th class="text-uppercase">Last Name</th>
                                        <th class="text-uppercase">Submission Date</th>
                                        <th class="text-uppercase">Approved Date</th>
                                        <th class="text-uppercase">Is Approved</th>
                                        <th class="text-uppercase">Remarks</th>
                                        <th class="text-uppercase print-hidden">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @if (isset($portfolio))
                                    @foreach ($portfolio as $record)
                                    <tr>
                                        <td class="min-width text-sm">{{$record->subject_name }}</td>
                                        <td class="min-width text-sm">{{$record->FirstName }}</td>
                                        <td class="min-width text-sm">{{$record->LastName }}</td>
                                        <td class="min-width text-sm">{{date('d-m-Y',strtotime($record->SubmissionDate))}}</td>
                                        <td class="min-width text-sm">{{date('d-m-Y',strtotime($record->ApprovedAt))}}</td>
                                        <td class="min-width text-sm">
                                            @if($record->IsApproved == 1)
                                            <span class="status-btn active-btn" title="Yes">Yes</span>
                                            @else
                                            <span class="status-btn close-btn" title="No">No</span>
                                            @endif
                                        </td>
                                        <td class="min-width text-sm">{{$record->PortfolioFile }}</td>
                                        <td>
                                            <div class="action">
                                                <a href="{{ route('PortfolioSubmission.delete',['id'=>$record->id ]) }}" class="text-danger" onclick="return confirm('Are you sure?')" title="Delete"><i class="lni lni-trash-can"></i></a>
                                            </div>
                                        </td>
                                    </tr>
                                    @endforeach
                                    @endif
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- ========== tables-wrapper end ========== -->
    </div>
    <!-- end container -->
</section>
<!-- ========== table components end ========== -->

@push('script')
<script>
    $(document).ready(function() {
        $('#data-table1').DataTable({
            "responsive": true,
            dom: 'Bfrtip',
            lengthMenu: [
                [10, 25, 50, -1],
                ['10 rows', '25 rows', '50 rows', 'Show all']
            ],
            "autoWidth": true,
            "paging": true,
            buttons: [
                'pageLength',
                {
                    extend: 'csv',
                    exportOptions: {
                        columns: ':not(.print-hidden)'

                    }
                },
                {
                    extend: 'print',
                    exportOptions: {
                        columns: ':not(.print-hidden)'
                    },
                },
                {
                    extend: 'pdf',
                    exportOptions: {
                        columns: ':not(.print-hidden)'
                    },

                }
            ],
        });
        const modal = document.getElementById('studentModal');
        modal.addEventListener('show.bs.modal', function(event) {
            var button = event.relatedTarget;
            var studentId = button.getAttribute('data-student-id');
            var subjectId = button.getAttribute('data-subject-id');
            var facultyId = button.getAttribute('data-faculty-id');
            var modalStudentId = modal.querySelector('#modalStudentId');
            var modalSubjectId = modal.querySelector('#modalSubjectId');
            var modalFacultyId = modal.querySelector('#modalFacultyId');
            var submissionDate = modal.querySelector('#submission_date');
            modalStudentId.value = studentId;
            modalSubjectId.value = subjectId;
            modalFacultyId.value = facultyId;

            // Display updated_at date in submission date field
            var updatedDate = button.getAttribute('data-updated-date');
            submissionDate.value = updatedDate;
        });

        $('#saveButton').on('click', function() {
            // Disable the button to prevent multiple clicks
            $(this).prop('disabled', true);
            // Submit the form via Ajax
            submitFormViaAjax();
        });

        // Function to submit form via Ajax
        function submitFormViaAjax() {
            // Serialize form data
            var formData = $('#portfolioForm').serialize();

            // Send AJAX request
            $.ajax({
                url: $('#portfolioForm').attr('action'),
                type: $('#portfolioForm').attr('method'),
                data: formData,
                success: function(response) {
                    if (response && response.message) {
                        // Handle success response
                        var successHtml = '<div class="alert alert-success alert-dismissible fade show">';
                        successHtml += response.message;
                        successHtml += '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>';
                        successHtml += '</div>';
                        $('#responseMessage').html(successHtml);
                    } else {
                        console.error('Invalid response format:', response);
                    }
                    // Reload the page after 3 seconds
                    setTimeout(function() {
                        location.reload();
                    }, 3000);
                },

                error: function(xhr, status, error) {
                    // Handle error response
                    var errors = xhr.responseJSON.errors;
                    if (errors) {
                        var errorHtml = '<div class="alert alert-danger">';
                        $.each(errors, function(key, value) {
                            errorHtml += value[0] + '<br>';
                        });
                        errorHtml += '</div>';
                        $('#responseMessage').html(errorHtml);
                    } else {
                        console.error('Error:', error);
                    }
                },
                complete: function() {
                    // Enable the button after AJAX request completes
                    $('#saveButton').prop('disabled', false);
                }
            });

            // Hide response message after 3 seconds
            setTimeout(function() {
                $('#responseMessage').fadeOut('slow');
            }, 3000);
        }

        // Reset form when modal is closed
        $('#studentModal').on('hidden.bs.modal', function() {
            $('#portfolioForm')[0].reset(); // Reset the form
            $('#responseMessage').html(''); // Clear any previous response message
        });

        // Close response message when close button is clicked
        $(document).on('click', '.alert .btn-close', function() {
            $(this).closest('.alert').alert('close');
        });
    });
</script>
@endpush

@endsection