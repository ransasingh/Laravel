@extends('layout.admin_layout')
@section('title', 'Student Calender')
@section('css')
<link rel="stylesheet" href="{{ url('assets/css/custom.css') }}">
@endsection

@section('dashboard')

<!-- ========== section start ========== -->
<section class="section">
    <div class="container-fluid">

        @if(session('error'))
        <div class="alert alert-danger alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('error') }}
        </div>
        @endif

        @if(session('success'))
        <div class="alert alert-success alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('success') }}
        </div>
        @endif


        <!-- ========== title-wrapper start ========== -->
        <div class="title-wrapper pt-30">
            <div class="row align-items-center">
                <div class="col-md-9">
                    <div class="title">
                        <h2>Update Student</h2>
                    </div>
                    <ul class="nav nav-tabs" id="myTabs">
                        <li class="nav-item">
                            <a class="nav-link{{ request()->is('student/show*') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('student.show',['id' => request('id')]) }}">Student Info</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link{{ request()->is('studentcourse/detail*') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('studentcourse.detail',['id' => request('id')]) }}">Course Details</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link{{ request()->is('feereceipt/detail*') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('feereceipt.detail',['id' => request('id')]) }}">Fee Details</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link{{ request()->is('student/calender*') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('student.calender',['id' => request('id')]) }}">Calender</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link{{ request()->routeIs('student.PortfolioSubmission') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('student.PortfolioSubmission',['id' => request('id')]) }}">Portfolio Submission</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link{{ request()->routeIs('student.batchcompletion') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('student.batchcompletion',['id' => request('id')]) }}">Batch Completion</a>
                        </li>
                    </ul>

                </div>
            </div>
            <!-- end row -->
        </div>
        <div class="row g-0 auth-row">

            <div class="card-style calendar-card mb-40">
                <div id="calendar-mini"></div>
            </div>

        </div>

    </div>
    <!-- end container -->
</section>
<!-- Batch Detail Modal -->
<div class="modal fade" id="batchDetailModal" tabindex="-1" aria-labelledby="batchDetailModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="batchDetailModalLabel">Batch Detail</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <dl class="row">
                    <dt class="col-sm-4">Name</dt>
                    <dd class="col-sm-8" id="batchName"></dd>

                    <dt class="col-sm-4">Current Date</dt>
                    <dd class="col-sm-8" id="currentDate"></dd>

                    <dt class="col-sm-4">From Date</dt>
                    <dd class="col-sm-8" id="fromDate"></dd>

                    <dt class="col-sm-4">To Date</dt>
                    <dd class="col-sm-8" id="toDate"></dd>

                    <dt class="col-sm-4">Start At</dt>
                    <dd class="col-sm-8" id="startTime"></dd>

                    <dt class="col-sm-4">End At</dt>
                    <dd class="col-sm-8" id="endTime"></dd>

                    <dt class="col-sm-4">Software</dt>
                    <dd class="col-sm-8" id="software"></dd>

                    <dt class="col-sm-4">Attendance</dt>
                    <dd class="col-sm-8" id="attendance"></dd>
                </dl>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>

            </div>
        </div>
    </div>
</div>





<!-- ========== section end ========== -->
@push('script')
<script>
    document.addEventListener("DOMContentLoaded", function() {
        var calendarMiniEl = document.getElementById("calendar-mini");
        var batches = @json($batches);

        var events = [];

        // Iterate over your batches data and create events array
        for (const [date, batchArray] of Object.entries(batches)) {
            batchArray.forEach((batch, index) => {
                var attendanceStatus = batch.AttendanceStatus ?? 'No attendance record'; // Default message when attendance record is not available

                // Format the dates in "DD-MMM-YYYY" format
                var options = {
                    day: 'numeric',
                    month: 'short',
                    year: 'numeric'
                };
                var formattedFromDate = new Date(batch.FromDate).toLocaleDateString('en-US', options);
                var formattedToDate = new Date(batch.ToDate).toLocaleDateString('en-US', options);

                // Concatenate batch name, start time, and end time
                var eventTitle = batch.Name + " - " + batch.StartTimeInMinutes + " to " + batch.EndTimeInMinutes;
                events.push({
                    title: eventTitle,
                    start: date,

                    batchDetails: batch,
                    attendanceStatus: attendanceStatus,
                    fromDate: formattedFromDate,
                    toDate: formattedToDate
                });
            });
        }

        var calendarMini = new FullCalendar.Calendar(calendarMiniEl, {
            initialView: "dayGridMonth",
            events: events, // Set events data
            eventDidMount: function(info) {
                // Customize event rendering (adjust size, etc.)
                info.el.style.fontSize = '9px'; // Example: adjust font size
                info.el.style.background = '#9501fc'; // Example: adjust background color
                info.el.style.color = '#333'; // Example: adjust text color
                info.el.style.border = '1px solid #fc0101'; // Example: add border
                info.el.style.padding = '1px'; // Example: add padding
                info.el.style.overflow = 'hidden'; // Hide overflow content
                info.el.style.maxWidth = '100px'; // Adjust as needed
                info.el.style.whiteSpace = 'normal'; // Allow text to wrap
                // Add ellipsis for overflow
                info.el.style.textOverflow = 'ellipsis';
                // Add event listener to "show more" link
                if (info.event.extendedProps.showMore) {
                    info.el.addEventListener('click', function() {
                        // Display the remaining events
                        var remainingEvents = info.event.extendedProps.remainingEvents;
                        remainingEvents.forEach(event => {
                            calendarMini.addEvent(event);
                        });

                        // Remove the "show more" link
                        calendarMini.getEvents().forEach(event => {
                            if (event.extendedProps.showMore) {
                                calendarMini.getEventSourceById(event.source.id).remove();
                            }
                        });
                    });
                }
            },
            eventClick: function(info) {
                var batchDetails = info.event.extendedProps.batchDetails;
                var attendanceStatus = info.event.extendedProps.attendanceStatus;
                var currentDate = info.event.start; // Get the start date of the event

                // Format the current date to "DD-MMM-YYYY" format
                var options = {
                    day: 'numeric',
                    month: 'short',
                    year: 'numeric'
                };
                var formattedCurrentDate = currentDate.toLocaleDateString('en-US', options);

                // Format the dates in "DD-MMM-YYYY" format
                var formattedFromDate = info.event.extendedProps.fromDate;
                var formattedToDate = info.event.extendedProps.toDate;

                // Update modal with batch details, current date, and formatted dates
                document.getElementById("batchName").textContent = batchDetails.Name;
                document.getElementById("fromDate").textContent = formattedFromDate;
                document.getElementById("toDate").textContent = formattedToDate;
                document.getElementById("startTime").textContent = batchDetails.StartTimeInMinutes;
                document.getElementById("endTime").textContent = batchDetails.EndTimeInMinutes;
                document.getElementById("software").textContent = batchDetails.Name;
                document.getElementById("attendance").textContent = attendanceStatus;
                document.getElementById("currentDate").textContent = formattedCurrentDate; // Set the current date in the modal

                // Open the modal
                $('#batchDetailModal').modal('show');
            }
        });

        calendarMiniEl.style.overflow = 'auto';
        calendarMini.render();
    });
</script>

@endpush

@endsection