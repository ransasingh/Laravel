@extends('layout.admin_layout')
@section('title', 'Portfolio Submission')
@section('dashboard')

<!-- ========== table components start ========== -->
<section class="table-components">
    <div class="container-fluid">

        @if(session('error'))
        <div class="alert alert-danger alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('error') }}
        </div>
        @endif

        @if(session('success'))
        <div class="alert alert-success alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('success') }}
        </div>
        @endif

        <!-- ========== title-wrapper start ========== -->
        <div class="title-wrapper pt-30">
            <div class="row align-items-center">
                <div class="col-md-9">
                    <div class="title">
                        <h2>Update Student</h2>
                    </div>
                    @php
                    $userRole = auth()->user()->RoleId;
                    @endphp
                    <ul class="nav nav-tabs" id="myTabs">
                        @if ($userRole == 1)
                        <li class="nav-item">
                            <a class="nav-link{{ request()->routeIs('student.edit') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('student.edit',['id' => request('id')]) }}">Student Info</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link{{ request()->routeIs('studentcourse.add') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('studentcourse.add',['id' => request('id')]) }}">Course Details</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link{{ request()->routeIs('feereceipt.add') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('feereceipt.add',['id' => request('id')]) }}">Fee Details</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link{{ request()->routeIs('student.scalender') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('student.scalender',['id' => request('id')]) }}">Calender</a>
                        </li>
                        @else
                        <li class="nav-item">
                            <a class="nav-link{{ request()->is('student/show*') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('student.show',['id' => request('id')]) }}">Student Info</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link{{ request()->is('studentcourse/detail*') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('studentcourse.detail',['id' => request('id')]) }}">Course Details</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link{{ request()->is('feereceipt/detail*') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('feereceipt.detail',['id' => request('id')]) }}">Fee Details</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link{{ request()->is('student/calender*') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('student.calender',['id' => request('id')]) }}">Calender</a>
                        </li>

                        @endif
                        <li class="nav-item">
                            <a class="nav-link{{ request()->routeIs('student.PortfolioSubmission') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('student.PortfolioSubmission',['id' => request('id')]) }}">Portfolio Submission</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link{{ request()->routeIs('student.batchcompletion') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('student.batchcompletion',['id' => request('id')]) }}">Batch Completion</a>
                        </li>
                    </ul>

                </div>
                @if ($userRole != 4)
                <div class="col-md-3">
                    <div class="breadcrumb-wrapper">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a href="{{route('student.listing')}}" class="main-btn active-btn-light rounded-full btn-hover btn-sm">
                                        <i class="lni lni-arrow-left"></i>
                                        All Students
                                    </a>
                                </li>
                            </ol>
                        </nav>
                    </div>
                </div>
                @endif
            </div>
            <!-- end row -->
        </div>
        <!-- ========== title-wrapper end ========== -->

        <!-- ========== tables-wrapper start ========== -->

        <div class="tables-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card-style mb-30">
                        <div class="table-wrapper table-responsive">
                            <table class="table" id="data-table1">
                                <thead>
                                <tr class="text-sm">
                                        <th class="text-uppercase">Subject</th>
                                        <th class="text-uppercase">Submission Date</th>
                                        <th class="text-uppercase">Approved Date</th>
                                        <th class="text-uppercase">Is Approved</th>
                                        <th class="text-uppercase">Remarks</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @if (isset($portfolio))
                                    @foreach ($portfolio as $record)
                                    <tr>
                                        <td class="min-width text-sm">{{$record->subject_name }}</td>
                                        <td class="min-width text-sm">{{date('d-m-Y',strtotime($record->SubmissionDate))}}</td>
                                        <td class="min-width text-sm">{{date('d-m-Y',strtotime($record->ApprovedAt))}}</td>
                                        <td class="min-width text-sm">
                                            @if($record->IsApproved == 1)
                                            <span class="status-btn active-btn" title="Yes">Yes</span>
                                            @else
                                            <span class="status-btn close-btn" title="No">No</span>
                                            @endif
                                        </td>
                                        <td class="min-width text-sm">{{$record->PortfolioFile }}</td>
                                    </tr>
                                    @endforeach
                                    @endif
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- ========== tables-wrapper end ========== -->
    </div>
    <!-- end container -->
</section>
<!-- ========== table components end ========== -->

@push('script')
<script>
    $(document).ready(function() {
        $('#data-table1').DataTable({
            "responsive": true,
            dom: 'Bfrtip',
            lengthMenu: [
                [10, 25, 50, -1],
                ['10 rows', '25 rows', '50 rows', 'Show all']
            ],
            "autoWidth": true,
            "paging": true,
            buttons: [
                'pageLength',
                {
                    extend: 'csv',
                    exportOptions: {
                        columns: ':not(.print-hidden)'

                    }
                },
                {
                    extend: 'print',
                    exportOptions: {
                        columns: ':not(.print-hidden)'
                    },
                },
                {
                    extend: 'pdf',
                    exportOptions: {
                        columns: ':not(.print-hidden)'
                    },

                }
            ],
        });
    });
</script>
@endpush

@endsection