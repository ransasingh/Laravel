@extends('layout.admin_layout')
@section('title', 'Change Password')
@section('dashboard')
<!-- ========== section start ========== -->
<section class="section">
    <div class="container-fluid">

    @if(session('error'))
    <div class="alert alert-danger alert-dismissible mt-20 fade show alert-sm" role="alert">
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        {{ session('error') }}
    </div>
    @endif

    @if(session('success'))
    <div class="alert alert-success alert-dismissible mt-20 fade show alert-sm" role="alert">
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        {{ session('success') }}
    </div>
    @endif

        <!-- ========== title-wrapper start ========== -->
        <div class="title-wrapper pt-30">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <div class="title">
                        <h2>Change Password</h2>
                    </div>
                </div>
            </div>
            <!-- end row -->
        </div>
        <div class="row g-0 auth-row">
            <!-- end col -->
            <div class="col-md-12">
                <div class="signup-wrapper">
                    <div class="form-wrapper">
                        <form action="{{ route('student.updatepassword') }}" method="post">
                            @csrf
                            <div class="row">
                                <div class="col-md-6 col-xs-12">
                                    <div class="input-style-1">
                                        <label for="name" >User Name </label>
                                        <input type="text" name="name" id="name" value="{{$user->name}}" disabled />
                                        <input type="hidden" name="userid"  value="{{$user->id}}"  />
                                        @error('name')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                                <div class="col-md-6 col-xs-12">
                                    <div class="input-style-1">
                                        <label for="email" >Login Email ID</label>
                                        <input type="email" name="email" id="email" value="{{$user->email}}" disabled  />
                                        @error('email')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 col-xs-12">
                                    <div class="input-style-1">
                                        <label for="password" class="compulsory">Password</label>
                                        <input type="password" name="password" id="password" value="{{ old('password') }}" placeholder="Enter Password">
                                        <span toggle="#password" class="eye-icon toggle-password"></span>
                                        @error('password')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                                <div class="col-md-6 col-xs-12">
                                    <div class="input-style-1">
                                        <label for="password_confirmation" class="compulsory">Confirm Password</label>
                                        <input type="password" name="password_confirmation" value="{{ old('password_confirmation') }}" id="password_confirmation" placeholder="Confirm Password">
                                        @error('password_confirmation')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-12">
                                    <button class="main-btn dark-btn rounded-full btn-hover btn-sm">
                                        Submit
                                    </button>
                                </div>
                            </div>
                            <!-- end row -->
                        </form>

                    </div>
                </div>
            </div>
            <!-- end col -->
        </div>

    </div>
    <!-- end container -->
</section>
<!-- ========== section end ========== -->
@push('script')
<script src="{{ url('assets/js/custom/custom.js')}}"></script>
@endpush

@endsection