@extends('layout.admin_layout')
@section('title', 'Update Student')
@section('dashboard')

<!-- ========== table components start ========== -->
<section class="table-components">
    <div class="container-fluid">

    @if(session('error'))
    <div class="alert alert-danger alert-dismissible mt-20 fade show alert-sm" role="alert">
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        {{ session('error') }}
    </div>
    @endif

    @if(session('success'))
    <div class="alert alert-success alert-dismissible mt-20 fade show alert-sm" role="alert">
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        {{ session('success') }}
    </div>
    @endif

        <!-- ========== title-wrapper start ========== -->
        <div class="title-wrapper pt-30">
            <div class="row align-items-center">
                <div class="col-md-9">
                    <div class="title">
                        <h2>Update Student</h2>
                    </div>
                    <ul class="nav nav-tabs" id="myTabs">
                        <li class="nav-item">
                            <a class="nav-link{{ request()->is('student/show*') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('student.show',['id' => request('id')]) }}">Student Info</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link{{ request()->is('studentcourse/detail*') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('studentcourse.detail',['id' => request('id')]) }}">Course Details</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link{{ request()->is('feereceipt/detail*') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('feereceipt.detail',['id' => request('id')]) }}">Fee Details</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link{{ request()->is('student/calender*') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('student.calender',['id' => request('id')]) }}">Calender</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link{{ request()->routeIs('student.PortfolioSubmission') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('student.PortfolioSubmission',['id' => request('id')]) }}">Portfolio Submission</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link{{ request()->routeIs('student.batchcompletion') ? ' active' : '' }} min-width text-sm" data-toggle="tab" href="{{ route('student.batchcompletion',['id' => request('id')]) }}">Batch Completion</a>
                        </li>
                    </ul>
                </div>
            </div>
            <!-- end row -->
        </div>
        <!-- ========== title-wrapper end ========== -->

        <!-- ========== tables-wrapper start ========== -->
        <div class="row g-0 auth-row">
            <!-- end col -->
            <div class="col-md-12">
                <div class="signup-wrapper">
                    <div class="form-wrapper">
                        <div class="row">
                            <div class="col-lg-4 col-xs-12">
                                <div class="card-style mb-30 d-flex justify-content-center align-items-center">
                                    <div class="text-center">
                                        <div class="rounded-circle overflow-hidden" style="width: 200px; height: 200px;">
                                            @if($record->ProfileImage && file_exists(public_path('uploads/student/profile/' . $record->ProfileImage)))
                                            <img src="{{ asset('uploads/student/profile/' . $record->ProfileImage) }}" alt="Profile Image" class="img-fluid" style="object-fit: cover; width: 100%; height: 100%;">
                                            @else
                                            <img src="{{ url('assets/images/default/user_image.png')}}" alt="Default Image" class="img-fluid" style="object-fit: cover; width: 100%; height: 100%;">
                                            @endif
                                        </div>
                                        <h3 class="text-medium mb-1">{{$record->FirstName}} {{$record->LastName}}</h3>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-8 col-xs-12">
                                <div class="card-style mb-30">
                                    <div class="title">
                                        <h4 class="text-medium mb-3">Profile Details:</h4>
                                    </div>
                                    <div class="row  mb-3">
                                        <div class="col-lg-4 col-md-4 label">Full Name</div>
                                        <div class="col-lg-8 col-md-8">{{$record->FirstName}} {{$record->LastName}}</div>
                                    </div>
                                    <div class="row  mb-3">
                                        <div class="col-lg-4 col-md-4 label">Blood Group</div>
                                        <div class="col-lg-8 col-md-8">{{$record->BloodGroup}}</div>
                                    </div>
                                    <div class="row  mb-3">
                                        <div class="col-lg-4 col-md-4 label">Country</div>
                                        <div class="col-lg-8 col-md-8">
                                            @if ($record->StateId == 0)
                                            Out Of India
                                            @endif
                                            India
                                        </div>
                                    </div>
                                    <div class="row  mb-3">
                                        <div class="col-lg-4 col-md-4 label">State</div>
                                        <div class="col-lg-8 col-md-8">{{$record->state_name}}</div>
                                    </div>
                                    <div class="row  mb-3">
                                        <div class="col-lg-4 col-md-4 label">Address</div>
                                        <div class="col-lg-8 col-md-8">
                                            {{$record->AddressLine1 }},
                                            @if($record->AddressLine2)
                                            {{$record->AddressLine2}},
                                            @endif
                                            {{$record->CityName}}, {{$record->PostalCode}}
                                        </div>
                                    </div>
                                    <div class="row  mb-3">
                                        <div class="col-lg-4 col-md-4 label">Mobile</div>
                                        <div class="col-lg-8 col-md-8">{{$record->MobileNumber}}</div>
                                    </div>
                                    <div class="row mb-3">
                                        <div class="col-lg-4 col-md-4 label">Email</div>
                                        <div class="col-lg-8 col-md-8">{{$record->EmailId}}</div>
                                    </div>
                                </div>
                            </div>

                            <!-- ========== tables-wrapper end ========== -->
                        </div>
                    </div>
                    <!-- end container -->
                </div>
            </div>
        </div>
    </div>
</section>
<!-- ========== table components end ========== -->



@endsection