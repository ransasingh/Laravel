@extends('layout.admin_layout')
@section('title', 'Institute Trash Listing')
@section('dashboard')

<!-- ========== table components start ========== -->
<section class="table-components">
    <div class="container-fluid">
      
    @if(session('error'))
        <div class="alert alert-danger alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('error') }}
        </div>
        @endif

        @if(session('success'))
        <div class="alert alert-success alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('success') }}
        </div>
        @endif

        <!-- ========== title-wrapper start ========== -->
        <div class="title-wrapper pt-30">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <div class="title">
                        <h2>Institute Trash Listing</h2>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="breadcrumb-wrapper">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a href="{{route('institute.listing')}}" class="main-btn active-btn-light rounded-full btn-hover btn-sm">
                                        <i class="lni lni-arrow-left"></i>
                                        All Institute
                                    </a>
                                </li>
                            </ol>
                        </nav>
                    </div>
                </div>

            </div>
            <!-- end row -->
        </div>
        <!-- ========== title-wrapper end ========== -->

        <!-- ========== tables-wrapper start ========== -->
        <div class="tables-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card-style mb-30">

                        <div class="table-wrapper table-responsive">
                            <table class="table" id="data-table">
                                <thead>
                                <tr class="text-sm">
                                        <th class="text-uppercase">#</th>
                                        <th class="text-uppercase">Name</th>
                                        <th class="text-uppercase">Mobile Number</th>
                                        <th class="text-uppercase">EmailId</th>
                                        <th class="text-uppercase">Status</th>
                                        <th class="text-uppercase print-hidden">Action</th>
                                    </tr>
                                    <!-- end table row-->
                                </thead>
                                <tbody>
                                    @if (isset($data))
                                    @foreach ($data as $record)
                                    <tr>
                                        <th scope="row" class="text-sm">{{ $loop->index + 1 }}</th>
                                        <td class="min-width text-sm">{{$record->Name }}</td>
                                        <td class="min-width text-sm">{{$record->MobileNumber}}</td>
                                        <td class="min-width text-sm">{{$record->EmailId}}</td>
                                        <td class="min-width text-sm">
                                            @if($record->IsActive == 1)
                                            <span class="status-btn active-btn" title="Active">Active</span>
                                            @else
                                            <span class="status-btn close-btn" title="Inactive">Inactive</span>
                                            @endif
                                        </td>
                                        <td>
                                            <div class="action">
                                                <a href="{{ route('institute.restore',['id'=>$record->id ]) }}" class="text-primary" title="Restore"><i class="lni lni-spinner-arrow"></i></a>
                                                <a href="{{ route('institute.delete',['id'=>$record->id ]) }}" class="text-danger" onclick="return confirm('Are you sure?')" title="Delete"><i class="lni lni-trash-can"></i></a>
                                            </div>
                                    </tr>
                                    @endforeach
                                    @endif
                                </tbody>
                            </table>
                            <!-- end table -->
                        </div>
                    </div>
                    <!-- end card -->
                </div>
                <!-- end col -->
            </div>
            <!-- end row -->
        </div>
        <!-- ========== tables-wrapper end ========== -->
    </div>
    <!-- end container -->
</section>
<!-- ========== table components end ========== -->



@endsection