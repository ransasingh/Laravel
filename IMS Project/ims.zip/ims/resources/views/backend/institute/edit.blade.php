@extends('layout.admin_layout')
@section('title', 'Institute Edit')
@section('dashboard')
<!-- ========== section start ========== -->
<section class="section">
    <div class="container-fluid">

    @if(session('error'))
        <div class="alert alert-danger alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('error') }}
        </div>
        @endif

        @if(session('success'))
        <div class="alert alert-success alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('success') }}
        </div>
        @endif

        <!-- ========== title-wrapper start ========== -->
        <div class="title-wrapper pt-30">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <div class="title">
                        <h2>Update Institute</h2>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="breadcrumb-wrapper">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a href="{{route('institute.listing')}}" class="main-btn active-btn-light rounded-full btn-hover btn-sm">
                                        <i class="lni lni-arrow-left"></i>
                                        All Institute
                                    </a>
                                </li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
            <!-- end row -->
        </div>
        <div class="row g-0 auth-row">
            <!-- end col -->
            <div class="col-md-12">
                <div class="signup-wrapper">
                    <div class="form-wrapper">
                        <form action="{{ route('institute.editinstitute',['id' =>$data->id]) }}" method="post" enctype="multipart/form-data">
                            @csrf
                            <div class="row">
                                <div class="col-md-4 col-xs-12">
                                    <div class="input-style-1">
                                        <label for="Name" class="compulsory">Name </label>
                                        <input type="text" name="Name" id="Name" value="{{$data->Name}}" placeholder="Enter Institute Name" />
                                        @error('Name')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                                <div class="col-md-4 col-xs-12">
                                    <div class="input-style-1">
                                        <label for="MobileNumber" class="compulsory">Mobile Number</label>
                                        <input type="tel" name="MobileNumber" id="MobileNumber" minlength="10" maxlength="10" value="{{$data->MobileNumber}}" placeholder="Enter Mobile Number" />
                                        @error('MobileNumber')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                                <div class="col-md-4 col-xs-12">
                                    <div class="input-style-1">
                                        <label for="EmailId" class="compulsory">Email</label>
                                        <input type="email" name="EmailId" id="EmailId" value="{{$data->EmailId}}" placeholder="Enter Email" />
                                        @error('EmailId')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4 col-xs-12">
                                    <div class="input-style-1">
                                        <label for="Website">Website</label>
                                        <input type="text" name="Website" id="Website" value="{{$data->Website}}" placeholder="Enter Website" />
                                    </div>
                                </div>
                                <div class="col-md-4 col-xs-12">
                                    <div class="input-style-1">
                                        <label for="AddressLine1" class="compulsory">Address Line1</label>
                                        <textarea name="AddressLine1" id="AddressLine1" cols="30" rows="1" placeholder="Enter Address">{{$data->AddressLine1}}</textarea>
                                        @error('AddressLine1')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                                <div class="col-md-4 col-xs-12">
                                    <div class="input-style-1">
                                        <label for="AddressLine2">Address Line2</label>
                                        <textarea name="AddressLine2" id="AddressLine2" cols="30" rows="1">{{$data->AddressLine2}}</textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4 col-xs-12">
                                    <div class="select-style-1">
                                        <label for="StateId" class="compulsory">State</label>
                                        <div class="select-position">
                                            <select name="StateId" id="StateId">
                                                <option selected disabled>Please select State</option>
                                                @if (isset($states))
                                                @foreach ($states as $state)
                                                <option value="{{$state->id}}" {{$data->StateId == $state->id ? 'selected' : '' }}>{{$state->Name}}</option>
                                                @endforeach
                                                @endif
                                            </select>
                                        </div>
                                        @error('StateId')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                                <div class="col-md-4 col-xs-12">
                                    <div class="input-style-1">
                                        <label for="CityName" class="compulsory">City Name</label>
                                        <input type="text" name="CityName" id="CityName" value="{{$data->CityName}}" placeholder="Enter City Name" />
                                        @error('CityName')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                                <div class="col-md-4 col-xs-12">
                                    <div class="input-style-1">
                                        <label for="PostalCode" class="compulsory">Postal Code</label>
                                        <input type="text" name="PostalCode" id="PostalCode" value="{{$data->PostalCode}}" placeholder="Enter Postal Code" />
                                        @error('PostalCode')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4 col-xs-12">
                                    <div class="input-style-1">
                                        @if($data->InstituteLogo != null)
                                        <label>Institute Logo</label>
                                        <!-- Display image preview -->
                                        <a href="{{ url('uploads/institute/' . $data->InstituteLogo) }}" target="_blank">
                                            <img src="{{ url('uploads/institute/' . $data->InstituteLogo) }}" alt="Institute Logo" width="90px">
                                        </a>
                                        <a class="main-btn danger-btn-light rounded-full btn-hover btn-sm" href="{{ url('institute/deleteimage/' . $data->id . '?imageType=InstituteLogo') }}" onclick="return confirm('Are you sure?');"> Remove </a>
                                        @else
                                        <label for="InstituteLogo">Institute Logo</label>
                                        <input class="form-control" type="file" name="InstituteLogo" id="InstituteLogo" onchange="previewImage('InstituteLogo', 'preview_InstituteLogo')" accept="image/*">
                                        <img id="preview_InstituteLogo" src="#" alt="Visiting Card" style="display:none;" width="80px">
                                        @error('InstituteLogo')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                        @endif
                                       
                                    </div>
                                </div>
                                <div class="col-md-4 col-xs-12">
                                    <div class="select-style-1">
                                        <label for="IsActive" class="compulsory">Status</label>
                                        <div class="select-position">
                                            <select name="IsActive" id="IsActive">
                                                <option value="1" {{$data->IsActive == '1'?'selected':''}}>Active</option>
                                                <option value="0" {{$data->IsActive == '0'?'selected':''}}>Inactive</option>
                                            </select>
                                        </div>
                                        @error('IsActive')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                                <!-- end col -->

                                <div class="col-12">
                                    <button class="main-btn dark-btn rounded-full btn-hover btn-sm">
                                        Update
                                    </button>
                                </div>
                            </div>
                            <!-- end row -->
                        </form>

                    </div>
                </div>
            </div>
            <!-- end col -->
        </div>

    </div>
    <!-- end container -->
</section>
<!-- ========== section end ========== -->
@push('script')
<script src="{{ url('assets/js/custom/custom.js')}}"></script>
@endpush

@endsection