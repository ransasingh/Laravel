@extends('layout.admin_layout')
@section('title', 'CourseSubject Listing')
@section('dashboard')

<!-- ========== table components start ========== -->
<section class="table-components">
    <div class="container-fluid">

    @if(session('error'))
        <div class="alert alert-danger alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('error') }}
        </div>
        @endif

        @if(session('success'))
        <div class="alert alert-success alert-dismissible mt-20 fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('success') }}
        </div>
        @endif


        <!-- ========== title-wrapper start ========== -->
        <div class="title-wrapper pt-30">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <div class="title">
                        <h2>CourseSubject Listing</h2>
                    </div>
                </div>

            </div>
            <!-- end row -->
        </div>
        <!-- ========== title-wrapper end ========== -->

        <!-- ========== tables-wrapper start ========== -->
        <div class="tables-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card-style mb-30">

                        <div class="table-wrapper table-responsive">
                            <table class="table" id="data-table">
                                <thead>
                                    <tr>
                                        <th class="text-uppercase">#</th>
                                        <th class="text-uppercase">Course</th>
                                        <th class="text-uppercase">Subject</th>
                                    </tr>
                                    <!-- end table row-->
                                </thead>
                                <tbody>
                                    @if (isset($data))
                                    @foreach ($data as $record)
                                    <tr>
                                        <th scope="row" class="text-sm">{{ $loop->index + 1 }}</th>
                                        <td class="min-width text-sm">{{$record->course_name }}</td>
                                        <td class="min-width text-sm">{{$record->subject_name }}</td>

                                    </tr>
                                    @endforeach
                                    @endif
                                </tbody>
                            </table>
                            <!-- end table -->
                        </div>
                    </div>
                    <!-- end card -->
                </div>
                <!-- end col -->
            </div>
            <!-- end row -->
        </div>
        <!-- ========== tables-wrapper end ========== -->
    </div>
    <!-- end container -->
</section>
<!-- ========== table components end ========== -->



@endsection