@extends('layout.admin_layout')
@section('title', 'Role Add')
@section('dashboard')
<!-- ========== section start ========== -->
<section class="section">
    <div class="container-fluid">

        @if(session('error'))
        <div class="alert alert-danger alert-dismissible fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('error') }}
        </div>
        @endif

        @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('success') }}
        </div>
        @endif


        <!-- ========== title-wrapper start ========== -->
        <div class="title-wrapper pt-30">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <div class="title">
                        <h2>Add New Role</h2>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="breadcrumb-wrapper">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a href="{{route('role.listing')}}" class="main-btn active-btn-light rounded-full btn-hover btn-sm">
                                        <i class="lni lni-arrow-left"></i>
                                        All Roles
                                    </a>
                                </li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
            <!-- end row -->
        </div>
        <div class="row g-0 auth-row">
            <!-- end col -->
            <div class="col-lg-12">
                <div class="signup-wrapper">
                    <div class="form-wrapper">
                        <form action="{{ route('role.addnew') }}" method="post">
                            @csrf
                            <div class="row">
                                <div class="col-6">
                                    <div class="input-style-1">
                                        <label for="RoleName" class="compulsory">Role Name </label>
                                        <input type="text" name="RoleName" id="RoleName" value="{{ old('RoleName') }}" placeholder="Enter Role" />
                                        @error('RoleName')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="input-style-1">
                                        <label for="Code" class="compulsory">Role Code</label>
                                        <input type="text" name="Code" id="Code" value="{{ old('Code') }}" placeholder="Enter Role Code" />
                                        @error('Code')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-3">
                                    <div class="select-style-1">
                                        <div class="form-check checkbox-style">
                                            <input class="form-check-input" type="checkbox" value="1" name="CanCreate" id="CanCreate" />
                                            <label class="form-check-label" for="CanCreate">Create</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-3">
                                    <div class="select-style-1">
                                        <div class="form-check checkbox-style">
                                            <input class="form-check-input" type="checkbox" value="1" name="CanUpdate" id="CanUpdate" />
                                            <label class="form-check-label" for="CanUpdate">Update</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-3">
                                    <div class="select-style-1">
                                        <div class="form-check checkbox-style">
                                            <input class="form-check-input" type="checkbox" value="1" name="CanDelete" id="CanDelete" />
                                            <label class="form-check-label" for="CanDelete">Delete</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-3">
                                    <div class="select-style-1">
                                        <div class="form-check checkbox-style">
                                            <input class="form-check-input" type="checkbox" value="1" name="CanView" id="CanView" />
                                            <label class="form-check-label" for="CanView">View</label>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div class="row">
                                <div class="col-4">
                                    <div class="select-style-1">
                                        <label for="IsActive" class="compulsory">Status</label>
                                        <div class="select-position">
                                            <select name="IsActive" id="IsActive">
                                                <option value="1" selected>Active</option>
                                                <option value="0">Inactive</option>
                                            </select>
                                        </div>
                                        @error('IsActive')
                                        <span class="text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                                <!-- end col -->

                                <div class="col-12">
                                    <button class="main-btn dark-btn rounded-full btn-hover btn-sm">
                                        Submit
                                    </button>
                                </div>
                            </div>
                            <!-- end row -->
                        </form>

                    </div>
                </div>
            </div>
            <!-- end col -->
        </div>

    </div>
    <!-- end container -->
</section>
<!-- ========== section end ========== -->
@endsection