@extends('layout.admin_layout')
@section('title', 'Roles Trash Listing')
@section('dashboard')

<!-- ========== table components start ========== -->
<section class="table-components">
    <div class="container-fluid">
     
        @if(session('error'))
        <div class="alert alert-danger alert-dismissible fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('error') }}
        </div>
        @endif

        @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show alert-sm" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            {{ session('success') }}
        </div>
        @endif


        <!-- ========== title-wrapper start ========== -->
        <div class="title-wrapper pt-30">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <div class="title">
                        <h2>Roles Trash Listing</h2>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="breadcrumb-wrapper">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a href="{{route('role.listing')}}" class="main-btn active-btn-light rounded-full btn-hover btn-sm">
                                        <i class="lni lni-arrow-left"></i>
                                        All Roles
                                    </a>
                                </li>
                            </ol>
                        </nav>
                    </div>
                </div>

            </div>
            <!-- end row -->
        </div>
        <!-- ========== title-wrapper end ========== -->

        <!-- ========== tables-wrapper start ========== -->
        <div class="tables-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card-style mb-30">

                        <div class="table-wrapper table-responsive">
                            <table class="table" id="data-table">
                                <thead>
                                    <tr>
                                        <th class="text-uppercase">#</th>
                                        <th class="text-uppercase">Role Name </th>
                                        <th class="text-uppercase">Code</th>
                                        <th class="text-uppercase">Create</th>
                                        <th class="text-uppercase">Update</th>
                                        <th class="text-uppercase">Delete</th>
                                        <th class="text-uppercase">View</th>
                                        <th class="text-uppercase">Status</th>
                                        <th class="text-uppercase print-hidden">Action</th>
                                    </tr>
                                    <!-- end table row-->
                                </thead>
                                <tbody>
                                    @if (isset($data))
                                    @foreach ($data as $record)
                                    <tr>
                                        <th scope="row">{{ $loop->index + 1 }}</th>
                                        <td>{{$record->RoleName }}</td>
                                        <td>{{$record->Code }}</td>
                                        <td>
                                            @if($record->CanCreate == 1)
                                            <button type="button" class="main-btn active-btn-light rounded-full btn-hover btn-sm" title="Access">Yes</button>
                                            @else
                                            <button type="button" class="main-btn danger-btn-light rounded-full btn-hover btn-sm" title="Denied">No</button>
                                            @endif
                                        </td>
                                        <td>
                                            @if($record->CanUpdate == 1)
                                            <button type="button" class="main-btn active-btn-light rounded-full btn-hover btn-sm" title="Access">Yes</button>
                                            @else
                                            <button type="button" class="main-btn danger-btn-light rounded-full btn-hover btn-sm" title="Denied">No</button>
                                            @endif
                                        </td>
                                        <td>
                                            @if($record->CanDelete == 1)
                                            <button type="button" class="main-btn active-btn-light rounded-full btn-hover btn-sm" title="Access">Yes</button>
                                            @else
                                            <button type="button" class="main-btn danger-btn-light rounded-full btn-hover btn-sm" title="Denied">No</button>
                                            @endif
                                        </td>
                                        <td>
                                            @if($record->CanView == 1)
                                            <button type="button" class="main-btn active-btn-light rounded-full btn-hover btn-sm" title="Access">Yes</button>
                                            @else
                                            <button type="button" class="main-btn danger-btn-light rounded-full btn-hover btn-sm" title="Denied">No</button>
                                            @endif
                                        </td>
                                        <td>
                                            @if($record->IsActive == 1)
                                            <button type="button" class="main-btn active-btn-light rounded-full btn-hover btn-sm" title="Active"><i class="lni lni-checkmark-circle"></i></button>
                                            @else
                                            <button type="button" class="main-btn danger-btn-light rounded-full btn-hover btn-sm" title="Inactive"><i class="lni lni-cross-circle"></i></button>
                                            @endif
                                        </td>
                                        <td>
                                            <a href="{{ route('role.restore',['id'=>$record->id ]) }}" class="main-btn success-btn-light rounded-full btn-hover btn-sm">Restore</a>
                                            <a href="{{ route('role.delete',['id'=>$record->id ]) }}" class="main-btn danger-btn-light rounded-full btn-hover btn-sm" onclick="return confirm('Are you sure?')">Delete</a>
                                        </td>
                                    </tr>
                                    @endforeach
                                    @endif
                                </tbody>
                            </table>
                            <!-- end table -->
                        </div>
                    </div>
                    <!-- end card -->
                </div>
                <!-- end col -->
            </div>
            <!-- end row -->
        </div>
        <!-- ========== tables-wrapper end ========== -->
    </div>
    <!-- end container -->
</section>
<!-- ========== table components end ========== -->



@endsection